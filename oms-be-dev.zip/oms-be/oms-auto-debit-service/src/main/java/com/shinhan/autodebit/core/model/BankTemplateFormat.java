package com.shinhan.autodebit.core.model;

public class BankTemplateFormat {
	private String sheetName;
	
	//initial row
	private int fromRow; 
	
	//row for header
	private int fromHeaderRow;
	
	// col for header
	private int fromHeaderCol;
	
	// current date to fill second row
	private Object[] dateExportReport;
	
	// row need to setting height
	private int[] customRow;
	
	// height to set for custom row 
	private short[] heightOfCustomRow;
	
	private int[] indexOfMegreItem;
	
	private int[] mergeFrom;
	
	private int[] mergeTo;
	
	private String prefix;
	
	public BankTemplateFormat() {
		super();
	}

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public int getFromRow() {
		return fromRow;
	}

	public void setFromRow(int fromRow) {
		this.fromRow = fromRow;
	}

	public int getFromHeaderRow() {
		return fromHeaderRow;
	}

	public void setFromHeaderRow(int fromHeaderRow) {
		this.fromHeaderRow = fromHeaderRow;
	}

	public int getFromHeaderCol() {
		return fromHeaderCol;
	}

	public void setFromHeaderCol(int fromHeaderCol) {
		this.fromHeaderCol = fromHeaderCol;
	}

	public Object[] getDateExportReport() {
		return dateExportReport;
	}

	public void setDateExportReport(Object[] dateExportReport) {
		this.dateExportReport = dateExportReport;
	}

	public int[] getCustomRow() {
		return customRow;
	}

	public void setCustomRow(int[] customRow) {
		this.customRow = customRow;
	}

	public short[] getHeightOfCustomRow() {
		return heightOfCustomRow;
	}

	public void setHeightOfCustomRow(short[] heightOfCustomRow) {
		this.heightOfCustomRow = heightOfCustomRow;
	}

	public int[] getIndexOfMegreItem() {
		return indexOfMegreItem;
	}

	public void setIndexOfMegreItem(int[] indexOfMegreItem) {
		this.indexOfMegreItem = indexOfMegreItem;
	}

	public int[] getMergeFrom() {
		return mergeFrom;
	}

	public void setMergeFrom(int[] mergeFrom) {
		this.mergeFrom = mergeFrom;
	}

	public int[] getMergeTo() {
		return mergeTo;
	}

	public void setMergeTo(int[] mergeTo) {
		this.mergeTo = mergeTo;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	
}
