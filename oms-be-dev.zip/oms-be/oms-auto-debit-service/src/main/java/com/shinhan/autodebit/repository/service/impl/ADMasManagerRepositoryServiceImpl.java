/**
 * 
 */
package com.shinhan.autodebit.repository.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.shinhan.autodebit.common.AbstractServiceClass;
import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.core.model.AutoDebitTrxInfo;
import com.shinhan.autodebit.core.util.DateUtils;
import com.shinhan.autodebit.repository.dao.TOmsAutoDebitLmsMasDAO;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsInf;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsMas;
import com.shinhan.autodebit.repository.service.ADMasManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("adMasManagerRepositoryService")
public class ADMasManagerRepositoryServiceImpl extends AbstractServiceClass
		implements ADMasManagerRepositoryService {
	private TOmsAutoDebitLmsMasDAO objectDao;

	@Autowired
	public ADMasManagerRepositoryServiceImpl(TOmsAutoDebitLmsMasDAO objectDao) {
		this.objectDao = objectDao;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADMasManagerRepositoryService#getByLoanNo(java.lang.String)
	 */
	@Override
	public TOmsAutoDebitLmsMas getByLoanNo(String loanNo) throws ServiceRuntimeException {
		if (StringUtils.isBlank(loanNo)) {
			return null;
		}
		try {
			TOmsAutoDebitLmsMas item = objectDao.getItemByLoanNo(loanNo);
			return item;
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + loanNo + "");
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADMasManagerRepositoryService#getListUnRegisterAutoDebitTrx(java.util.Map)
	 */
	@Override
	public List<AutoDebitTrxInfo> getListUnRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String sql = "SELECT new com.shinhan.autodebit.core.model.AutoDebitTrxInfo("
					+ "mas.loanNo as loanNo, mas.customerName as customerName, mas.authorizeDt as authorizeDt, mas.firstDt as firstDt, "
					+ "mas.branch as branch, mas.roUser as roUser, mas.bankName as bankName, "
					+ "mas.adType as adType, mas.autosalDay as autosalDay, mas.doc36 as doc36 "
					+ ") "
					+ "from TOmsAutoDebitLmsMas mas "
					+ "where mas.authorizeDt between :fromDt and :endDt "
					+ "and mas.loanStatus = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loanACH = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and (:loanNo is NULL or mas.loanNo =:loanNo) "
					+ "and (:branch is NULL or mas.branch =:branch) "
					+ "and (:roUser is NULL or mas.roUser =:roUser) "
					+ "and (:bankName is NULL or UPPER(mas.bankName) =:bankName) "
					+ "and (:adType is NULL or UPPER(mas.adType) =:adType) "
					+ "and (:doc36 is NULL or UPPER(mas.doc36) =:doc36) "
					+ "and (:firstDt is NULL or mas.firstDt =:firstDt) "
					;
			
			String subQuery = "and NOT EXISTS (select loanNo from TOmsAutoDebitLmsInf inf where mas.loanNo = inf.loanNo ";
			if(inputParams.get(APIConstant.PERIOD_DT) == null){
				subQuery = subQuery + "and inf.statusCode <> '"+APIConstant.AUTO_DEBIT_STATUS_MAPPING_AD_SEND_SMS_DUE_DATE+"' ";
			}
			subQuery = subQuery + ") ";
			String orderBy = "order by authorizeDt asc, loanNo asc";
			
			Query query = entityManager.createQuery(sql + subQuery + orderBy);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("branch", inputParams.get(APIConstant._BRANCH).toString());
			query.setParameter("roUser", inputParams.get(APIConstant._RO_USER).toString());
			
			query.setParameter("bankName", StringUtils.upperCase(inputParams.get(APIConstant._BANK).toString()));
			query.setParameter("adType", StringUtils.upperCase(inputParams.get(APIConstant._AD_TYPE).toString()));
			query.setParameter("doc36", StringUtils.upperCase(inputParams.get(APIConstant._DOC36).toString()));
			
			query.setParameter("firstDt", inputParams.get(APIConstant.PERIOD_DT));
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			List<AutoDebitTrxInfo> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADMasManagerRepositoryService#countUnRegisterAutoDebitTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countUnRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String sql = "select count(*) from oms_ad_lms_mas mas "
					+ "where mas.AUTHORIZED_DT between :fromDt and :endDt "
					+ "and mas.loan_status = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loan_ach = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and (:loanNo is NULL or mas.LOAN_NO =:loanNo) "
					+ "and (:branch is NULL or mas.BRANCH =:branch) "
					+ "and (:roUser is NULL or mas.RO_USER =:roUser) "
					+ "and (:bankName is NULL or UPPER(mas.BANK_NAME) =:bankName) "
					+ "and (:adType is NULL or UPPER(mas.AD_TYPE) =:adType) "
					+ "and (:doc36 is NULL or UPPER(mas.DOC36) =:doc36) "
					+ "and (:firstDt is NULL or mas.first_due_dt =:firstDt) "
					;
			String subQuery = "and NOT EXISTS (select loan_no from oms_ad_lms_inf inf where mas.loan_no = inf.loan_no ";
			if(inputParams.get(APIConstant.PERIOD_DT) == null){
				subQuery = subQuery + "and inf.status_code <> '"+APIConstant.AUTO_DEBIT_STATUS_MAPPING_AD_SEND_SMS_DUE_DATE+"' ";
			}
			subQuery = subQuery + ") ";
			
			Query query = entityManager.createNativeQuery(sql + subQuery);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("branch", inputParams.get(APIConstant._BRANCH).toString());
			query.setParameter("roUser", inputParams.get(APIConstant._RO_USER).toString());
			
			query.setParameter("bankName", StringUtils.upperCase(inputParams.get(APIConstant._BANK).toString()));
			query.setParameter("adType", StringUtils.upperCase(inputParams.get(APIConstant._AD_TYPE).toString()));
			query.setParameter("doc36", StringUtils.upperCase(inputParams.get(APIConstant._DOC36).toString()));
			
			query.setParameter("firstDt"
					, inputParams.get(APIConstant.PERIOD_DT) != null && StringUtils.isNotBlank(inputParams.get(APIConstant._FIRST_DUEDT).toString())
					? inputParams.get(APIConstant.PERIOD_DT)
					: "");
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADMasManagerRepositoryService#exportUnRegisterAutoDebitTrx(java.util.Map)
	 */
	@Override
	public List<Object[]> exportUnRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String sql = "SELECT "
					+ "mas.loanNo as loanNo, mas.customerName as customerName, mas.authorizeDt as authorizeDt, mas.firstDt as firstDt, "
					+ "mas.branch as branch, mas.roUser as roUser, mas.bankName as bankName, "
					+ "mas.adType as adType, mas.autosalDay as autosalDay, mas.doc36 as doc36 "
					+ ""
					+ "from TOmsAutoDebitLmsMas mas "
					+ "where mas.authorizeDt between :fromDt and :endDt "
					+ "and mas.loanStatus = '"+APIConstant.LOAN_STATUS_ACTIVE+"' and mas.loanACH = '"+APIConstant.LOAN_ACH_ACTIVE+"' "
					+ "and (:loanNo is NULL or mas.loanNo =:loanNo) "
					+ "and (:branch is NULL or mas.branch =:branch) "
					+ "and (:roUser is NULL or mas.roUser =:roUser) "
					+ "and (:bankName is NULL or UPPER(mas.bankName) =:bankName) "
					+ "and (:adType is NULL or UPPER(mas.adType) =:adType) "
					+ "and (:doc36 is NULL or UPPER(mas.doc36) =:doc36) "
					+ "and (:firstDt is NULL or mas.firstDt =:firstDt) "
					;
			String subQuery = "and NOT EXISTS (select loanNo from TOmsAutoDebitLmsInf inf where mas.loanNo = inf.loanNo ";
			if(inputParams.get(APIConstant.PERIOD_DT) == null){
				subQuery = subQuery + "and inf.statusCode <> '"+APIConstant.AUTO_DEBIT_STATUS_MAPPING_AD_SEND_SMS_DUE_DATE+"' ";
			}
			subQuery = subQuery + ") ";
			String orderBy = "order by authorizeDt asc";
			
			Query query = entityManager.createQuery(sql + subQuery + orderBy);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("branch", inputParams.get(APIConstant._BRANCH).toString());
			query.setParameter("roUser", inputParams.get(APIConstant._RO_USER).toString());
			
			query.setParameter("bankName", StringUtils.upperCase(inputParams.get(APIConstant._BANK).toString()));
			query.setParameter("adType", StringUtils.upperCase(inputParams.get(APIConstant._AD_TYPE).toString()));
			query.setParameter("doc36", StringUtils.upperCase(inputParams.get(APIConstant._DOC36).toString()));
			
			query.setParameter("firstDt", inputParams.get(APIConstant.PERIOD_DT));
			
			List<Object[]> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.autodebit.repository.service.ADMasManagerRepositoryService#buildDataADTrxReportByBank(java.util.Map)
	 */
	@Override
	public List<TOmsAutoDebitLmsMas> buildDataADTrxReportByBank(Map<String, Object> inputParams) throws ServiceRuntimeException {
		@SuppressWarnings("unchecked")
		List<String> loanNoLst = (List<String>) inputParams.get(APIConstant.DOCUMENT);
		String bankName = inputParams.get(APIConstant._BANK).toString();
		int limit = Integer.valueOf(env.getProperty(APIConstant.DATA_LIMIT_CONDTION_SEARCHING_IN));
		int sizes = loanNoLst.size();
		if(sizes >= limit) {
			int times = sizes / limit;
			int start = 0;
			int end = limit;
			List<TOmsAutoDebitLmsMas> rs = new ArrayList<TOmsAutoDebitLmsMas>();
			for(int i = 0; i <= times; i++) {
				List<String> loanNoList = loanNoLst.subList(start, end);
				rs.addAll(objectDao.findAll(new Specification<TOmsAutoDebitLmsMas>() {
					/**
					 * 
					 */
					private static final long serialVersionUID = 4026019747432813696L;

					@Override
					public Predicate toPredicate(Root<TOmsAutoDebitLmsMas> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
						List<Predicate> predicates = new ArrayList<>();
						if (CollectionUtils.isNotEmpty(loanNoList)) {
//							predicates.add(root.get("loanNo").in(loanNoList));
							predicates.add(root.get("bankName").in(bankName));
							predicates.add(root.get("loanStatus").in(APIConstant.LOAN_STATUS_ACTIVE));
							predicates.add(root.get("loanACH").in(APIConstant.LOAN_ACH_ACTIVE));
						}
						
						return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
					}
				}));
				
				start += limit;
				end += limit;
				if(end > sizes) {
					end = sizes;
				}
			}
			return rs;
			
		} else {
			return objectDao.findAll(new Specification<TOmsAutoDebitLmsMas>() {
				/**
				 * 
				 */
				private static final long serialVersionUID = 4026019747432813696L;

				@Override
				public Predicate toPredicate(Root<TOmsAutoDebitLmsMas> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();
					if (CollectionUtils.isNotEmpty(loanNoLst)) {
//						predicates.add(root.get("loanNo").in(loanNoLst));
						predicates.add(root.get("bankName").in(bankName));
						predicates.add(root.get("loanStatus").in(APIConstant.LOAN_STATUS_ACTIVE));
						predicates.add(root.get("loanACH").in(APIConstant.LOAN_ACH_ACTIVE));
					}
					
					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});
		}
	}

	@Override
	public List<TOmsAutoDebitLmsMas> buildDataADTrxReportByBankTemplate(Map<String, Object> inputParams)
			throws ServiceRuntimeException {

		@SuppressWarnings("unchecked")
		String bankName = inputParams.get(APIConstant._BANK).toString();
		List<TOmsAutoDebitLmsMas> rs = new ArrayList<TOmsAutoDebitLmsMas>();
			String sql = "SELECT new com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsMas("
					+ "mas.loanNo as loanNo, mas.loanStatus as loanStatus, mas.loanACH as loanACH,"
					+ "mas.customerName as customerName, mas.customerPhone, mas.customerIdNo as customerIdNo,"
					+ "mas.customerIssuedDt as customerIssuedDt, mas.customerBankAccount as customerBankAccount, mas.authorizeDt as authorizeDt,"
					+ "mas.firstDt as firstDt, mas.branch as branch, mas.roUser as roUser, mas.bankName as bankName, "
					+ "mas.adType as adType, mas.autosalDay as autosalDay, mas.doc36 as doc36" + ") "
					+ "from TOmsAutoDebitLmsInf inf, TOmsAutoDebitLmsMas mas "
					+ "where inf.loanNo = mas.loanNo and inf.statusCode = :statusCode " + "and mas.loanStatus = '"
					+ APIConstant.LOAN_STATUS_ACTIVE + "' and mas.loanACH = '" + APIConstant.LOAN_ACH_ACTIVE + "' "
					+ "and mas.bankName =:bankName "
					+ "order by inf.receiveDt asc, inf.receiveUser desc, inf.receiveDtIndex asc";
			Query querysql = entityManager.createQuery(sql);
			querysql.setParameter("bankName", bankName);
			querysql.setParameter("statusCode", APIConstant.AUTO_DEBIT_STATUS_MAPPING_DR_RECEIVED_HARD_COPY);
			rs = querysql.getResultList();
			return rs;
	}
}
