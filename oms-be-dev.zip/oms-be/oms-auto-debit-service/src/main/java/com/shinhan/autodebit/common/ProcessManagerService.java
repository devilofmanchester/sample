/**
 * 
 */
package com.shinhan.autodebit.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.shinhan.autodebit.report.ADExportReportService;
import com.shinhan.autodebit.service.ADApiService;
import com.shinhan.autodebit.service.UtilityApiService;

/**
 * @author shds01
 *
 */
@Service("processManagerService")
public class ProcessManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private UtilityApiService utilityApiService;
	
	@Autowired
	private ADApiService adApiService;

	@Autowired
	private ADExportReportService adExportReportService;
	/**
	 * @return the utilityApiService
	 */
	public UtilityApiService getUtilityApiService() {
		return utilityApiService;
	}

	/**
	 * @param utilityApiService the utilityApiService to set
	 */
	public void setUtilityApiService(@Qualifier("utilityApiService") UtilityApiService utilityApiService) {
		this.utilityApiService = utilityApiService;
	}

	/**
	 * @return the adApiService
	 */
	public ADApiService getAdApiService() {
		return adApiService;
	}

	/**
	 * @param adApiService the adApiService to set
	 */
	public void setAdApiService(@Qualifier("adApiService") ADApiService adApiService) {
		this.adApiService = adApiService;
	}

	/**
	 * @return the adExportReportService
	 */
	public ADExportReportService getAdExportReportService() {
		return adExportReportService;
	}

	/**
	 * @param adExportReportService the adExportReportService to set
	 */
	public void setAdExportReportService(@Qualifier("adExportReportService") ADExportReportService adExportReportService) {
		this.adExportReportService = adExportReportService;
	}

}
