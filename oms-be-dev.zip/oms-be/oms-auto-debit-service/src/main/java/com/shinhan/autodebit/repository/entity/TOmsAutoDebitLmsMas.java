/**
 * 
 */
package com.shinhan.autodebit.repository.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_AD_LMS_MAS")
public class TOmsAutoDebitLmsMas implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6380784714776782699L;
	private Long id;
	private String loanNo;
	private String loanStatus;
	private String loanACH;
	private String customerName;
	private String customerPhone;
	private String customerIdNo;
	private Date customerIssuedDt;
	private String customerBankAccount;
	private Date authorizeDt;
	private Date firstDt;
	private String branch;
	private String roUser;
	private String bankName;
	private String adType;
	private String autosalDay;
	private String doc36;

	/**
	 * 
	 */
	public TOmsAutoDebitLmsMas() {
		super();
	}

	/**
	 * @param id
	 * @param loanNo
	 * @param customerName
	 * @param authorizeDt
	 * @param firstDt
	 * @param branch
	 * @param roUser
	 * @param bankName
	 * @param adType
	 * @param autosalDay
	 * @param doc36
	 */
	public TOmsAutoDebitLmsMas(Long id, String loanNo, String customerName, Date authorizeDt, Date firstDt,
			String branch, String roUser, String bankName, String adType, String autosalDay, String doc36) {
		super();
		this.id = id;
		this.loanNo = loanNo;
		this.customerName = customerName;
		this.authorizeDt = authorizeDt;
		this.firstDt = firstDt;
		this.branch = branch;
		this.roUser = roUser;
		this.bankName = bankName;
		this.adType = adType;
		this.autosalDay = autosalDay;
		this.doc36 = doc36;
	}

	/**
	 * @param id
	 * @param loanNo
	 * @param loanStatus
	 * @param loanACH
	 * @param customerName
	 * @param customerPhone
	 * @param customerIdNo
	 * @param customerIssuedDt
	 * @param customerBankAccount
	 * @param authorizeDt
	 * @param firstDt
	 * @param branch
	 * @param roUser
	 * @param bankName
	 * @param adType
	 * @param autosalDay
	 * @param doc36
	 */
	public TOmsAutoDebitLmsMas(Long id, String loanNo, String loanStatus, String loanACH, String customerName,
			String customerPhone, String customerIdNo, Date customerIssuedDt, String customerBankAccount,
			Date authorizeDt, Date firstDt, String branch, String roUser, String bankName, String adType,
			String autosalDay, String doc36) {
		super();
		this.id = id;
		this.loanNo = loanNo;
		this.loanStatus = loanStatus;
		this.loanACH = loanACH;
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerIdNo = customerIdNo;
		this.customerIssuedDt = customerIssuedDt;
		this.customerBankAccount = customerBankAccount;
		this.authorizeDt = authorizeDt;
		this.firstDt = firstDt;
		this.branch = branch;
		this.roUser = roUser;
		this.bankName = bankName;
		this.adType = adType;
		this.autosalDay = autosalDay;
		this.doc36 = doc36;
	}
	

	public TOmsAutoDebitLmsMas(String loanNo, String loanStatus, String loanACH, String customerName,
			String customerPhone, String customerIdNo, Date customerIssuedDt, String customerBankAccount,
			Date authorizeDt, Date firstDt, String branch, String roUser, String bankName, String adType,
			String autosalDay, String doc36) {
		super();
		this.loanNo = loanNo;
		this.loanStatus = loanStatus;
		this.loanACH = loanACH;
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerIdNo = customerIdNo;
		this.customerIssuedDt = customerIssuedDt;
		this.customerBankAccount = customerBankAccount;
		this.authorizeDt = authorizeDt;
		this.firstDt = firstDt;
		this.branch = branch;
		this.roUser = roUser;
		this.bankName = bankName;
		this.adType = adType;
		this.autosalDay = autosalDay;
		this.doc36 = doc36;
	}

	/**
	 * @return the id
	 */
	@Id
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the loanNo
	 */
	@Column(name = "LOAN_NO")
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the loanStatus
	 */
	@Column(name = "LOAN_STATUS")
	public String getLoanStatus() {
		return loanStatus;
	}

	/**
	 * @param loanStatus the loanStatus to set
	 */
	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}

	/**
	 * @return the loanACH
	 */
	@Column(name = "LOAN_ACH")
	public String getLoanACH() {
		return loanACH;
	}

	/**
	 * @param loanACH the loanACH to set
	 */
	public void setLoanACH(String loanACH) {
		this.loanACH = loanACH;
	}

	/**
	 * @return the customerName
	 */
	@Column(name = "CUSTOMER_NAME")
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the customerPhone
	 */
	@Column(name = "CUSTOMER_PHONE")
	public String getCustomerPhone() {
		return customerPhone;
	}

	/**
	 * @param customerPhone the customerPhone to set
	 */
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	/**
	 * @return the customerIdNo
	 */
	@Column(name = "ID_NO")
	public String getCustomerIdNo() {
		return customerIdNo;
	}

	/**
	 * @param customerIdNo the customerIdNo to set
	 */
	public void setCustomerIdNo(String customerIdNo) {
		this.customerIdNo = customerIdNo;
	}

	/**
	 * @return the customerIssuedDt
	 */
	@Column(name = "ID_ISSUED_DT")
	public Date getCustomerIssuedDt() {
		return customerIssuedDt;
	}

	/**
	 * @param customerIssuedDt the customerIssuedDt to set
	 */
	public void setCustomerIssuedDt(Date customerIssuedDt) {
		this.customerIssuedDt = customerIssuedDt;
	}

	/**
	 * @return the customerBankAccount
	 */
	@Column(name = "CUSTOMER_BANK_ACCOUNT")
	public String getCustomerBankAccount() {
		return customerBankAccount;
	}

	/**
	 * @param customerBankAccount the customerBankAccount to set
	 */
	public void setCustomerBankAccount(String customerBankAccount) {
		this.customerBankAccount = customerBankAccount;
	}

	/**
	 * @return the authorizeDt
	 */
	@Column(name = "AUTHORIZED_DT")
	public Date getAuthorizeDt() {
		return authorizeDt;
	}

	/**
	 * @param authorizeDt the authorizeDt to set
	 */
	public void setAuthorizeDt(Date authorizeDt) {
		this.authorizeDt = authorizeDt;
	}

	/**
	 * @return the firstDt
	 */
	@Column(name = "FIRST_DUE_DT")
	public Date getFirstDt() {
		return firstDt;
	}

	/**
	 * @param firstDt the firstDt to set
	 */
	public void setFirstDt(Date firstDt) {
		this.firstDt = firstDt;
	}

	/**
	 * @return the branch
	 */
	@Column(name = "BRANCH")
	public String getBranch() {
		return branch;
	}

	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}

	/**
	 * @return the roUser
	 */
	@Column(name = "RO_USER")
	public String getRoUser() {
		return roUser;
	}

	/**
	 * @param roUser the roUser to set
	 */
	public void setRoUser(String roUser) {
		this.roUser = roUser;
	}

	/**
	 * @return the bankName
	 */
	@Column(name = "BANK_NAME")
	public String getBankName() {
		return bankName;
	}

	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * @return the adType
	 */
	@Column(name = "AD_TYPE")
	public String getAdType() {
		return adType;
	}

	/**
	 * @param adType the adType to set
	 */
	public void setAdType(String adType) {
		this.adType = adType;
	}

	/**
	 * @return the autosalDay
	 */
	@Column(name = "AUTOSAL_DAY")
	public String getAutosalDay() {
		return autosalDay;
	}

	/**
	 * @param autosalDay the autosalDay to set
	 */
	public void setAutosalDay(String autosalDay) {
		this.autosalDay = autosalDay;
	}

	/**
	 * @return the doc36
	 */
	@Column(name = "DOC36")
	public String getDoc36() {
		return doc36;
	}

	/**
	 * @param doc36 the doc36 to set
	 */
	public void setDoc36(String doc36) {
		this.doc36 = doc36;
	}

}
