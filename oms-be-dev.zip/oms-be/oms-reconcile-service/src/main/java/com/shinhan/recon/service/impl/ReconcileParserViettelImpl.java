/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.UnaryOperator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.model.BankTemplateInfo;
import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.core.util.ReadFromExcel;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.service.ReconcileParser;

/**
 * @author shds04
 *
 */
@Service
public class ReconcileParserViettelImpl extends AbstractServiceClass implements ReconcileParser {

	@Override
	public List<BankStatementCommonTemplate> getBankStatement(File file, TBankCommon bankVal, Object bankTemplate,
			Map<String, String> glBaMap) throws Exception {
		ReadFromExcel rw = new ReadFromExcel(file.getAbsolutePath());
		BankTemplateInfo templateInfo = DTOConverter.getBankTemplateInfo(bankVal);
		ArrayList<Map> lsArrMapObject = (ArrayList<Map>) rw.readDataFromExcel(templateInfo.getSheetIndex(), templateInfo.getFromRow(), templateInfo.getHeaderRow());
		if(bankVal.getBankCode().equals(APIConstant.NON_BANK_STATEMENT_VIETTEL)) {
			//Pattern p = Pattern.compile("(?<=Ref:).[0-9]+");
			
			Pattern p = Pattern.compile(oracleOMSNamedQueries.get(APIConstant._REGEX_GET_REF_OCB061).toLowerCase().replaceAll("\\s+", ""));
			//Pattern pDes = Pattern.compile(".*thu ho.*");
			Pattern pDes = Pattern.compile(oracleOMSNamedQueries.get(APIConstant._REGEX_EXCPT_OCB061).toLowerCase().replaceAll("\\s+", ""));
			List<Map<String, Object>> deleteList = new ArrayList<>();
			for (Map map : lsArrMapObject) {
				String loanRefNoFromDesc =String.valueOf(map.get("Debit/Credit Ref")).toLowerCase().replaceAll("\\s+", "");
				String desLower = String.valueOf(map.get("Detail Description")).toLowerCase().replaceAll("\\s+", "");
				Matcher matcher = p.matcher(loanRefNoFromDesc);
				String regexString = "";
				
				if(matcher.find()) {
					regexString = matcher.group(0);
				}
				if(!StringUtils.isBlank(regexString)) {
					map.put("refNo", regexString);
				}else {
					map.put("refNo", "SFVC" + DateUtils.getSystemDateStr(DateUtils.ddMMyyyyhhmmss));
				}
				matcher = pDes.matcher(desLower);
				if(matcher.find()) {
					deleteList.add(map);
				}
			}
			if(bankVal.getBankCode().equals(APIConstant.BANK_STATEMENT_OCB_061)){
				lsArrMapObject.removeAll(deleteList);
			}
			
		}
		/** Step 2: import raw excel data to java class and validation */
		JsonArray jsonArrayDocument = (JsonArray) CommonUtil.toPojo(lsArrMapObject, JsonArray.class);
		
		List<String> excelColumn = Arrays.asList(templateInfo.getTemplateColName().split(","));
		Field[] bankStatementProperty = bankTemplate.getClass().getDeclaredFields();
		
		Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping = buildBankStatementMapping(excelColumn, bankStatementProperty);
		List<BankStatementCommonTemplate> bankStatements = super.mapListExcelDataToListBankStatement(jsonArrayDocument, bankStatementMapping, BankStatementCommonTemplate::new);
		if(bankStatements.isEmpty()) {
			Map<String, Object> statementFileMasMap = new HashedMap<String, Object>();
			statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
			statementFileMasMap.put(APIConstant.UPLOAD_BANKCODE_KEY, bankVal.getBankAccNuber());
			statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY,  APIConstant.LMS_TRX_TYPE_REPAYMENT);
			statementFileMasMap.put(APIConstant._STATUS_KEY,  APIConstant._UPLOAD_FILE_NORMAL_STATUS);
			TOmsStmtFileMas tOmsStmtFileMas = getFileMasByFileName(file.getName(), getRepositoryManagerService()
					.getTomsStmtFileMasManagerRepositoryService().getListUploadByDateAndStatus(statementFileMasMap));
			getProcessManagerService().getReconcileLogProcessService().logToFileMas(tOmsStmtFileMas, env.getProperty("MSG_006"));
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_006"));
		}
		glBaMap.put(APIConstant.GL_OPEN_BALANCE, rw.readFromSpecCell(templateInfo.getSheetIndex(), templateInfo.getGlOpenBlcRow(), templateInfo.getGlOpenBlcCol()));
		glBaMap.put(APIConstant.GL_CLOSE_BALANCE,rw.readFromSpecCell(templateInfo.getSheetIndex(), templateInfo.getGlCloseBlcRow(), templateInfo.getGlCloseBlcCol()));
		return bankStatements;
	}

}
