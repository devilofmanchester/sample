package com.shinhan.recon.core.model.statement;


public class BankStatementViettinBankStatementTemplate {
	
	private String STT;
	private String trxDt;
	private String description;     
	private String debit;
	private String credit;
	private String exntRef;
	private String ref;
	public BankStatementViettinBankStatementTemplate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankStatementViettinBankStatementTemplate(String sTT, String trxDate, String description, String debit,
			String credit, String exntRef, String ref) {
		super();
		STT = sTT;
		this.trxDt = trxDate;
		this.description = description;
		this.debit = debit;
		this.credit = credit;
		this.exntRef = exntRef;
		this.ref = ref;
	}
	public String getSTT() {
		return STT;
	}
	public void setSTT(String sTT) {
		STT = sTT;
	}
	public String getTrxDate() {
		return trxDt;
	}
	public void setTrxDate(String trxDate) {
		this.trxDt = trxDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDebit() {
		return debit;
	}
	public void setDebit(String debit) {
		this.debit = debit;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	public String getExntRef() {
		return exntRef;
	}
	public void setExntRef(String exntRef) {
		this.exntRef = exntRef;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	
}
