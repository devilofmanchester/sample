/**
 * 
 */
package com.shinhan.recon.disburs.service;

import java.io.File;
import java.util.Collection;

import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;

/**
 * @author shds04
 *
 */
public interface ReconcileDisbursProcessService {

	public boolean getFileFromFTPServer() throws ServiceRuntimeException , BaseException;
	
	public Collection<File> getStatementFileFromFolderToRecon(String path) throws ServiceRuntimeException, BaseException;
	
	public void processReconcileBankStatement() throws Exception;
}
