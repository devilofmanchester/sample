/**
 * 
 */
package com.shinhan.recon.core.model;

import java.math.BigDecimal;

/**
 * @author shds04
 *
 */
public class BankDisbursInfo  extends BankTemplateInfo{
	private BigDecimal innerFee;
	private BigDecimal outerFee;
	private String regFin;
	private String regRevert;
	private String regShield;
	
	public BankDisbursInfo() {
		super();
	}
	
	public BankDisbursInfo(BigDecimal innerFee, BigDecimal outerFee, String regFin, String regRevert,
			String regShield) {
		super();
		this.innerFee = innerFee;
		this.outerFee = outerFee;
		this.regFin = regFin;
		this.regRevert = regRevert;
		this.regShield = regShield;
	}

	public BigDecimal getInnerFee() {
		return innerFee;
	}
	public void setInnerFee(BigDecimal innerFee) {
		this.innerFee = innerFee;
	}
	public BigDecimal getOuterFee() {
		return outerFee;
	}
	public void setOuterFee(BigDecimal outerFee) {
		this.outerFee = outerFee;
	}
	public String getRegFin() {
		return regFin;
	}
	public void setRegFin(String regFin) {
		this.regFin = regFin;
	}
	public String getRegRevert() {
		return regRevert;
	}
	public void setRegRevert(String regRevert) {
		this.regRevert = regRevert;
	}
	public String getRegShield() {
		return regShield;
	}
	public void setRegShield(String regShield) {
		this.regShield = regShield;
	}
	
}
