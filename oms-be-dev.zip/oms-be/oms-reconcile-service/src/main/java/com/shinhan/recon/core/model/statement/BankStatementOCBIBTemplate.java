package com.shinhan.recon.core.model.statement;

public class BankStatementOCBIBTemplate {
	
	private String accountNo;
	private String trxDt;
	private String loanNo;
	private String cusName;
	private String credit;
	private String ref;
	private String exntRef;
	public BankStatementOCBIBTemplate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankStatementOCBIBTemplate(String accountNo, String trxDate, String loanNo, String cusName, String credit,
			String ref, String exntRef) {
		super();
		this.accountNo = accountNo;
		this.trxDt = trxDate;
		this.loanNo = loanNo;
		this.cusName = cusName;
		this.credit = credit;
		this.ref = ref;
		this.exntRef = exntRef;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getTrxDate() {
		return trxDt;
	}
	public void setTrxDate(String trxDate) {
		this.trxDt = trxDate;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	public String getExntRef() {
		return exntRef;
	}
	public void setExntRef(String exntRef) {
		this.exntRef = exntRef;
	}

}
