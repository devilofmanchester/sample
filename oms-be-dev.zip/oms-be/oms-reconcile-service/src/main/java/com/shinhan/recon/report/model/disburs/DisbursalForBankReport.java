/**
 * 
 */
package com.shinhan.recon.report.model.disburs;

/**
 * @author shds01
 *
 */
public class DisbursalForBankReport {

	private DisbursalHeaderReport headerReport;
	private DisbursalMatchingDataReport dataMatchingReport;
	private DisbursalUnMatchingDataReport dataUnMatchingReport;
	private DisbursalFooterReport footerReport;

	/**
	 * 
	 */
	public DisbursalForBankReport() {
		super();
	}

	/**
	 * @param headerReport
	 */
	public DisbursalForBankReport(DisbursalHeaderReport headerReport) {
		super();
		this.headerReport = headerReport;
	}

	/**
	 * @return the headerReport
	 */
	public DisbursalHeaderReport getHeaderReport() {
		return headerReport;
	}

	/**
	 * @param headerReport the headerReport to set
	 */
	public void setHeaderReport(DisbursalHeaderReport headerReport) {
		this.headerReport = headerReport;
	}

	/**
	 * @return the dataMatchingReport
	 */
	public DisbursalMatchingDataReport getDataMatchingReport() {
		return dataMatchingReport;
	}

	/**
	 * @param dataMatchingReport the dataMatchingReport to set
	 */
	public void setDataMatchingReport(DisbursalMatchingDataReport dataMatchingReport) {
		this.dataMatchingReport = dataMatchingReport;
	}

	/**
	 * @return the dataUnMatchingReport
	 */
	public DisbursalUnMatchingDataReport getDataUnMatchingReport() {
		return dataUnMatchingReport;
	}

	/**
	 * @param dataUnMatchingReport the dataUnMatchingReport to set
	 */
	public void setDataUnMatchingReport(DisbursalUnMatchingDataReport dataUnMatchingReport) {
		this.dataUnMatchingReport = dataUnMatchingReport;
	}

	/**
	 * @return the footerReport
	 */
	public DisbursalFooterReport getFooterReport() {
		return footerReport;
	}

	/**
	 * @param footerReport the footerReport to set
	 */
	public void setFooterReport(DisbursalFooterReport footerReport) {
		this.footerReport = footerReport;
	}

}
