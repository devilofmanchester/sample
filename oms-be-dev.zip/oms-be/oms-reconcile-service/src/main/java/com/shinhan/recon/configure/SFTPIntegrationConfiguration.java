/**
 * 
 */
package com.shinhan.recon.configure;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.expression.common.LiteralExpression;
import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.file.filters.AcceptOnceFileListFilter;
import org.springframework.integration.file.remote.session.CachingSessionFactory;
import org.springframework.integration.file.remote.session.SessionFactory;
import org.springframework.integration.sftp.filters.SftpSimplePatternFileListFilter;
import org.springframework.integration.sftp.inbound.SftpInboundFileSynchronizer;
import org.springframework.integration.sftp.inbound.SftpInboundFileSynchronizingMessageSource;
import org.springframework.integration.sftp.outbound.SftpMessageHandler;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;
import org.springframework.integration.transformer.StreamTransformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessagingException;

import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.shinhan.recon.core.constant.APIConstant;

/**
 * @author shds01
 *
 */
@Configuration
@EnableIntegration
public class SFTPIntegrationConfiguration {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private Environment env;
	
	@Autowired
	ConfigurableApplicationContext context;
	
	@Autowired
	private SFTPSourceProperties sftpSourceProperties;

	@Bean
	public SessionFactory<LsEntry> sftpSessionFactory() {
		DefaultSftpSessionFactory factory = new DefaultSftpSessionFactory(true);
		factory.setHost(sftpSourceProperties.getHost());
		factory.setPort(sftpSourceProperties.getPort());
		factory.setUser(sftpSourceProperties.getUsername());
		factory.setPassword(sftpSourceProperties.getPassword());
		factory.setAllowUnknownKeys(true);
		return new CachingSessionFactory<LsEntry>(factory);
	}
	
	@Bean
	@Transformer(inputChannel = "sftpChannel", outputChannel = "data")
	public org.springframework.integration.transformer.Transformer transformer() {
		return new StreamTransformer("UTF-8");
	}

	@Bean
	public SftpInboundFileSynchronizer sftpInboundFileSynchronizer() {
		SftpInboundFileSynchronizer fileSynchronizer = new SftpInboundFileSynchronizer(sftpSessionFactory());
		fileSynchronizer.setDeleteRemoteFiles(true);
		fileSynchronizer.setRemoteDirectory(sftpSourceProperties.getSftpRemoteDirectory());//Remote folder
		fileSynchronizer.setFilter(new SftpSimplePatternFileListFilter("*.*")); //Filter file extension
		
		return fileSynchronizer;
	}
	
	@Bean
	//@InboundChannelAdapter(channel = "sftpChannel", poller = @Poller(fixedDelay = "${spring.job.application.fixedDelay.getFileFromSfpt}"))
	public MessageSource<File> sftpMessageSource() {
		logger.info("Connect sftp server success");
		SftpInboundFileSynchronizingMessageSource source = new SftpInboundFileSynchronizingMessageSource(sftpInboundFileSynchronizer());
		source.setLocalDirectory(new File(env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_FTP_FOLDER)));//Local folder
		source.setAutoCreateLocalDirectory(true);
		source.setLocalFilter(new AcceptOnceFileListFilter<File>());
		return source;
	}
	
	@Bean
	@ServiceActivator(inputChannel = "sftpChannel")
	public MessageHandler handler() {
		return new MessageHandler() {
			@Override
			public void handleMessage(Message<?> message) throws MessagingException {
				logger.info("Connect fpt server to get File " + message.getPayload());
				try {
					SFTPGateway gateway = context.getBean(SFTPGateway.class);
                    File orderFile = (File) message.getPayload();
                    //FileUtils.copyFileToDirectory(orderFile, new File(env.getProperty(APIConstant.PATH_SCAN_BANK_TEMP_FOLDER)));
//                    Collection<File> files = CommonUtil.getBankStatementFileInFolder(env.getProperty(APIConstant.PATH_SCAN_BANK_TEMP_FOLDER));
//                    for (File file : files) {
//                    	gateway.sendToSftp(file);
//                    	CommonUtil.deleteFile(file);
//                    	logger.debug("{} is picked by scheduler and moved to {} folder",orderFile.getName(),sftpSourceProperties.getSftpRemoteBackupDir());
//					}
                    
                } catch (Exception e) {
                	logger.error("Error occurred while processing order file exception is {}",e.getMessage());
                }
			}
		};
	}
	
	@Bean
    @ServiceActivator(inputChannel = "sftpChannelDest")
    public MessageHandler handlerOrderBackUp() {
        SftpMessageHandler handler = new SftpMessageHandler(sftpSessionFactory());
        handler.setRemoteDirectoryExpression(new LiteralExpression(sftpSourceProperties.getSftpRemoteBackupDir()));
        return handler;
    }
	@MessagingGateway
    public interface SFTPGateway {
        @Gateway(requestChannel = "sftpChannelDest")
        void sendToSftp(File file);

    }
}
