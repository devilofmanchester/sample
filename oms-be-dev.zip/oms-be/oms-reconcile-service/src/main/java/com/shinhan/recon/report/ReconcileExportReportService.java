/**
 * 
 */
package com.shinhan.recon.report;

import java.io.File;
import java.util.Map;

import com.shinhan.recon.core.exception.BaseException;

/**
 * @author shds01
 *
 */
public interface ReconcileExportReportService {

	public File exportReconcileRepaymentReportForBank (Map<String, Object> inputParams) throws BaseException;
	
	public File exportReconcileRepaymentReportForNonBank (Map<String, Object> inputParams) throws BaseException;
	
	public File exportReconcileDisbursalReport (Map<String, Object> inputParams) throws BaseException;

	public File exportDailyReport (Map<String, Object> inputParams) throws BaseException;

	public File exportPendingReport (Map<String, Object> inputParams) throws BaseException;

	public File exportSuspenseReport(Map<String, Object> inputParams) throws BaseException;

}
