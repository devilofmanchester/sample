package com.shinhan.recon.core.model.statement;

public class BankStatementOCBOTCTemplate {

	private String loanNo;
	private String cusName;
	private String ref;	
	private String credit;
	private String trxDt;
	public BankStatementOCBOTCTemplate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankStatementOCBOTCTemplate(String loanNo, String cusName, String ref, String credit, String trxDate) {
		super();
		this.loanNo = loanNo;
		this.cusName = cusName;
		this.ref = ref;
		this.credit = credit;
		this.trxDt = trxDate;
	}
	public String getAccountNo() {
		return loanNo;
	}
	public void setAccountNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	public String getTrxDate() {
		return trxDt;
	}
	public void setTrxDate(String trxDate) {
		this.trxDt = trxDate;
	}
	
	
}
