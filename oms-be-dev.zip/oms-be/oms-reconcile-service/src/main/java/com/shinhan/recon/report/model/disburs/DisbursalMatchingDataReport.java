/**
 * 
 */
package com.shinhan.recon.report.model.disburs;

import java.util.ArrayList;
import java.util.List;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;

/**
 * @author shds01
 *
 */
public class DisbursalMatchingDataReport {

	private BankStatementLmsTrxInfo sumRecord;

	/**
	 * 
	 */
	public DisbursalMatchingDataReport() {
		super();
		this.sumRecord = new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
	}

	/**
	 * @param matchingLst
	 * @param sumRecord
	 */
	public DisbursalMatchingDataReport(
			BankStatementLmsTrxInfo sumRecord) {
		super();
		this.sumRecord = sumRecord;
	}

	/**
	 * @return the sumRecord
	 */
	public BankStatementLmsTrxInfo getSumRecord() {
		return sumRecord;
	}

	/**
	 * @param sumRecord the sumRecord to set
	 */
	public void setSumRecord(BankStatementLmsTrxInfo sumRecord) {
		this.sumRecord = sumRecord;
	}

}
