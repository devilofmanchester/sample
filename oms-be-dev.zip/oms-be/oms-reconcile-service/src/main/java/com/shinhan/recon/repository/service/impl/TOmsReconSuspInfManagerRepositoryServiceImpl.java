/**
 * 
 */
package com.shinhan.recon.repository.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.Query;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.SuspenseTrxInf;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.dao.TOmsReconSuspInfDAO;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.service.TOmsReconSuspInfManagerRepositoryService;

/**
 * @author shds04
 *
 */
@Service("tOmsReconSuspInfManagerRepositoryService")
public class TOmsReconSuspInfManagerRepositoryServiceImpl extends AbstractServiceClass implements TOmsReconSuspInfManagerRepositoryService {

	private TOmsReconSuspInfDAO objectDao;

	@Autowired
	public TOmsReconSuspInfManagerRepositoryServiceImpl(TOmsReconSuspInfDAO objectDao) {
		this.objectDao = objectDao;
	}
	
	@Override
	public List<TOmsReconSuspenseInf> getSuspenseByRef(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconSuspenseInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getSuspByRef");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String refNo = inputParams.get(APIConstant._REF_NO_KEY).toString();
		String crAmtString = inputParams.get(APIConstant._CR_AMT_KEY).toString();
		BigDecimal crAmt = new BigDecimal( StringUtils.isBlank(crAmtString) ? "0" :crAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconSuspenseInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant._REF_NO_KEY,refNo);
		query.setParameter(APIConstant._CR_AMT_KEY,crAmt);
		list = query.getResultList();
		return list;
	}
	@Override
	public List<TOmsReconSuspenseInf> getSuspenseByRevertRef(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconSuspenseInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getSuspByRevertRef");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String refNo = inputParams.get(APIConstant._REF_NO_KEY).toString();
		String drAmtString = inputParams.get(APIConstant._DR_AMT_KEY).toString();
		BigDecimal drAmt = new BigDecimal( StringUtils.isBlank(drAmtString) ? "0" :drAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconSuspenseInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant._REF_NO_KEY,refNo);
		query.setParameter(APIConstant._DR_AMT_KEY,drAmt);
		list = query.getResultList();
		return list;
	}

	@Override
	public boolean create(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconSuspenseInf item = (TOmsReconSuspenseInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean createAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconSuspenseInf> items = (List<TOmsReconSuspenseInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean update(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconSuspenseInf item = (TOmsReconSuspenseInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean updateAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconSuspenseInf> items = (List<TOmsReconSuspenseInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public List<TOmsReconSuspenseInf> getListTrxByBankcodeAndDate(Map<String, Object> inputParams)
			throws BaseException {
		List< TOmsReconSuspenseInf> rs = new ArrayList<>();
		String bankCode = inputParams.get(APIConstant.UPLOAD_BANKCODE_KEY).toString();
		String trxDt = inputParams.get(APIConstant.TRX_DATE_KEY).toString();
		String sql = oracleOMSNamedQueries.get("getSuspDataByBankCodeAndDate");
		Query query = entityManager.createNativeQuery(sql, TOmsReconSuspenseInf.class);
		query.setParameter(APIConstant.UPLOAD_BANKCODE_KEY, bankCode);
		query.setParameter(APIConstant.TRX_DATE_KEY, DateUtils.convertDate(trxDt, DateUtils.DATEFORMAT));
		rs = query.getResultList();
		return rs;
	}
	@Override
	public List<TOmsReconSuspenseInf> getListTrxByBankcodeAndFileId(Map<String, Object> inputParams) throws BaseException {
		List< TOmsReconSuspenseInf> rs = new ArrayList<>();
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String fileId = inputParams.get(APIConstant.FILE_ID).toString();
		String sql = oracleOMSNamedQueries.get("getSuspDataByBankCodeAndFileId");
		Query query = entityManager.createNativeQuery(sql, TOmsReconSuspenseInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY, bankCode);
		query.setParameter(APIConstant.FILE_ID, fileId);
		rs = query.getResultList();
		return rs;
	}
	@Override
	public List<SuspenseTrxInf> getSuspenseList(Map<String, Object> inputParams) throws BaseException {
		List< SuspenseTrxInf> rs = new ArrayList<>();
		//String bankCode = inputParams.get(APIConstant.UPLOAD_BANKCODE_KEY).toString();
		int statusCode = StringUtils.isBlank(inputParams.get(APIConstant._STATUS_KEY).toString())
				? 0
				: Integer.parseInt(inputParams.get(APIConstant._STATUS_KEY).toString());
		int pageNumber = inputParams.get(APIConstant._START_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
						? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
						: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
		
		int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
						? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
						: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
		String sql = "SELECT new com.shinhan.recon.core.model.SuspenseTrxInf("
				+ "bank.id as id, bank.trxDt as trxDt, bank.refNo as refNo, bank.remark as remark, bank.loanNo as loanNo, bank.bankCode as bankCode,"
				+ "bank.drAmt as drAmt,bank.payMode as payMode, bank.crAmt as crAmt,"
				+ "bank.suspenseType as suspenseType, '' as classification, bank.statusCode as status,"
				+ "bank.remarkNote as remarkNote, bank.statusCode as status, bank.confirmYn as confirmYn, bank.confirmDt as confirmDt"
				+ ") "
				+ "FROM TOmsReconSuspenseInf bank "    
				+ "WHERE "
				+ "(:bankCode is null or :bankCode = bank.bankCode )"
				+ "and bank.trxDt BETWEEN :fromDt and :endDt "
				+ "and bank.statusCode <> 7 "
				+ "and (:loanNo is null or :loanNo = bank.loanNo) "
				+ "and (:refNo is null or :refNo = bank.refNo) "
				+ "and (:flag is null  or :flag = bank.confirmYn) "
				+ "and (:statusCode = 0 or :statusCode = bank.statusCode) ";
		Query query = entityManager.createQuery(sql);
		query.setFirstResult((pageNumber - 1) * pageSize);
		query.setMaxResults(pageSize);
		query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY));
		query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
		query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
		query.setParameter("loanNo",inputParams.get(APIConstant.LOAN_NO_KEY));
		query.setParameter("flag",inputParams.get(APIConstant.FLAG));
		query.setParameter("statusCode", statusCode);
		query.setParameter("refNo", inputParams.get(APIConstant._REF_NO_KEY));
		
		rs = query.getResultList();
		
		for (SuspenseTrxInf tOmsReconSuspenseInf : rs) {
			BigDecimal amt = tOmsReconSuspenseInf.getCrAmt().subtract(tOmsReconSuspenseInf.getDrAmt());
			tOmsReconSuspenseInf.setCrAmt(amt);
			tOmsReconSuspenseInf.setDrAmt(amt);
			tOmsReconSuspenseInf.setAgeing(DateUtils.getDayOfDate(tOmsReconSuspenseInf.getTrxDt()));
		}
		
		return rs.stream().sorted( (i1, i2) -> i2.getAgeing().compareTo(i1.getAgeing()) ).collect(Collectors.toList());
	}
	
	@Override
	public List<Object[]> getSuspenseListForReport(Map<String, Object> inputParams) throws BaseException {
		List< Object[]> rs = new ArrayList<>();
		String sql = "SELECT "
				+ "bank.trx_dt as trxDt, bank.ref_no as refNo, bank.remark as remark, bank.loan_no as loanNo, '' as jv,"
				+ "bank.dr_amt as drAmt,' ' as payMode, bank.cr_amt as crAmt,"
				+ "bank.suspense_type as suspenseType, '' as classification,0 as age, bank.remark_note as note, bank.status as status "
				+ "FROM oms_recon_suspense_inf bank "    
				+ "WHERE "
				+ "bank.status <> 7 "
				+ "and (:bankCode is null or :bankCode = bank.bank_code ) "
				+ "and bank.trx_dt BETWEEN :fromDt and :endDt ";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY));
		query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
		query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
		
		rs = query.getResultList();
		
		for (Object[] objects : rs) {
			BigDecimal crAmt = ( objects[7] == null ? APIConstant.DEC_ZERO : new BigDecimal(objects[7].toString()) );
			BigDecimal drAmt = ( objects[5] == null ? APIConstant.DEC_ZERO : new BigDecimal(objects[5].toString()) );
			long age = DateUtils.getDayOfDate( ( objects[0] == null ? DateUtils.getCurrentDate() : (Date)objects[0] ) );
			objects[7] = objects[5] = crAmt.subtract(drAmt);
			objects[10] = age;
		}
		Comparator<Object[]> reverseComparator = new Comparator<Object[]>() {
	            @Override
	            public int compare(Object[] i1, Object[] i2) {
	            	Long a = (Long) i1[10];
	            	Long b = (Long) i2[10];
	                return b.compareTo(a);
	            }
	        }; 
		return rs.stream().sorted(reverseComparator).collect(Collectors.toList());
	}

	@Override
	public BigDecimal countTotalSuspenseTrxByDate(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT count( distinct bank.ID) "
					+ "FROM OMS_RECON_SUSPENSE_INF bank "
					+ "WHERE "
					+ "bank.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and (:bankCode is null or bank.BANK_CODE = :bankCode) "
					+ "and (:loanNo is null or bank.LOAN_NO =:loanNo) "
					+ "and (:flag is null or bank.CONFIRM_YN = :flag) "
					+ "and (:statusCode= 0 or bank.STATUS = :statusCode) ";
			int statusCode = StringUtils.isBlank(inputParams.get(APIConstant._STATUS_KEY).toString())
					? 0
					: Integer.parseInt(inputParams.get(APIConstant._STATUS_KEY).toString());
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", statusCode);
			query.setParameter("loanNo",inputParams.get(APIConstant.LOAN_NO_KEY));
			query.setParameter("flag",inputParams.get(APIConstant.FLAG));
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	
	@Override
	public TOmsReconSuspenseInf getOne(Map<String, Object> inputParams) throws BaseException {
		String omsId = inputParams.get(APIConstant.OMSID).toString();
		if (StringUtils.isBlank(omsId)) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_003"));
		}
		try {
			TOmsReconSuspenseInf item = objectDao.findById(Long.valueOf(omsId)).get();
			return item;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + omsId + "");
		}
	}
}
