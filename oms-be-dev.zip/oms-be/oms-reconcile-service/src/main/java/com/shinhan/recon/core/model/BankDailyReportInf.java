/**
 * 
 */
package com.shinhan.recon.core.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author shds04
 *
 */
public class BankDailyReportInf implements Serializable{
	private static final long serialVersionUID = -1095014736940613761L;
	
	private String bankName;
	private List<Object[]> data;
	public BankDailyReportInf() {
		super();
		this.data = new ArrayList<>();
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public List<Object[]> getData() {
		return data;
	}
	public void setData(List<Object[]> data) {
		this.data = data;
	}
	
}
