/**
 * 
 */
package com.shinhan.recon.core.model.disburs.statement;

/**
 * @author shds04
 *
 */
public class BankDisbursTechcombankTemplate {
	private String remitter;
	private String trxDt;
	private String description;
	private String ref;
	private String remitterBank;
	private String debit;
	private String credit;
	public BankDisbursTechcombankTemplate() {
		super();
	}
	public BankDisbursTechcombankTemplate(String remitter, String trxDt, String description, String ref,
			String remitterBank, String debit, String credit) {
		super();
		this.remitter = remitter;
		this.trxDt = trxDt;
		this.description = description;
		this.ref = ref;
		this.remitterBank = remitterBank;
		this.debit = debit;
		this.credit = credit;
	}
	public String getRemitter() {
		return remitter;
	}
	public void setRemitter(String remitter) {
		this.remitter = remitter;
	}
	public String getTrxDt() {
		return trxDt;
	}
	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	public String getRemitterBank() {
		return remitterBank;
	}
	public void setRemitterBank(String remitterBank) {
		this.remitterBank = remitterBank;
	}
	public String getDebit() {
		return debit;
	}
	public void setDebit(String debit) {
		this.debit = debit;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	
}
