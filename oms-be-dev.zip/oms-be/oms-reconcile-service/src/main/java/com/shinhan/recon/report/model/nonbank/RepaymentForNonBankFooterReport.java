/**
 * 
 */
package com.shinhan.recon.report.model.nonbank;

import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;

/**
 * @author shds01
 *
 */
public class RepaymentForNonBankFooterReport {

	private BankStatementLmsTrxInfo sumGrandRecord;

	/**
	 * 
	 */
	public RepaymentForNonBankFooterReport() {
		super();
	}

	/**
	 * @param sumGrandRecord
	 */
	public RepaymentForNonBankFooterReport(BankStatementLmsTrxInfo sumGrandRecord) {
		super();
		this.sumGrandRecord = sumGrandRecord;
	}
	
	/**
	 * @return the sumRecord
	 */
	public BankStatementLmsTrxInfo getSumRecord() {
		return sumGrandRecord;
	}

	/**
	 * @param sumGrandRecord the sumGrandRecord to set
	 */
	public void setSumRecord(BankStatementLmsTrxInfo sumGrandRecord) {
		this.sumGrandRecord = sumGrandRecord;
	}

	
}
