package com.shinhan.recon.report.model.bank;

import java.util.ArrayList;
import java.util.List;

import com.shinhan.recon.report.model.SuspenseReportHeader;

public class SuspenseReportData {
	
	private List<Object[]> pending;
	private List<Object[]> done;
	private List<Object[]> income;
	private SuspenseReportHeader suspenseReportHeader;

	public SuspenseReportData() {
		pending = new ArrayList<>();
		done = new ArrayList<>();
		income = new ArrayList<>();
	}

	public SuspenseReportHeader getSuspenseReportHeader() {
		return suspenseReportHeader;
	}

	public void setSuspenseReportHeader(SuspenseReportHeader suspenseReportHeader) {
		this.suspenseReportHeader = suspenseReportHeader;
	}

	public List<Object[]> getPending() {
		return pending;
	}

	public void setPending(List<Object[]> pending) {
		this.pending = pending;
	}

	public List<Object[]> getDone() {
		return done;
	}

	public void setDone(List<Object[]> done) {
		this.done = done;
	}

	public List<Object[]> getIncome() {
		return income;
	}

	public void setIncome(List<Object[]> income) {
		this.income = income;
	}
	
}
