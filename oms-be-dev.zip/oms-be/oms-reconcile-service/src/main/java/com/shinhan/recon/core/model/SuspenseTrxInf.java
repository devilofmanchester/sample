/**
 * 
 */
package com.shinhan.recon.core.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author shds04
 *
 */
public class SuspenseTrxInf implements Serializable {
	private static final long serialVersionUID = -4990488919534808657L;
	
	private Long id;
	private Date trxDt;
	private String refNo;
	private String remark;
	private String loanNo;    
	private String bankCode;
	private BigDecimal drAmt;
	private String payMode;
	private BigDecimal crAmt;
	private String suspenseType;
	private String classification;
	private Long ageing;
	private String remarkNote;
	private long status;
	private String confirmYn;
	private Date confirmDt;
	public SuspenseTrxInf() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SuspenseTrxInf(Long id, Date trxDt, String refNo, String remark, String loanNo, String bankCode,
			BigDecimal drAmt, String payMode, BigDecimal crAmt, String suspenseType, String classification, Long ageing,
			String remarkNote, long status, String confirmYn, Date confirmDt) {
		super();
		this.id = id;
		this.trxDt = trxDt;
		this.refNo = refNo;
		this.remark = remark;
		this.loanNo = loanNo;
		this.bankCode = bankCode;
		this.drAmt = drAmt;
		this.payMode = payMode;
		this.crAmt = crAmt;
		this.suspenseType = suspenseType;
		this.classification = classification;
		this.ageing = ageing;
		this.remarkNote = remarkNote;
		this.status = status;
		this.confirmYn = confirmYn;
		this.confirmDt = confirmDt;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getTrxDt() {
		return trxDt;
	}
	public void setTrxDt(Date trxDt) {
		this.trxDt = trxDt;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public BigDecimal getDrAmt() {
		return drAmt;
	}
	public void setDrAmt(BigDecimal drAmt) {
		this.drAmt = drAmt;
	}
	public String getPayMode() {
		return payMode;
	}
	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}
	public BigDecimal getCrAmt() {
		return crAmt;
	}
	public void setCrAmt(BigDecimal crAmt) {
		this.crAmt = crAmt;
	}
	public String getSuspenseType() {
		return suspenseType;
	}
	public void setSuspenseType(String suspenseType) {
		this.suspenseType = suspenseType;
	}
	public String getClassification() {
		return classification;
	}
	public void setClassification(String classification) {
		this.classification = classification;
	}
	public Long getAgeing() {
		return ageing;
	}
	public void setAgeing(Long ageing) {
		this.ageing = ageing;
	}
	public String getRemarkNote() {
		return remarkNote;
	}
	public void setRemarkNote(String remarkNote) {
		this.remarkNote = remarkNote;
	}
	public long getStatus() {
		return status;
	}
	public void setStatus(long status) {
		this.status = status;
	}
	public String getConfirmYn() {
		return confirmYn;
	}
	public void setConfirmYn(String confirmYn) {
		this.confirmYn = confirmYn;
	}
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getConfirmDt() {
		return confirmDt;
	}
	public void setConfirmDt(Date confirmDt) {
		this.confirmDt = confirmDt;
	}
	
	
}
