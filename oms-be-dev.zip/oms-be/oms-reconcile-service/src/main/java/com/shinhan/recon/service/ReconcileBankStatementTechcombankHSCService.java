/**
 * 
 */
package com.shinhan.recon.service;

import java.io.File;
import java.util.List;

import com.shinhan.recon.repository.entity.TBankCommon;

/**
 * @author shds04
 *
 */
public interface ReconcileBankStatementTechcombankHSCService {
	public void processReconcileBankStatementTechcombank_028(File file, List<TBankCommon> listBankCommonVal) throws Exception;
}
