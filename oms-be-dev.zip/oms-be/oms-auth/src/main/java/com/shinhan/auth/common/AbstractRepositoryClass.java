/**
 * 
 */
package com.shinhan.auth.common;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

import com.shinhan.auth.core.constant.APIConstant;
import com.shinhan.auth.core.exception.ServiceRuntimeException;
import com.shinhan.auth.core.model.UserFeatureInfo;
import com.shinhan.auth.core.model.UserInfo;
import com.shinhan.auth.core.model.UserPermission;
import com.shinhan.auth.core.model.UserRoleInfo;
import com.shinhan.auth.core.util.CommonUtil;
import com.shinhan.auth.core.util.DTOConverter;
import com.shinhan.auth.repository.entity.AuthUser;
import com.shinhan.auth.repository.entity.TDataModel;
import com.shinhan.auth.repository.entity.TMetadata;



/**
 * @author shds01
 *
 */

public abstract class AbstractRepositoryClass {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public Environment env;

	@PersistenceContext(unitName = "entityManagerOMS")
	public EntityManager entityManager;

	@Autowired
	private RepositoryManagerService repositoryManagerService;

	@Autowired
	public OracleOMSNamedQueries oracleOMSNamedQueries;

	/**
	 * @return the repositoryManagerService
	 */
	public RepositoryManagerService getRepositoryManagerService() {
		return repositoryManagerService;
	}

	/**
	 * @param repositoryManagerService the repositoryManagerService to set
	 */
	public void setRepositoryManagerService(
			@Qualifier("repositoryManagerService") RepositoryManagerService repositoryManagerService) {
		this.repositoryManagerService = repositoryManagerService;
	}
	
	public static Hashtable<String, TMetadata> hashItembyName(List<TMetadata> items) {
		Hashtable<String, TMetadata> ht = new Hashtable<String, TMetadata>();
		if (items != null && items.size() >= 0) {
			for (TMetadata item : items) {
				ht.put(item.getLookupCodeId(), item);
			}
		}
		return ht;
	}

	public UserInfo getUserProfileByUserName(AuthUser authUser) throws ServiceRuntimeException {
		List<UserRoleInfo> userRoleProfiles = new ArrayList<UserRoleInfo>();
		List<UserRoleInfo> userRoles = CommonUtil.toListPojo(authUser.getConfiguration(), UserRoleInfo.class);
		List<TMetadata> roles = repositoryManagerService.getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant.LOOKUP_CODE_OMS_USER_ROLE);
		List<TMetadata> features = repositoryManagerService.getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant.LOOKUP_CODE_OMS_USER_FEATURE);
		
		for(UserRoleInfo userRole : userRoles) {
			for(TMetadata role : roles) {
				//Role
				if(userRole.getRoleCode().equalsIgnoreCase(role.getLookupCodeId()) && APIConstant.YES_KEY.equalsIgnoreCase(role.getIsShow())) {
					UserRoleInfo userRoleProfile = DTOConverter.setUtilityUserRoleInfoForProfile(role);
					
					TDataModel model = repositoryManagerService.getUtilityManagerRepositoryService().getDataModelByDocType(role.getLookupCodeId());
					UserRoleInfo userInfoModel = (UserRoleInfo) CommonUtil.toPojo(model.getDataModel(), UserRoleInfo.class);
					List<UserFeatureInfo> userFeatureModels = userInfoModel.getFeatures();
					List<UserFeatureInfo> userFeatureProfile = new ArrayList<UserFeatureInfo>();
					//Feature
					for(UserFeatureInfo userFeature : userFeatureModels) {
						for(TMetadata feature : features) {
							if(userFeature.getFeatureCode().equalsIgnoreCase(feature.getLookupCodeId())) {
								userFeature.setIsShow(feature.getIsShow());
								userFeatureProfile.add(userFeature);
								break;
							}
						}
					}
					userRoleProfile.setFeatures(userFeatureProfile);
					userRoleProfiles.add(userRoleProfile);
					break;
				}
			}
			
		}
		return new UserInfo(authUser.getUsername(), authUser.getFullname(), authUser.getStatus(), userRoleProfiles);
	}
	
	public boolean checkPermissionUserNameByURL(AuthUser authUser, UserPermission userPer) throws ServiceRuntimeException {
		if(userPer == null || authUser == null || StringUtils.isBlank(userPer.getUrl()) ) {
			return false;
		}
		List<TMetadata> features = repositoryManagerService.getUtilityManagerRepositoryService().getMetadataByLookupCode(APIConstant.LOOKUP_CODE_OMS_USER_FEATURE);
		List<UserRoleInfo> userRoles = CommonUtil.toListPojo(authUser.getConfiguration(), UserRoleInfo.class);
		for(UserRoleInfo userRole : userRoles) {
			TMetadata roleItem = repositoryManagerService.getUtilityManagerRepositoryService().getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_OMS_USER_ROLE, userRole.getRoleCode());
			if(APIConstant.NO_KEY.equalsIgnoreCase(roleItem.getIsShow())) {
				continue;
			}
			
			TDataModel model = repositoryManagerService.getUtilityManagerRepositoryService().getDataModelByDocType(roleItem.getLookupCodeId());
			UserRoleInfo userInfoModel = (UserRoleInfo) CommonUtil.toPojo(model.getDataModel(), UserRoleInfo.class);
			List<UserFeatureInfo> userFeatureModels = userInfoModel.getFeatures();
			//Feature
			for(UserFeatureInfo userFeature : userFeatureModels) {
				String featureCode = userFeature.getFeatureCode();
				for(TMetadata feature : features) {
					if(featureCode.equalsIgnoreCase(feature.getLookupCodeId()) && APIConstant.YES_KEY.equalsIgnoreCase(feature.getIsShow())) {
						if(checkPermissionFeatureByURL(userFeature, userPer)) {
							return true;
						}
						break;
					}
				}
			}
		}
		return false;
	}
	
	private boolean checkPermissionFeatureByURL(UserFeatureInfo feature, UserPermission userPer) {
		String isRead = feature.getIsRead();
		String isWrite = feature.getIsWrite();
		String endpoint = feature.getEndpoint();
		String url = userPer.getUrl();
		String method = userPer.getMethod();
		String contentType = userPer.getContentType();
		
		if(StringUtils.isBlank(isRead) || StringUtils.isBlank(isWrite) 
				|| StringUtils.isBlank(endpoint) || StringUtils.isBlank(url) || StringUtils.isBlank(method)
				|| APIConstant.NO_KEY.equalsIgnoreCase(isRead)) {
			return false;
		}
		
		if(!endpoint.contains(url)) {
			return false;
		}
		
		if(APIConstant.GET_METHOD_STR.equalsIgnoreCase(method) && (APIConstant.YES_KEY.equalsIgnoreCase(isWrite) || APIConstant.YES_KEY.equalsIgnoreCase(isRead))) {
			return true;
		} else if(APIConstant.PATCH_METHOD_STR.equalsIgnoreCase(method) && (APIConstant.YES_KEY.equalsIgnoreCase(isWrite))) {
			return true;
		} else if(APIConstant.POST_METHOD_STR.equalsIgnoreCase(method)) {
			if(APIConstant.YES_KEY.equalsIgnoreCase(isWrite)) {
				return true;
			} else if(APIConstant.YES_KEY.equalsIgnoreCase(isRead) && (APIConstant.CONTENT_TYPE_APPLICATION_OCTET_STREAM.equalsIgnoreCase(contentType) || APIConstant.CONTENT_TYPE_APPLICATION_PDF.equalsIgnoreCase(contentType))) {
				return true;
			}
			return false;
		}
		
		return false;
	}
}
































