/**
 * 
 */
package com.shinhan.auth.repository.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.auth.common.AbstractServiceClass;
import com.shinhan.auth.core.exception.ServiceRuntimeException;
import com.shinhan.auth.repository.dao.AuthUserDAO;
import com.shinhan.auth.repository.entity.AuthUser;
import com.shinhan.auth.repository.service.AuthManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("authManagerRepositoryService")
public class AuthManagerRepositoryServiceImpl extends AbstractServiceClass
		implements AuthManagerRepositoryService {
	
	private AuthUserDAO objectAuthDao;

	@Autowired
	public AuthManagerRepositoryServiceImpl(AuthUserDAO objectAuthDao) {
		this.objectAuthDao = objectAuthDao;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.AuthManagerRepositoryService#getAuthenUserProfile(java.lang.String)
	 */
	@Override
	public AuthUser getAuthenUserProfile(String username) throws ServiceRuntimeException {
		if (StringUtils.isBlank(username)) {
			return null;
		}
		try {
			return objectAuthDao.getProfileByUsername(username);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.AuthManagerRepositoryService#createAuthUser(com.shinhan.auth.repository.entity.AuthUser)
	 */
	@Override
	public boolean createAuthUser(AuthUser user) throws ServiceRuntimeException {
		try {
			if (user != null) {
				objectAuthDao.save(user);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.repository.service.AuthManagerRepositoryService#updateAuthUser(com.shinhan.auth.repository.entity.AuthUser)
	 */
	@Override
	public boolean updateAuthUser(AuthUser user) throws ServiceRuntimeException {
		try {
			if (user != null) {
				objectAuthDao.save(user);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

}
