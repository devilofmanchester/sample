/**
 * 
 */
package com.shinhan.auth.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.shinhan.auth.repository.entity.TDataModel;

/**
 * @author shds01
 *
 */
@Repository
public interface TDataModelDAO extends JpaRepository<TDataModel, Long> {

	@Query("SELECT item FROM TDataModel item WHERE documentType = :documentType")
	public TDataModel getModelByDocType(@Param("documentType") String documentType);
}
