/**
 * 
 */
package com.shinhan.auth.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.shinhan.auth.service.AuthApiService;
import com.shinhan.auth.service.ConfigurationApiService;
import com.shinhan.auth.service.UtilityApiService;

/**
 * @author shds01
 *
 */
@Service("processManagerService")
public class ProcessManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private UtilityApiService utilityApiService;
	
	@Autowired
	private AuthApiService authApiService;
	
	@Autowired
	private ConfigurationApiService configurationApiService;
	
	/**
	 * @return the utilityApiService
	 */
	public UtilityApiService getUtilityApiService() {
		return utilityApiService;
	}

	/**
	 * @param utilityApiService the utilityApiService to set
	 */
	public void setUtilityApiService(@Qualifier("utilityApiService") UtilityApiService utilityApiService) {
		this.utilityApiService = utilityApiService;
	}

	/**
	 * @return the authApiService
	 */
	public AuthApiService getAuthApiService() {
		return authApiService;
	}

	/**
	 * @param authApiService the authApiService to set
	 */
	public void setAuthApiService(@Qualifier("authApiService") AuthApiService authApiService) {
		this.authApiService = authApiService;
	}

	/**
	 * @return the configurationApiService
	 */
	public ConfigurationApiService getConfigurationApiService() {
		return configurationApiService;
	}

	/**
	 * @param configurationApiService the configurationApiService to set
	 */
	public void setConfigurationApiService(@Qualifier("configurationApiService") ConfigurationApiService configurationApiService) {
		this.configurationApiService = configurationApiService;
	}

}
