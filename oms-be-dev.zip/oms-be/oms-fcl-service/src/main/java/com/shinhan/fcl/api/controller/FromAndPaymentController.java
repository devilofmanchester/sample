/**
 * 
 */
package com.shinhan.fcl.api.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;

/**
 * @author shds01
 *
 */
@RestController
public class FromAndPaymentController extends BaseController{
	
	/** Payment Available */
	@RequestMapping(value = "shinhan/service/formpayment", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	public String getListPaymentAvailable(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _cifNo,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant._LOAN_NO, _loanNo);
		inputParams.put(APIConstant._CIF_NO, _cifNo);
		
		List<EarlyTerminationTrx> lst = getProcessManagerService().getFormPaymentApiService().getListFormPaymentAvailable(inputParams);
		BigDecimal countTotal = getProcessManagerService().getFormPaymentApiService().countFormPaymentAvailableTrx(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
}
