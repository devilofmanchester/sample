/**
 * 
 */
package com.shinhan.fcl.repository.service;

import java.util.List;

import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.repository.entity.TMetadata;
import com.shinhan.fcl.repository.entity.TOmsFCLLmsMas;

/**
 * @author shds01
 *
 */
public interface UtilityManagerRepositoryService {
	
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws ServiceRuntimeException;
	
	public TMetadata getMetadataById(Long id) throws ServiceRuntimeException;
	
	public TMetadata getMetadataByLookupCodeAndId(String lookupCode, String lookupId) throws ServiceRuntimeException;
	
	public TOmsFCLLmsMas getFCLMasTrxByLoanNo(String loanNo) throws ServiceRuntimeException;
}
