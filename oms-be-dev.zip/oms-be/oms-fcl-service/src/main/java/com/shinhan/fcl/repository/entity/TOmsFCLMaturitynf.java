/**
 * 
 */
package com.shinhan.fcl.repository.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_FCL_MATURITY_INF")
public class TOmsFCLMaturitynf implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String loanNo;
	private String statusCode;
	private BigDecimal rpa_amount;
	private String createdUser;
	private Date createdDt;
	private String updatedUser;
	private Date updatedDt;

	/**
	 * 
	 */
	public TOmsFCLMaturitynf() {
		super();
	}

	/**
	 * @param loanNo
	 * @param statusCode
	 * @param createdUser
	 * @param createdDt
	 * @param updatedUser
	 * @param updatedDt
	 */
	public TOmsFCLMaturitynf(String loanNo, String statusCode, String createdUser, Date createdDt, String updatedUser,
			Date updatedDt) {
		super();
		this.loanNo = loanNo;
		this.statusCode = statusCode;
		this.createdUser = createdUser;
		this.createdDt = createdDt;
		this.updatedUser = updatedUser;
		this.updatedDt = updatedDt;
	}

	/**
	 * @return the loanNo
	 */
	@Id
	@Column(name = "LOAN_NO")
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the statusCode
	 */
	@Column(name = "STATUS_CODE")
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the rpa_amount
	 */
	@Column(name = "RPA_AMOUNT")
	public BigDecimal getRpa_amount() {
		return rpa_amount;
	}

	/**
	 * @param rpa_amount the rpa_amount to set
	 */
	public void setRpa_amount(BigDecimal rpa_amount) {
		this.rpa_amount = rpa_amount;
	}

	/**
	 * @return the createdUser
	 */
	@Column(name = "REGIS_INF_USER")
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * @param createdUser the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * @return the createdDt
	 */
	@Column(name = "REGIS_INF_DT")
	public Date getCreatedDt() {
		return createdDt;
	}

	/**
	 * @param createdDt the createdDt to set
	 */
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	/**
	 * @return the updatedUser
	 */
	@Column(name = "LCHG_INF_USER")
	public String getUpdatedUser() {
		return updatedUser;
	}

	/**
	 * @param updatedUser the updatedUser to set
	 */
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	/**
	 * @return the updatedDt
	 */
	@Column(name = "LCHG_INF_DT")
	public Date getUpdatedDt() {
		return updatedDt;
	}

	/**
	 * @param updatedDt the updatedDt to set
	 */
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

}
