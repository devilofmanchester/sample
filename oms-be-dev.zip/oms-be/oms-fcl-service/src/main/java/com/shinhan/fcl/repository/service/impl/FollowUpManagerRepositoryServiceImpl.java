/**
 * 
 */
package com.shinhan.fcl.repository.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.fcl.common.AbstractServiceClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.util.DateUtils;
import com.shinhan.fcl.repository.dao.TOmsFCLFollowEMIINFDAO;
import com.shinhan.fcl.repository.dao.TOmsFCLLmsMasDAO;
import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIInf;
import com.shinhan.fcl.repository.service.FollowUpManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("followUpManagerRepositoryService")
public class FollowUpManagerRepositoryServiceImpl extends AbstractServiceClass
		implements FollowUpManagerRepositoryService {

	private TOmsFCLLmsMasDAO objectMasDao;
	
	private TOmsFCLFollowEMIINFDAO objectEMIInfDao;

	@Autowired
	public FollowUpManagerRepositoryServiceImpl(TOmsFCLLmsMasDAO objectMasDao, TOmsFCLFollowEMIINFDAO objectEMIInfDao) {
		this.objectMasDao = objectMasDao;
		this.objectEMIInfDao = objectEMIInfDao;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormManagerRepositoryService#getListFollowUpEMI(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListFollowUpEMI(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String sql = "SELECT new com.shinhan.fcl.core.model.EarlyTerminationTrx("
					
					+ "mas.loan_no, mas.cif, mas.customer_name, mas.customer_phone_no, mas.last_due_date, "
					+ "mas.last_payment_bank_ref, mas.collection_account, mas.bank_narration, mas.bank_credit_amount, "
					+ "mas.emi_amount, mas.transaction_date, mas.outstanding_principle, mas.excess_amount, "
					+ "mas.penalty_fees, mas.partner_bank, inf.statusCode as followup_note, inf.remarks as remarks"
					
					+ ") "
					+ "from TOmsFCLLmsMas mas left join TOmsFCLFollowEMIInf inf on mas.loan_no = inf.loanNo "
					+ "where UPPER(mas.loan_status) = :loan_status "
					+ "and to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - mas.transaction_date > 2 "
					+ "and mas.bank_credit_amount is not null and mas.emi_amount is not null "
					+ "and mas.bank_credit_amount >= 3 * mas.emi_amount "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:partner_bank is NULL or mas.partner_bank = :partner_bank) "
					;
		
			String orderBy = " order by mas.loan_no asc, mas.partner_bank asc";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_ACTIVE);
			query.setParameter("sys_date", DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("partner_bank", inputParams.get(APIConstant._PARTNER_BANK).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			@SuppressWarnings("unchecked")
			List<EarlyTerminationTrx> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormManagerRepositoryService#countFollowUpEMITrx(java.util.Map)
	 */
	@Override
	public BigDecimal countFollowUpEMITrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String sql = "select count(*) from oms_fcl_lms_mas mas "
					+ "where UPPER(mas.loan_status) = :loan_status "
					+ "and to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - mas.transaction_date > 2 "
					+ "and mas.bank_credit_amount is not null and mas.emi_amount is not null "
					+ "and mas.bank_credit_amount >= 3 * mas.emi_amount "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:partner_bank is NULL or mas.partner_bank = :partner_bank) "
					;
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_ACTIVE);
			query.setParameter("sys_date", DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("partner_bank", inputParams.get(APIConstant._PARTNER_BANK).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FollowUpManagerRepositoryService#createAll(java.util.Map)
	 */
	@Override
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			@SuppressWarnings("unchecked")
			List<TOmsFCLFollowEMIInf> items = (List<TOmsFCLFollowEMIInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectEMIInfDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FollowUpManagerRepositoryService#getFollowUpEMITrxByLoanNo(java.lang.String)
	 */
	@Override
	public TOmsFCLFollowEMIInf getFollowUpEMITrxByLoanNo(String loanNo) throws ServiceRuntimeException {
		if (StringUtils.isBlank(loanNo)) {
			return null;
		}
		try {
			TOmsFCLFollowEMIInf item = objectEMIInfDao.getItemByLoanNo(loanNo);
			return item;
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + loanNo + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FollowUpManagerRepositoryService#exportReportFollowupEMITrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportFollowupEMITrx(String startDt, String endDt)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		try {
			String sql = "SELECT "
					
					+ "inf.updatedUser, "
					+ "(SELECT tm.value from TMetadata tm "
					+ "where tm.lookupCode = '"+APIConstant.LOOKUP_CODE_FOLLOWUP_EMI_NOTE+"' and tm.lookupCodeId = inf.statusCode) as followup_note, "
					+ "inf.remarks, "
					+ "mas.customer_phone_no, mas.loan_no, mas.customer_name, mas.collection_account, "
					+ "mas.last_payment_bank_ref, mas.bank_narration, mas.bank_credit_amount, "
					+ "mas.transaction_date, mas.partner_bank, mas.last_due_date, "
					+ "inf.updatedDt "
					+ "from TOmsFCLFollowEMIInf inf left join TOmsFCLLmsMas mas on inf.loanNo = mas.loan_no "
					+ "where to_date(to_char(inf.updatedDt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') between :startDt and :endDt "
					+ "and UPPER(mas.loan_status) = :loan_status "
					;
			
			String orderBy = " order by inf.updatedDt asc";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_ACTIVE);
			
			List<Object[]> list = query.getResultList();
			if(CollectionUtils.isEmpty(list)) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			return list;
		} catch (ServiceInvalidAgurmentException ex) {
			throw new ServiceInvalidAgurmentException(ex.getMessage());
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
}
