/**
 * 
 */
package com.shinhan.fcl.common;

import java.util.Hashtable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

import com.shinhan.fcl.repository.entity.TMetadata;



/**
 * @author shds01
 *
 */

public abstract class AbstractRepositoryClass {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public Environment env;

	@PersistenceContext(unitName = "entityManagerOMS")
	public EntityManager entityManager;

	@Autowired
	private RepositoryManagerService repositoryManagerService;

	@Autowired
	public OracleOMSNamedQueries oracleOMSNamedQueries;

	/**
	 * @return the repositoryManagerService
	 */
	public RepositoryManagerService getRepositoryManagerService() {
		return repositoryManagerService;
	}

	/**
	 * @param repositoryManagerService the repositoryManagerService to set
	 */
	public void setRepositoryManagerService(
			@Qualifier("repositoryManagerService") RepositoryManagerService repositoryManagerService) {
		this.repositoryManagerService = repositoryManagerService;
	}
	
	public static Hashtable<String, TMetadata> hashItembyName(List<TMetadata> items) {
		Hashtable<String, TMetadata> ht = new Hashtable<String, TMetadata>();
		if (items != null && items.size() >= 0) {
			for (TMetadata item : items) {
				ht.put(item.getLookupCodeId(), item);
			}
		}
		return ht;
	}

}
