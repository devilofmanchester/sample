/**
 * 
 */
package com.shinhan.migrate.repository.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.shinhan.migrate.common.AbstractServiceClass;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.repository.dao.TOmsReconLmsInfDAO;
import com.shinhan.migrate.repository.entity.TOmsReconLmsInf;
import com.shinhan.migrate.repository.service.TOmsReconLmsInfManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("tomsReconLmsInfManagerRepositoryService")
public class TOmsReconLmsInfManagerRepositoryServiceImpl extends AbstractServiceClass
		implements TOmsReconLmsInfManagerRepositoryService {

	private TOmsReconLmsInfDAO objectDao;

	@Autowired
	public TOmsReconLmsInfManagerRepositoryServiceImpl(TOmsReconLmsInfDAO objectDao) {
		this.objectDao = objectDao;
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconLmsInfManagerRepositoryService#
	 * createAll(java.util.Map)
	 */
	@Override
	public boolean createAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconLmsInf> items = (List<TOmsReconLmsInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public List<TOmsReconLmsInf> getListLmsTrxMatchWithRepTrx(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconLmsInf> list = new ArrayList<>();
		BigDecimal drAmt = new BigDecimal(inputParams.get(APIConstant._DR_AMT_KEY) == null ? "0" :inputParams.get(APIConstant._DR_AMT_KEY).toString() );
		String sql = oracleOMSNamedQueries.get("getListLmsTrxMatchWithRepTrx");
		Query query = entityManager.createNativeQuery(sql,TOmsReconLmsInf.class);
		
		query.setParameter(APIConstant._BANK_CODE_KEY,inputParams.get(APIConstant._BANK_CODE_KEY).toString());
		query.setParameter(APIConstant._REF_NO_KEY,inputParams.get(APIConstant._REF_NO_KEY).toString());
		query.setParameter(APIConstant.LOAN_NO_KEY,inputParams.get(APIConstant.LOAN_NO_KEY).toString());
		query.setParameter(APIConstant._DR_AMT_KEY,drAmt);
		list = query.getResultList();
		return list;
	}
	@Override
	public List<TOmsReconLmsInf> getListLmsTrxMatchWithRevTrx(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconLmsInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getListLmsTrxMatchWithRevTrx");
		BigDecimal crAmt = new BigDecimal(inputParams.get(APIConstant._CR_AMT_KEY) == null ? "0" :inputParams.get(APIConstant._CR_AMT_KEY).toString() );
		Query query = entityManager.createNativeQuery(sql,TOmsReconLmsInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,inputParams.get(APIConstant._BANK_CODE_KEY).toString());
		query.setParameter(APIConstant._REF_NO_KEY,inputParams.get(APIConstant._REF_NO_KEY).toString());
		query.setParameter(APIConstant.LOAN_NO_KEY,inputParams.get(APIConstant.LOAN_NO_KEY).toString());
		query.setParameter(APIConstant._CR_AMT_KEY,crAmt);
		list = query.getResultList();
		return list;
	}
	
	@Override
	public List<TOmsReconLmsInf> getListLMSMatchedListRepTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		@SuppressWarnings("unchecked")
		List<String> loanNoLst = (List<String>) inputParams.get(APIConstant.LOAN_NO_KEY);
		List<String> bankLst = (List<String>) inputParams.get(APIConstant._BANK_CODE_KEY);
		List<String> refLst = (List<String>) inputParams.get(APIConstant._REF_NO_KEY);
		List<BigDecimal> amtLst = (List<BigDecimal>) inputParams.get(APIConstant._DR_AMT_KEY);
		
		int limit = Integer.valueOf(env.getProperty(APIConstant.DATA_LIMIT_CONDTION_SEARCHING_IN));
		int sizes = loanNoLst.size();
		if(sizes >= limit) {
			int times = sizes / limit;
			int start = 0;
			int end = limit;
			List<TOmsReconLmsInf> rs = new ArrayList<TOmsReconLmsInf>();
			for(int i = 0; i <= times; i++) {
				List<String> loanNoList = loanNoLst.subList(start, end);
				List<String> bankList = bankLst.subList(start, end);
				List<String> refList = refLst.subList(start, end);
				List<BigDecimal> amtList = amtLst.subList(start, end);
				
				rs.addAll(objectDao.findAll(new Specification<TOmsReconLmsInf>() {
					/**
					 * 
					 */
					private static final long serialVersionUID = 4026019747432813696L;

					@Override
					public Predicate toPredicate(Root<TOmsReconLmsInf> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
						List<Predicate> predicates = new ArrayList<>();
						if (CollectionUtils.isNotEmpty(loanNoList)) {
							predicates.add(root.get("loanNo").in(loanNoList));
							predicates.add(root.get("bankCode").in(bankList));
							predicates.add(root.get("refNo").in(refList));
							predicates.add(root.get("drAmt").in(amtList));
						}
						
						return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
					}
				}));
				
				start += limit;
				end += limit;
				if(end > sizes) {
					end = sizes;
				}
			}
			return rs;
			
		} else {
			return objectDao.findAll(new Specification<TOmsReconLmsInf>() {
				/**
				 * 
				 */
				private static final long serialVersionUID = 4026019747432813696L;

				@Override
				public Predicate toPredicate(Root<TOmsReconLmsInf> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();
					if (CollectionUtils.isNotEmpty(loanNoLst)) {
						predicates.add(root.get("loanNo").in(loanNoLst));
						predicates.add(root.get("bankCode").in(bankLst));
						predicates.add(root.get("refNo").in(refLst));
						predicates.add(root.get("drAmt").in(amtLst));
					}
					
					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});
		}
	}
	@Override
	public List<TOmsReconLmsInf> getListLMSMatchedListRevTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		@SuppressWarnings("unchecked")
		List<String> loanNoLst = (List<String>) inputParams.get(APIConstant.LOAN_NO_KEY);
		List<String> bankLst = (List<String>) inputParams.get(APIConstant._BANK_CODE_KEY);
		List<String> refLst = (List<String>) inputParams.get(APIConstant._REF_NO_KEY);
		List<BigDecimal> amtLst = (List<BigDecimal>) inputParams.get(APIConstant._DR_AMT_KEY);
		
		int limit = Integer.valueOf(env.getProperty(APIConstant.DATA_LIMIT_CONDTION_SEARCHING_IN));
		int sizes = loanNoLst.size();
		if(sizes >= limit) {
			int times = sizes / limit;
			int start = 0;
			int end = limit;
			List<TOmsReconLmsInf> rs = new ArrayList<TOmsReconLmsInf>();
			for(int i = 0; i <= times; i++) {
				List<String> loanNoList = loanNoLst.subList(start, end);
				List<String> bankList = bankLst.subList(start, end);
				List<String> refList = refLst.subList(start, end);
				List<BigDecimal> amtList = amtLst.subList(start, end);
				
				rs.addAll(objectDao.findAll(new Specification<TOmsReconLmsInf>() {
					/**
					 * 
					 */
					private static final long serialVersionUID = 4026019747432813696L;
					
					@Override
					public Predicate toPredicate(Root<TOmsReconLmsInf> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
						List<Predicate> predicates = new ArrayList<>();
						if (CollectionUtils.isNotEmpty(loanNoList)) {
							predicates.add(root.get("loanNo").in(loanNoList));
							predicates.add(root.get("bankCode").in(bankList));
							predicates.add(root.get("refNo").in(refList));
							predicates.add(root.get("drAmt").in(amtList));
						}
						
						return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
					}
				}));
				
				start += limit;
				end += limit;
				if(end > sizes) {
					end = sizes;
				}
			}
			return rs;
			
		} else {
			return objectDao.findAll(new Specification<TOmsReconLmsInf>() {
				/**
				 * 
				 */
				private static final long serialVersionUID = 4026019747432813696L;
				
				@Override
				public Predicate toPredicate(Root<TOmsReconLmsInf> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();
					if (CollectionUtils.isNotEmpty(loanNoLst)) {
						predicates.add(root.get("loanNo").in(loanNoLst));
						predicates.add(root.get("bankCode").in(bankLst));
						predicates.add(root.get("refNo").in(refLst));
						predicates.add(root.get("crAmt").in(amtLst));
					}
					
					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});
		}
	}

}
