package com.shinhan.migrate.repository.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "PROJ_PAYMENT")
public class TOmsProjPmtInf {
	
	private Long id;
	private String CD;
	private String value;
	private String hashValue;
	private Date regisDate;
	private String status;
	private String serviceName;
	public TOmsProjPmtInf() {
		super();
	}
	public TOmsProjPmtInf(Long id, String cD, String value, Date regisDate, String hashValue, String status,String serviceName) {
		super();
		this.id = id;
		CD = cD;
		this.value = value;
		this.regisDate = regisDate;
		this.hashValue = hashValue;
		this.status =status;
		this.serviceName = serviceName;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PROJ_PAYMENT_SEQ_GEN")
	@SequenceGenerator(name = "PROJ_PAYMENT_SEQ_GEN", sequenceName = "PROJ_PAYMENT_SEQ", allocationSize = 1)
	@Column(name = "ID")
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@Column(name = "CD")
	public String getCD() {
		return CD;
	}
	public void setCD(String cD) {
		CD = cD;
	}
	
	@Lob
	@Column(name = "VALUE")
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	@Column(name = "REGIS_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getRegisDate() {
		return regisDate;
	}
	public void setRegisDate(Date regisDate) {
		this.regisDate = regisDate;
	}
	@Column(name = "HASH_VALUE")
	public String getHashValue() {
		return hashValue;
	}
	public void setHashValue(String hashValue) {
		this.hashValue = hashValue;
	}
	@Column(name = "STATUS")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Column(name = "SERVICE_NAME")
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
}
