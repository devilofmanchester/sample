/**
 * 
 */
package com.shinhan.migrate.api.controller;

import java.util.Locale;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;

/**
 * @author shds01
 *
 */
@RestController
public class UtilityController extends BaseController{

	
	@RequestMapping(value = "shinhan/common/connection", method = RequestMethod.GET)
	public ResponseEntity<Object> testGet() throws ServiceRuntimeException, InterruptedException {
		return triggerSuccessOutPut(null, JsonObject.class, "connect server successfully");
	}

	@RequestMapping(value = "shinhan/common/exception", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	@ResponseBody
	public String testException(Locale locale) throws BaseException {
		testException();
		return "Success";
	}
	
}
