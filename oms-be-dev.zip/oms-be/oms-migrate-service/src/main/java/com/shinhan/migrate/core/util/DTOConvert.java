/**
 * 
 */
package com.shinhan.migrate.core.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.core.model.LMStemplateInfor;
import com.shinhan.migrate.core.model.TemplateInfor;
import com.shinhan.migrate.repository.entity.TOmsProjPmtInf;
import com.shinhan.migrate.repository.entity.TOmsReconLmsInf;
import com.shinhan.migrate.repository.entity.TOmsReconSuspenseInf;

/**
 * @author shds01
 *
 */
public class DTOConvert {

	public static List<?> convertSettoList(Set<?> sets) throws ServiceRuntimeException {
		List<?> list = new ArrayList<>(sets);
		return list;
	}

	public static void setUtilityTOmsProjInf(TOmsProjPmtInf item, String CD, String value, String serviceName) throws Exception {
		item.setCD(CD);
		Gson gson = new GsonBuilder().create();
		JsonElement el = JsonParser.parseString(value);
		item.setValue(gson.toJson(el));
		item.setRegisDate(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		item.setHashValue(CommonUtil.hashMD5(value));
		item.setServiceName(serviceName);
		item.setStatus(APIConstant._PROCESS_STATUS_PENDING);
	}
	
	public static List<TOmsReconLmsInf> getLMSListFromInf(List<LMStemplateInfor> items, String CD){
		
		List<TOmsReconLmsInf> rs = new ArrayList<>();
		
		for (LMStemplateInfor item : items) {
			
			TOmsReconLmsInf tOmsReconLmsInf = new TOmsReconLmsInf();
			
			if(CD.equals(APIConstant._LMS_TRX_TYPE_DISB_)) {
				tOmsReconLmsInf.setTransactionType(APIConstant._BANK_TYPE_DISB);
			}else {
				tOmsReconLmsInf.setTransactionType(APIConstant._BANK_TYPE_REP);
			}
			
			if( CD.equals(APIConstant._LMS_TRX_TYPE_DISB_) || CD.equals(APIConstant._LMS_TRX_TYPE_REV_) ) {
				tOmsReconLmsInf.setCrAmt(item.getReceiptAmt());
				tOmsReconLmsInf.setDrAmt(APIConstant.DEC_ZERO);
			}else if(CD.equals(APIConstant._LMS_TRX_TYPE_REP_)) {
				tOmsReconLmsInf.setDrAmt(item.getReceiptAmt());
				tOmsReconLmsInf.setCrAmt(APIConstant.DEC_ZERO);
			}
			
			tOmsReconLmsInf.setBankCode(item.getBankCode());
			tOmsReconLmsInf.setCif(item.getCustNo());
			tOmsReconLmsInf.setLoanNo(item.getLoanNo());
			tOmsReconLmsInf.setPaymode(item.getPaymentMode());
			tOmsReconLmsInf.setRefNo(item.getRefNo());
			tOmsReconLmsInf.setRemark(item.getRefNo());
			tOmsReconLmsInf.setTrxDt(item.getTrxDt());
			tOmsReconLmsInf.setValueDt(item.getValDt());
			tOmsReconLmsInf.setStatusCode(APIConstant._STATUS_PENDING);
			tOmsReconLmsInf.setCreatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
			tOmsReconLmsInf.setUpdatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
			tOmsReconLmsInf.setCreatedUser(APIConstant._OMS_RECONBATCH_);
			tOmsReconLmsInf.setUpdatedUser(APIConstant._OMS_RECONBATCH_);
			rs.add(tOmsReconLmsInf);
		}
		return rs;
		
	}
	public static TOmsReconLmsInf getLMSFromInf(LMStemplateInfor item, String CD){
		
		TOmsReconLmsInf tOmsReconLmsInf = new TOmsReconLmsInf();
			
		if(CD.equals(APIConstant._LMS_TRX_TYPE_DISB_)) {
			tOmsReconLmsInf.setTransactionType(APIConstant._BANK_TYPE_DISB);
		}else {
			tOmsReconLmsInf.setTransactionType(APIConstant._BANK_TYPE_REP);
		}
		
		if( CD.equals(APIConstant._LMS_TRX_TYPE_DISB_) || CD.equals(APIConstant._LMS_TRX_TYPE_REV_) ) {
			tOmsReconLmsInf.setCrAmt(item.getReceiptAmt());
			tOmsReconLmsInf.setDrAmt(APIConstant.DEC_ZERO);
		}else if(CD.equals(APIConstant._LMS_TRX_TYPE_REP_)) {
			tOmsReconLmsInf.setDrAmt(item.getReceiptAmt());
			tOmsReconLmsInf.setCrAmt(APIConstant.DEC_ZERO);
		}
		
		tOmsReconLmsInf.setBankCode(item.getBankCode());
		tOmsReconLmsInf.setCif(item.getCustNo());
		tOmsReconLmsInf.setLoanNo(item.getLoanNo());
		tOmsReconLmsInf.setPaymode(item.getPaymentMode());
		tOmsReconLmsInf.setRefNo(item.getRefNo());
		tOmsReconLmsInf.setRemark(item.getRemark());
		tOmsReconLmsInf.setTrxDt(item.getTrxDt());
		tOmsReconLmsInf.setValueDt(item.getValDt());
		tOmsReconLmsInf.setStatusCode(APIConstant._STATUS_PENDING);
		tOmsReconLmsInf.setCreatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		tOmsReconLmsInf.setUpdatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		tOmsReconLmsInf.setCreatedUser(APIConstant._OMS_RECONBATCH_);
		tOmsReconLmsInf.setUpdatedUser(APIConstant._OMS_RECONBATCH_);
		return tOmsReconLmsInf;
		
	}
	public static TOmsReconLmsInf getLMSDuplicateFromInf(LMStemplateInfor item, String CD){
		
		TOmsReconLmsInf tOmsReconLmsInf = new TOmsReconLmsInf();
		
		if(CD.equals(APIConstant._LMS_TRX_TYPE_DISB_)) {
			tOmsReconLmsInf.setTransactionType(APIConstant._BANK_TYPE_DISB);
		}else {
			tOmsReconLmsInf.setTransactionType(APIConstant._BANK_TYPE_REP);
		}
		
		if( CD.equals(APIConstant._LMS_TRX_TYPE_DISB_) || CD.equals(APIConstant._LMS_TRX_TYPE_REV_) ) {
			tOmsReconLmsInf.setCrAmt(item.getReceiptAmt());
			tOmsReconLmsInf.setDrAmt(APIConstant.DEC_ZERO);
		}else if(CD.equals(APIConstant._LMS_TRX_TYPE_REP_)) {
			tOmsReconLmsInf.setDrAmt(item.getReceiptAmt());
			tOmsReconLmsInf.setCrAmt(APIConstant.DEC_ZERO);
		}
		
		tOmsReconLmsInf.setBankCode(item.getBankCode());
		tOmsReconLmsInf.setCif(item.getCustNo());
		tOmsReconLmsInf.setLoanNo(item.getLoanNo());
		tOmsReconLmsInf.setPaymode(item.getPaymentMode());
		tOmsReconLmsInf.setRefNo(item.getRefNo());
		tOmsReconLmsInf.setRemark(item.getRemark());
		tOmsReconLmsInf.setTrxDt(item.getTrxDt());
		tOmsReconLmsInf.setValueDt(item.getValDt());
		tOmsReconLmsInf.setStatusCode(APIConstant._STATUS_DUPLICATE);
		tOmsReconLmsInf.setRemarkNote(APIConstant._DUPLICATE_NOTE);
		tOmsReconLmsInf.setCreatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		tOmsReconLmsInf.setUpdatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		tOmsReconLmsInf.setCreatedUser(APIConstant._OMS_RECONBATCH_);
		tOmsReconLmsInf.setUpdatedUser(APIConstant._OMS_RECONBATCH_);
		return tOmsReconLmsInf;
		
	}
	public static TOmsReconSuspenseInf getSuspRevertFromInf(LMStemplateInfor item, String CD){
		
		TOmsReconSuspenseInf tOmsReconLmsInf = new TOmsReconSuspenseInf();
		
		tOmsReconLmsInf.setBankCode(item.getBankCode());
		tOmsReconLmsInf.setLoanNo(item.getLoanNo());
		tOmsReconLmsInf.setRefNo(item.getRefNo());
		tOmsReconLmsInf.setRemark(item.getRefNo());
		tOmsReconLmsInf.setTrxDt(item.getTrxDt());
		tOmsReconLmsInf.setConfirmYn(APIConstant.NO_KEY);
		tOmsReconLmsInf.setCrAmt(APIConstant.DEC_ZERO);
		tOmsReconLmsInf.setDrAmt(item.getReceiptAmt());
		tOmsReconLmsInf.setLedgerType(APIConstant._LMS_TRX_TYPE_REV_);
		tOmsReconLmsInf.setStatusCode(APIConstant._STATUS_PENDING);
		tOmsReconLmsInf.setPayMode(item.getPaymentMode());
		tOmsReconLmsInf.setRefIdFileMas( (long) 1 );
		tOmsReconLmsInf.setCreatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		tOmsReconLmsInf.setUpdatedDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
		tOmsReconLmsInf.setCreateUser(APIConstant._OMS_RECONBATCH_);
		tOmsReconLmsInf.setUpdatedUser(APIConstant._OMS_RECONBATCH_);
		return tOmsReconLmsInf;
		
	}
	
	public static List<LMStemplateInfor> getLMStempFromInfo(List<TemplateInfor> items, String CD){
		
		List<LMStemplateInfor> rs = new ArrayList<>();
		for (TemplateInfor item : items) {
			
			LMStemplateInfor lms = new LMStemplateInfor();
			lms.setBankCode(item.getBankCode());
			lms.setBankName(item.getBankName());
			lms.setCustNo(item.getCustNo());
			lms.setLoanNo(item.getLoanNo());
			lms.setPaymentMode(item.getPaymentMode());
			lms.setRefNo(item.getRefNo());
			lms.setRemark(item.getRemark());
			lms.setReceiptAmt(( StringUtils.isBlank(item.getReceiptAmt()) ? APIConstant.DEC_ZERO : new BigDecimal(item.getReceiptAmt())));
//			if(  CD.equals(APIConstant._LMS_TRX_TYPE_REV_) ) {
//				lms.setReceiptAmt(( StringUtils.isBlank(item.getCreditAmt()) ? APIConstant.DEC_ZERO : new BigDecimal(item.getCreditAmt())));
//				
//			}else 
			if(CD.equals(APIConstant._LMS_TRX_TYPE_REP_) || CD.equals(APIConstant._LMS_TRX_TYPE_REV_) ) {
				lms.setReceiptAmt(( StringUtils.isBlank(item.getReceiptAmt()) ? APIConstant.DEC_ZERO : new BigDecimal(item.getReceiptAmt())));
			}else if(CD.equals(APIConstant._LMS_TRX_TYPE_DISB_)) {
				lms.setReceiptAmt(( StringUtils.isBlank(item.getDebitAmt()) ? APIConstant.DEC_ZERO : new BigDecimal(item.getDebitAmt())));
			}
			if(DateUtils.isValidate(item.getTrxDt())) {
				lms.setTrxDt(DateUtils.convertDate(item.getTrxDt(), DateUtils.getValidFormat(item.getTrxDt()), DateUtils.DATEFORMAT,false));
				
			}else {
				lms.setRemark( APIConstant.THE_DATA_INCORRECT_FORMAT_ERROR );
				lms.setTrxDt(new Date());
			}
			if(DateUtils.isValidate(item.getValDt())) {
				lms.setValDt(DateUtils.convertDate(item.getValDt(), DateUtils.getValidFormat(item.getValDt()), DateUtils.DATEFORMAT,false));
				
			}else {
				lms.setRemark( APIConstant.THE_DATA_INCORRECT_FORMAT_ERROR );
				lms.setValDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
			}
			
			rs.add(lms);
		}
		
		return rs;
		
	}
	
}
