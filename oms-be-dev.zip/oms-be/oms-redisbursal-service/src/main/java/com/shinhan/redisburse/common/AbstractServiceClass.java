/**
 * 
 */
package com.shinhan.redisburse.common;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

import com.shinhan.redisburse.core.exception.BaseException;
import com.shinhan.redisburse.core.constant.APIConstant;
import com.shinhan.redisburse.core.exception.ServiceRuntimeException;
import com.shinhan.redisburse.core.model.BankReDisbursalInf;
import com.shinhan.redisburse.core.util.DTOConvert;
import com.shinhan.redisburse.core.util.WriteToExcelTemplate;


/**
 * @author shds01
 *
 */
public abstract class AbstractServiceClass extends AbstractRepositoryClass{

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	public Environment env;
	
	@Autowired
	private ProcessManagerService processManagerService;

	@Autowired
	private ValidationManagerService validationManagerService;
	
	/**
	 * @return the processManagerService
	 */
	public ProcessManagerService getProcessManagerService() {
		return processManagerService;
	}

	/**
	 * @param processManagerService the processManagerService to set
	 */
	public void setProcessManagerService(@Qualifier("processManagerService") ProcessManagerService processManagerService) {
		this.processManagerService = processManagerService;
	}
	
	/**
	 * @return the validationManagerService
	 */
	public ValidationManagerService getValidationManagerService() {
		return validationManagerService;
	}

	/**
	 * @param validationManagerService the validationManagerService to set
	 */
	public void setValidationManagerService(@Qualifier("validationManagerService")
		ValidationManagerService validationManagerService) {
		this.validationManagerService = validationManagerService;
	}
	
	public File exportRedisbursalReport(Map<String, Object> inputParams, String bankCode) throws BaseException {
		String fileSource = env.getProperty(APIConstant.FOLDER_TEMPLATE_REPORT) + "/" + APIConstant.FILE_BANK_TEMPLATE_REPORT_IN;
		String fileDestinationExport = env.getProperty(APIConstant.FOLDER_EXPORT_REPORT) + "/"+ APIConstant.FILE_BANK_TEMPLATE_REPORT_EXPORT + APIConstant.FILE_TYPE_EXCEL_NEW; ;
		
		List<BankReDisbursalInf> items = (List<BankReDisbursalInf>)inputParams.get(APIConstant.DOCUMENT);
		List<Object[]> arrList = new ArrayList<>();
		for (BankReDisbursalInf item : items) {
			Object[] arr = new  Object[9];
			if(item.getRedisbType().equals(APIConstant._REDISB_CUSTOMER)) {
				item.setLoanNo(item.getLoanNo() + "A");
			}else {
				item.setLoanNo(item.getLoanNo() + "LA");
			}
			arrList.add(DTOConvert.getArrObjFromRedisbInf(item));
		}
		Workbook wb = loadTemplate(fileSource, 1, "data",arrList);
		
		WriteToExcelTemplate.writeWorkbook(wb, fileDestinationExport);
		File file = new File(fileDestinationExport);
		if(!file.exists()) {
			throw new ServiceRuntimeException(env.getProperty("MSG_004"));
		}
		return file;
		
	}
	
	private Workbook loadTemplate(String fileSource, int fromRow, String sheetName, List<Object[]> datas) {
		return WriteToExcelTemplate.fillDataToSheetTemplate(fileSource, null, sheetName, fromRow, datas);
	}
	
}







