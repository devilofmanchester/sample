/**
 * 
 */
package com.shinhan.fcl.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.service.FormApiService;

/**
 * @author shds01
 *
 */

@Service("formApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class FormApiServiceImpl extends AbstractBasicCommonClass implements FormApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#getListFormAvailable(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListFormAvailable(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getFormManagerRepositoryService().getListFormAvailable(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#countFormAvailableTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countFormAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getFormManagerRepositoryService().countFormAvailableTrx(inputParams);
	}

}
