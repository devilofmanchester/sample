/**
 * 
 */
package com.shinhan.fcl.core.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.model.WaiveOffDocumentTrx;
import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIInf;
import com.shinhan.fcl.repository.entity.TOmsFCLLmsMas;
import com.shinhan.fcl.repository.entity.TOmsFCLMaturitynf;

/**
 * @author shds01
 *
 */
public class DTOConverter {

	public static List<?> convertSettoList(Set<?> sets) throws ServiceRuntimeException {
		List<?> list = new ArrayList<>(sets);
		return list;
	}
	
	public static void populateDataExecuteWaive(EarlyTerminationTrx trx, TOmsFCLLmsMas mas) {
		trx.setCif(mas.getCif());
		
		trx.setRepayment_amount(mas.getRepayment_amount());
		trx.setPenalty_fees(mas.getPenalty_fees());
		
		trx.setInterest_amount(mas.getInterest_amount());
		trx.setLast_change_amount(mas.getLast_change_amount());
		trx.setOverdue_fee(mas.getOverdue_fee());
	}
	
	public static WaiveOffDocumentTrx populateDataExecuteWaiveForWaiveOffDocumentTrx(EarlyTerminationTrx trx) {
		WaiveOffDocumentTrx doc = new WaiveOffDocumentTrx(trx.getLoan_no(), trx.getCif(), DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		
		BigDecimal int_amt_original = trx.getInterest_amount();
		BigDecimal lpp_amt_original = trx.getLast_change_amount();
		BigDecimal odf_amt_original = trx.getOverdue_fee();
		BigDecimal repayment_amt_original = trx.getRepayment_amount();
		BigDecimal penalty_fees_original = trx.getPenalty_fees();
		
		BigDecimal total_waiveOff = int_amt_original.add(lpp_amt_original).add(odf_amt_original);
		BigDecimal total_repayment = repayment_amt_original.subtract(penalty_fees_original);
		
		if(total_waiveOff.compareTo(total_repayment) <= 0 ) {
			//Set original no need to calculate
			doc.setLpp_amt(CommonUtil.writeDecimal(lpp_amt_original.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
			doc.setInt_amt(CommonUtil.writeDecimal(int_amt_original.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
			doc.setOverdue_amt(CommonUtil.writeDecimal(odf_amt_original.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
			
			doc.setTotal_amt(CommonUtil.writeDecimal(total_waiveOff.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
		} else {
			if(lpp_amt_original.compareTo(total_repayment) >= 0) {
				//Set new lpp = total_repayment, another is zero
				doc.setLpp_amt(CommonUtil.writeDecimal(total_repayment.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
				doc.setInt_amt(CommonUtil.writeDecimal(APIConstant.DEC_ZERO.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
				doc.setOverdue_amt(CommonUtil.writeDecimal(APIConstant.DEC_ZERO.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
				
				doc.setTotal_amt(doc.getLpp_amt());
			} else {
				if(lpp_amt_original.add(odf_amt_original).compareTo(total_repayment) >= 0) {
					//Set new lpp = current lpp, new odf = total_repayment - lpp, int = zero
					doc.setLpp_amt(CommonUtil.writeDecimal(lpp_amt_original.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
					doc.setOverdue_amt(CommonUtil.writeDecimal(total_repayment.subtract(lpp_amt_original).doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
					doc.setInt_amt(CommonUtil.writeDecimal(APIConstant.DEC_ZERO.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
					
					doc.setTotal_amt(CommonUtil.writeDecimal(total_repayment.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
				} else {
					//Set new lpp = current lpp, new odf = current odf, int = total_repayment - lpp - odf
					doc.setLpp_amt(CommonUtil.writeDecimal(lpp_amt_original.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
					doc.setInt_amt(CommonUtil.writeDecimal(total_repayment.subtract(lpp_amt_original).subtract(odf_amt_original).doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
					doc.setOverdue_amt(CommonUtil.writeDecimal(odf_amt_original.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
					
					doc.setTotal_amt(CommonUtil.writeDecimal(total_repayment.doubleValue(), APIConstant.FORMAT_FACTOR_PERCENT).replace(APIConstant.COMMA, APIConstant.DOT));
				}
			}
		}
		
		return doc;
	}

	public static TOmsFCLFollowEMIInf populateDataUpdateNoteFollowUpEMINew(EarlyTerminationTrx trx, String userName) {
		TOmsFCLFollowEMIInf inf = new TOmsFCLFollowEMIInf();
		
		inf.setLoanNo(trx.getLoan_no());
		inf.setStatusCode(trx.getFollowup_note());
		inf.setRemarks(trx.getRemarks());
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsFCLFollowEMIInf populateDataUpdateNoteFollowUpEMIUpdate(EarlyTerminationTrx trx, TOmsFCLFollowEMIInf inf, String userName) {
		
		inf.setStatusCode(trx.getFollowup_note());
		inf.setRemarks(trx.getRemarks());
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsFCLMaturitynf populateDataExecuteWaiveMaturityWaiveOffIncNew(EarlyTerminationTrx trx, String userName) {
		TOmsFCLMaturitynf inf = new TOmsFCLMaturitynf();
		
		inf.setLoanNo(trx.getLoan_no());
		
		inf.setStatusCode(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_WAIVEOFF_VALUE);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static TOmsFCLMaturitynf populateDataExecuteDoneMaturityBookIncNew(EarlyTerminationTrx trx, String userName) {
		TOmsFCLMaturitynf inf = new TOmsFCLMaturitynf();
		
		inf.setLoanNo(trx.getLoan_no());
		
		inf.setStatusCode(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static void populateDataExecuteDoneMaturityBookIncUpdate(TOmsFCLMaturitynf inf, String userName) {
		
		inf.setStatusCode(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setUpdatedUser(userName);
	}
	
	public static TOmsFCLMaturitynf populateDataExecuteDoneMaturityRefundNew(EarlyTerminationTrx trx, String userName) {
		TOmsFCLMaturitynf inf = new TOmsFCLMaturitynf();
		
		inf.setLoanNo(trx.getLoan_no());
		inf.setStatusCode(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
		inf.setRpa_amount(trx.getRpa_amount());
		
		inf.setCreatedDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setCreatedUser(userName);
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setUpdatedUser(userName);
		
		return inf;
	}
	
	public static void populateDataExecuteDoneMaturityRefundUpdate(TOmsFCLMaturitynf inf, EarlyTerminationTrx trx, String userName) {
		
		inf.setStatusCode(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
		inf.setRpa_amount(trx.getRpa_amount());
		
		inf.setUpdatedDt(DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
		inf.setUpdatedUser(userName);
	}
	
}