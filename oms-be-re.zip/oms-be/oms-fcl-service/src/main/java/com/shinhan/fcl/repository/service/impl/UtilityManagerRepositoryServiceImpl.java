/**
 * 
 */
package com.shinhan.fcl.repository.service.impl;

import java.util.List;

import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.fcl.common.AbstractServiceClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.repository.dao.TMetadataDAO;
import com.shinhan.fcl.repository.dao.TOmsFCLLmsMasDAO;
import com.shinhan.fcl.repository.entity.TMetadata;
import com.shinhan.fcl.repository.entity.TOmsFCLLmsMas;
import com.shinhan.fcl.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("utilityManagerRepositoryService")
public class UtilityManagerRepositoryServiceImpl extends AbstractServiceClass
		implements UtilityManagerRepositoryService {

	private TMetadataDAO objectMetaDao;

	private TOmsFCLLmsMasDAO objectMasDao;
	
	@Autowired
	public UtilityManagerRepositoryServiceImpl(TMetadataDAO objectMetaDao, TOmsFCLLmsMasDAO objectMasDao) {
		this.objectMetaDao = objectMetaDao;
		this.objectMasDao = objectMasDao;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.UtilityManagerRepositoryService#getMetadataById(java.lang.Long)
	 */
	@Override
	public TMetadata getMetadataById(Long id) throws ServiceRuntimeException {
		return objectMetaDao.findById(id).get(); 
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.fcl.repository.service.UtilityManagerRepositoryService#
	 * getMetadataByLookupCode(java.lang.String)
	 */
	@Override
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws ServiceRuntimeException {
		String sql = oracleOMSNamedQueries.get("getMetadataByLookupCode");
		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		
		query.setParameter("SERVICENAME", APIConstant.SERVICENAME_FCL);
		query.setParameter("LOOKUPCODE", lookupCode);
		
		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();

		return list;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.UtilityManagerRepositoryService#getMetadataByLookupCodeAndId(java.lang.String, java.lang.String)
	 */
	@Override
	public TMetadata getMetadataByLookupCodeAndId(String lookupCode, String lookupId) throws ServiceRuntimeException {
		String sql = oracleOMSNamedQueries.get("getMetadataByLookupCodeAndId");

		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		query.setParameter("SERVICENAME", APIConstant.SERVICENAME_FCL);
		query.setParameter("LOOKUPCODE", lookupCode);
		query.setParameter("LOOKUPCODEID", lookupId);

		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();
		if(CollectionUtils.isEmpty(list)) {
			throw new ServiceRuntimeException(String.format(env.getProperty("MSG_007"), lookupId));
		}
		
		return (TMetadata) list.get(0);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.UtilityManagerRepositoryService#getFCLMasTrxByLoanNo(java.lang.String)
	 */
	@Override
	public TOmsFCLLmsMas getFCLMasTrxByLoanNo(String loanNo) throws ServiceRuntimeException {
		if (StringUtils.isBlank(loanNo)) {
			return null;
		}
		try {
			TOmsFCLLmsMas item = objectMasDao.getItemByLoanNo(loanNo);
			return item;
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + loanNo + "");
		}
	
	}
	
}
