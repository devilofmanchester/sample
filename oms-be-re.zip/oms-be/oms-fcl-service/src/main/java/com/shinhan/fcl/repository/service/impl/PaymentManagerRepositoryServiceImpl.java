/**
 * 
 */
package com.shinhan.fcl.repository.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.fcl.common.AbstractServiceClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.util.DateUtils;
import com.shinhan.fcl.repository.dao.TOmsFCLLmsMasDAO;
import com.shinhan.fcl.repository.service.PaymentManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("paymentManagerRepositoryService")
public class PaymentManagerRepositoryServiceImpl extends AbstractServiceClass
		implements PaymentManagerRepositoryService {

	private TOmsFCLLmsMasDAO objectMasDao;

	@Autowired
	public PaymentManagerRepositoryServiceImpl(TOmsFCLLmsMasDAO objectMasDao) {
		this.objectMasDao = objectMasDao;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormManagerRepositoryService#getListPaymentAvailable(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListPaymentAvailable(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String sql = "SELECT new com.shinhan.fcl.core.model.EarlyTerminationTrx("
					
					+ "mas.loan_no, mas.cif, mas.customer_name, mas.rpa_amount, "
					+ "mas.last_payment_amount, mas.last_payment_date, mas.last_payment_bank_ref, mas.last_due_date, '' as remarks "
					
					+ ") "
					+ "from TOmsFCLLmsMas mas "
					+ "where mas.et_form_scan_date is null "
					+ "and UPPER(mas.loan_status) = :loan_status "
					+ "and UPPER(mas.delq_status) in ('REG', 'TB1', 'TB2', 'TB3', 'TB4', 'TB5') "
					+ "and mas.last_due_date > :current_date and mas.last_due_date is not null "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					+ "and (mas.total_outstanding = 0 or mas.total_outstanding is null) "
					
					;
		
			String orderBy = " order by mas.last_payment_date asc";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_ACTIVE);
			
			query.setParameter("current_date", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			@SuppressWarnings("unchecked")
			List<EarlyTerminationTrx> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormManagerRepositoryService#countPaymentAvailableTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countPaymentAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String sql = "select count(*) from oms_fcl_lms_mas mas "
					+ "where mas.et_form_scan_date is null "
					+ "and UPPER(mas.loan_status) = :loan_status "
					+ "and UPPER(mas.delq_status) in ('REG', 'TB1', 'TB2', 'TB3', 'TB4', 'TB5') "
					+ "and mas.last_due_date > :current_date and mas.last_due_date is not null "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					+ "and (mas.total_outstanding = 0 or mas.total_outstanding is null) "
					;
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_ACTIVE);
			
			query.setParameter("current_date", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
}
