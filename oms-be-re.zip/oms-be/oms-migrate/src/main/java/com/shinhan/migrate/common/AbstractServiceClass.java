/**
 * 
 */
package com.shinhan.migrate.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

/**
 * @author shds01
 *
 */
public abstract class AbstractServiceClass extends AbstractRepositoryClass{

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	public Environment env;
	
	@Autowired
	private ProcessManagerService processManagerService;

	/**
	 * @return the processManagerService
	 */
	public ProcessManagerService getProcessManagerService() {
		return processManagerService;
	}

	/**
	 * @param processManagerService the processManagerService to set
	 */
	public void setProcessManagerService(@Qualifier("processManagerService") ProcessManagerService processManagerService) {
		this.processManagerService = processManagerService;
	}
	
	
}







