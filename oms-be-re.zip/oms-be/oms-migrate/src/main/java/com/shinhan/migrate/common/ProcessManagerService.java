/**
 * 
 */
package com.shinhan.migrate.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.shinhan.migrate.service.ReconcileRetreiveApiService;
import com.shinhan.migrate.service.ReconcileRetreiveLmsDataService;

/**
 * @author shds01
 *
 */
@Service("processManagerService")
public class ProcessManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private ReconcileRetreiveLmsDataService reconcileRetreiveLmsDataService;

	@Autowired
	private ReconcileRetreiveApiService reconcileRetreiveApiService;
	
	public ReconcileRetreiveLmsDataService getReconcileRetreiveLmsDataService() {
		return reconcileRetreiveLmsDataService;
	}

	public void setReconcileRetreiveLmsDataService(
			@Qualifier("reconcileRetreiveLmsDataService")	ReconcileRetreiveLmsDataService reconcileRetreiveLmsDataService) {
		this.reconcileRetreiveLmsDataService = reconcileRetreiveLmsDataService;
	}

	public ReconcileRetreiveApiService getReconcileRetreiveApiService() {
		return reconcileRetreiveApiService;
	}

	public void setReconcileRetreiveApiService(
			@Qualifier("reconcileRetreiveApiService")	ReconcileRetreiveApiService reconcileRetreiveApiService) {
		this.reconcileRetreiveApiService = reconcileRetreiveApiService;
	}
	
	
	
}
