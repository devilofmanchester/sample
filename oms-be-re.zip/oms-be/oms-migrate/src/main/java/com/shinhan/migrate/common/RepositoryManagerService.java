/**
 * 
 */
package com.shinhan.migrate.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.shinhan.migrate.repository.service.TOmsReconLmsInfManagerRepositoryService;
import com.shinhan.migrate.repository.service.TOmsReconRetreiveLmsDataRepositoryService;
import com.shinhan.migrate.repository.service.TOmsReconSuspInfManagerRepositoryService;
import com.shinhan.migrate.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("repositoryManagerService")
public class RepositoryManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private UtilityManagerRepositoryService utilityManagerRepositoryService;

	@Autowired
	private TOmsReconLmsInfManagerRepositoryService tomsReconLmsInfManagerRepositoryService;
	
	@Autowired
	private TOmsReconRetreiveLmsDataRepositoryService tOmsReconRetreiveLmsDataRepositoryService;
	
	@Autowired
	private TOmsReconSuspInfManagerRepositoryService tOmsReconSuspInfManagerRepositoryService;
	
	/**
	 * @return the utilityManagerRepositoryService
	 */
	public UtilityManagerRepositoryService getUtilityManagerRepositoryService() {
		return utilityManagerRepositoryService;
	}

	/**
	 * @param utilityManagerRepositoryService the utilityManagerRepositoryService to
	 *                                        set
	 */
	public void setUtilityManagerRepositoryService(
			@Qualifier("utilityManagerRepositoryService") UtilityManagerRepositoryService utilityManagerRepositoryService) {
		this.utilityManagerRepositoryService = utilityManagerRepositoryService;
	}

	
	/**
	 * @return the tomsReconLmsInfManagerRepositoryService
	 */
	public TOmsReconLmsInfManagerRepositoryService getTomsReconLmsInfManagerRepositoryService() {
		return tomsReconLmsInfManagerRepositoryService;
	}

	/**
	 * @param tomsReconLmsInfManagerRepositoryService the
	 *                                                tomsReconLmsInfManagerRepositoryService
	 *                                                to set
	 */
	public void setTomsReconLmsInfManagerRepositoryService(
			@Qualifier("tomsReconLmsInfManagerRepositoryService") TOmsReconLmsInfManagerRepositoryService tomsReconLmsInfManagerRepositoryService) {
		this.tomsReconLmsInfManagerRepositoryService = tomsReconLmsInfManagerRepositoryService;
	}
	
	public TOmsReconRetreiveLmsDataRepositoryService gettOmsReconRetreiveLmsDataRepositoryService() {
		return tOmsReconRetreiveLmsDataRepositoryService;
	}

	public void settOmsReconRetreiveLmsDataRepositoryService(
			@Qualifier("tOmsReconRetreiveLmsDataRepositoryService")	TOmsReconRetreiveLmsDataRepositoryService tOmsReconRetreiveLmsDataRepositoryService) {
		this.tOmsReconRetreiveLmsDataRepositoryService = tOmsReconRetreiveLmsDataRepositoryService;
	}

	public TOmsReconSuspInfManagerRepositoryService gettOmsReconSuspInfManagerRepositoryService() {
		return tOmsReconSuspInfManagerRepositoryService;
	}

	public void settOmsReconSuspInfManagerRepositoryService(
			@Qualifier("tOmsReconSuspInfManagerRepositoryService")	TOmsReconSuspInfManagerRepositoryService tOmsReconSuspInfManagerRepositoryService) {
		this.tOmsReconSuspInfManagerRepositoryService = tOmsReconSuspInfManagerRepositoryService;
	}
	
	
}
