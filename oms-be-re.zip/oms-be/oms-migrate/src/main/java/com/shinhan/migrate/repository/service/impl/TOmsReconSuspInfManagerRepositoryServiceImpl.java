/**
 * 
 */
package com.shinhan.migrate.repository.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.shinhan.migrate.common.AbstractServiceClass;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.repository.dao.TOmsReconSuspInfDAO;
import com.shinhan.migrate.repository.entity.TOmsReconLmsInf;
import com.shinhan.migrate.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.migrate.repository.service.TOmsReconSuspInfManagerRepositoryService;

/**
 * @author shds04
 *
 */
@Service("tOmsReconSuspInfManagerRepositoryService")
public class TOmsReconSuspInfManagerRepositoryServiceImpl extends AbstractServiceClass implements TOmsReconSuspInfManagerRepositoryService {

	private TOmsReconSuspInfDAO objectDao;

	@Autowired
	public TOmsReconSuspInfManagerRepositoryServiceImpl(TOmsReconSuspInfDAO objectDao) {
		this.objectDao = objectDao;
	}

	@Override
	public List<TOmsReconSuspenseInf> getSuspenseByRevertRef(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconSuspenseInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getSuspByRevertRef");
		BigDecimal drAmt = new BigDecimal( inputParams.get(APIConstant._DR_AMT_KEY) == null ? "0" : inputParams.get(APIConstant._DR_AMT_KEY).toString() );
		Query query = entityManager.createNativeQuery(sql,TOmsReconSuspenseInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,inputParams.get(APIConstant._BANK_CODE_KEY).toString());
		query.setParameter(APIConstant._REF_NO_KEY,inputParams.get(APIConstant._REF_NO_KEY).toString());
		query.setParameter(APIConstant.LOAN_NO_KEY,inputParams.get(APIConstant.LOAN_NO_KEY).toString());
		query.setParameter(APIConstant._DR_AMT_KEY,drAmt);
		list = query.getResultList();
		return list;
	}

	@Override
	public boolean create(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconSuspenseInf item = (TOmsReconSuspenseInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean createAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconSuspenseInf> items = (List<TOmsReconSuspenseInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean update(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconSuspenseInf item = (TOmsReconSuspenseInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean updateAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconSuspenseInf> items = (List<TOmsReconSuspenseInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	@Override
	public List<TOmsReconSuspenseInf> getListLMSMatchedListRevTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		@SuppressWarnings("unchecked")
		List<String> loanNoLst = (List<String>) inputParams.get(APIConstant.LOAN_NO_KEY);
		List<String> bankLst = (List<String>) inputParams.get(APIConstant._BANK_CODE_KEY);
		List<String> refLst = (List<String>) inputParams.get(APIConstant._REF_NO_KEY);
		List<BigDecimal> amtLst = (List<BigDecimal>) inputParams.get(APIConstant._DR_AMT_KEY);
		
		int limit = Integer.valueOf(env.getProperty(APIConstant.DATA_LIMIT_CONDTION_SEARCHING_IN));
		int sizes = loanNoLst.size();
		if(sizes >= limit) {
			int times = sizes / limit;
			int start = 0;
			int end = limit;
			List<TOmsReconSuspenseInf> rs = new ArrayList<TOmsReconSuspenseInf>();
			for(int i = 0; i <= times; i++) {
				List<String> loanNoList = loanNoLst.subList(start, end);
				List<String> bankList = bankLst.subList(start, end);
				List<String> refList = refLst.subList(start, end);
				List<BigDecimal> amtList = amtLst.subList(start, end);
				
				rs.addAll(objectDao.findAll(new Specification<TOmsReconSuspenseInf>() {
					/**
					 * 
					 */
					private static final long serialVersionUID = 4026019747432813696L;
					
					@Override
					public Predicate toPredicate(Root<TOmsReconSuspenseInf> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
						List<Predicate> predicates = new ArrayList<>();
						if (CollectionUtils.isNotEmpty(loanNoList)) {
							predicates.add(root.get("loanNo").in(loanNoList));
							predicates.add(root.get("bankCode").in(bankList));
							predicates.add(root.get("refNo").in(refList));
							predicates.add(root.get("drAmt").in(amtList));
						}
						
						return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
					}
				}));
				
				start += limit;
				end += limit;
				if(end > sizes) {
					end = sizes;
				}
			}
			return rs;
			
		} else {
			return objectDao.findAll(new Specification<TOmsReconSuspenseInf>() {
				/**
				 * 
				 */
				private static final long serialVersionUID = 4026019747432813696L;
				
				@Override
				public Predicate toPredicate(Root<TOmsReconSuspenseInf> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();
					if (CollectionUtils.isNotEmpty(loanNoLst)) {
						predicates.add(root.get("loanNo").in(loanNoLst));
						predicates.add(root.get("bankCode").in(bankLst));
						predicates.add(root.get("refNo").in(refLst));
						predicates.add(root.get("drAmt").in(amtLst));
					}
					
					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});
		}
	}
}
