/**
 * 
 */
package com.shinhan.auth.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.auth.common.AbstractBasicCommonClass;
import com.shinhan.auth.core.constant.APIConstant;
import com.shinhan.auth.core.exception.BaseException;
import com.shinhan.auth.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.auth.core.util.CommonUtil;
import com.shinhan.auth.repository.entity.AuthUser;
import com.shinhan.auth.repository.entity.TMetadata;
import com.shinhan.auth.service.UtilityApiService;

/**
 * @author shds01
 *
 */

@Service("utilityApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class UtilityApiServiceImpl extends AbstractBasicCommonClass implements UtilityApiService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.auth.service.UtilityApiService#getAllMetadata(java.lang.
	 * String)
	 */
	@Override
	public List<TMetadata> getAllMetadata(Map<String, Object> inputParams) throws BaseException {
		String lookupCode = inputParams.get(APIConstant._LOOKUP_CODE_KEY).toString();
		String username = inputParams.get(APIConstant.USERNAME_KEY).toString();
		if (APIConstant.ALL.equalsIgnoreCase(lookupCode)) {
			AuthUser authUser = getRepositoryManagerService().getAuthManagerRepositoryService().getAuthenUserProfile(username);
			if(!getRepositoryManagerService().isUserAdmin(authUser)) {
				return getRepositoryManagerService().getUtilityManagerRepositoryService().getAllMetadata(inputParams);
			}
			return getRepositoryManagerService().getUtilityManagerRepositoryService().getAllMetadataByAdmin(inputParams);
		}
		return getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(lookupCode);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.auth.service.UtilityApiService#getMetadataByLookupCode(java.
	 * lang.String)
	 */
	@Override
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws BaseException {
		return getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCode(lookupCode);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.UtilityApiService#createMetadata(java.util.Map)
	 */
	@Override
	public TMetadata createMetadata(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		
		TMetadata item = (TMetadata) CommonUtil.toPojo(document, TMetadata.class);
		getValidationManagerService().checkValidationCreateNewMetadata(item);
		
		getRepositoryManagerService().createNewMetadataToDB(item);
		
		return item;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.UtilityApiService#updateMetadata(java.util.Map)
	 */
	@Override
	public TMetadata updateMetadata(Map<String, Object> inputParams) throws BaseException {
		String document = inputParams.get(APIConstant.DOCUMENT).toString();
		String metaId = inputParams.get(APIConstant.OMSID).toString();
		
		TMetadata itemUpdate = (TMetadata) CommonUtil.toPojo(document, TMetadata.class);
		TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataById(Long.valueOf(metaId));
		
		if(item == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), metaId));
		}
		if(itemUpdate.getId().equals(item.getId()) == false) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_008"));
		}
		
		getRepositoryManagerService().updateMetadataToDB(itemUpdate);
		
		return item;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.auth.service.UtilityApiService#deleteMetadata(java.util.Map)
	 */
	@Override
	public TMetadata deleteMetadata(Map<String, Object> inputParams) throws BaseException {
		String metaId = inputParams.get(APIConstant.OMSID).toString();
		
		TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataById(Long.valueOf(metaId));
		if(item == null) {
			throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_007"), metaId));
		}
		
		if(APIConstant.YES_KEY.equalsIgnoreCase(item.getIsShow())) {
			getRepositoryManagerService().deleteMetadataToDB(item);
		}
		
		return item;
	}


}
