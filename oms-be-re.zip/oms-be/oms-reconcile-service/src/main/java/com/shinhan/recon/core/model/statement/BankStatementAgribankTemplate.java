package com.shinhan.recon.core.model.statement;

public class BankStatementAgribankTemplate {
	
	private String STT;
	private String valueDt;
	private String trxDt;
	private String paymentAccountId;
	private String payeeAccountId;
	private String beforeBalance;
	private String trxType;
	private String trxAmt;
	private String afterBalance;
	private String ccy;
	private String description;
	private String branchNo;
	private String status;
	private String credit;
	private String debit;
	private String ref;
	private String loanNo;
	
	public BankStatementAgribankTemplate() {
		
	}

	public BankStatementAgribankTemplate(String sTT, String valueDt, String trxDt, String paymentAccountId,
			String payeeAccountId, String beforeBalance, String trxType, String trxAmt, String afterBalance, String ccy,
			String description, String branchNo, String status, String credit, String debit, String ref, String loanNo) {
		super();
		STT = sTT;
		this.valueDt = valueDt;
		this.trxDt = trxDt;
		this.paymentAccountId = paymentAccountId;
		this.payeeAccountId = payeeAccountId;
		this.beforeBalance = beforeBalance;
		this.trxType = trxType;
		this.trxAmt = trxAmt;
		this.afterBalance = afterBalance;
		this.ccy = ccy;
		this.description = description;
		this.branchNo = branchNo;
		this.status = status;
		this.credit = credit;
		this.debit = debit;
		this.ref = ref;
		this.loanNo = loanNo;
	}

	public String getSTT() {
		return STT;
	}

	public void setSTT(String sTT) {
		STT = sTT;
	}

	public String getValueDt() {
		return valueDt;
	}

	public void setValueDt(String valueDt) {
		this.valueDt = valueDt;
	}

	public String getTrxDt() {
		return trxDt;
	}

	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}

	public String getPaymentAccountId() {
		return paymentAccountId;
	}

	public void setPaymentAccountId(String paymentAccountId) {
		this.paymentAccountId = paymentAccountId;
	}

	public String getPayeeAccountId() {
		return payeeAccountId;
	}

	public void setPayeeAccountId(String payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}

	public String getBeforeBalance() {
		return beforeBalance;
	}

	public void setBeforeBalance(String beforeBalance) {
		this.beforeBalance = beforeBalance;
	}

	public String getTrxType() {
		return trxType;
	}

	public void setTrxType(String trxType) {
		this.trxType = trxType;
	}

	public String getTrxAmt() {
		return trxAmt;
	}

	public void setTrxAmt(String trxAmt) {
		this.trxAmt = trxAmt;
	}

	public String getAfterBalance() {
		return afterBalance;
	}

	public void setAfterBalance(String afterBalance) {
		this.afterBalance = afterBalance;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBranchNo() {
		return branchNo;
	}

	public void setBranchNo(String branchNo) {
		this.branchNo = branchNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCredit() {
		return credit;
	}

	public void setCredit(String credit) {
		this.credit = credit;
	}

	public String getDebit() {
		return debit;
	}

	public void setDebit(String debit) {
		this.debit = debit;
	}

	public String getRef() {
		return ref;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}

	public String getLoanNo() {
		return loanNo;
	}

	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	
	
}
