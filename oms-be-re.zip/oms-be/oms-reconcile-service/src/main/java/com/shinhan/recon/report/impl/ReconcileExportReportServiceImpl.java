/**
 * 
 */
package com.shinhan.recon.report.impl;

import java.io.File;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.shinhan.recon.common.AbstractBasicCommonClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.report.ReconcileExportReportService;
import com.shinhan.recon.report.model.bank.DailyReportData;
import com.shinhan.recon.report.model.bank.RepaymentForBankReport;
import com.shinhan.recon.report.model.bank.SuspenseReportData;
import com.shinhan.recon.report.model.disburs.DisbursalForBankReport;
import com.shinhan.recon.report.model.nonbank.RepaymentForNonBankReport;

/**
 * @author shds01
 *
 */
@Service("reconcileExportReportService")
public class ReconcileExportReportServiceImpl extends AbstractBasicCommonClass implements ReconcileExportReportService{

	/* (non-Javadoc)
	 * @see com.shinhan.recon.report.ReconcileExportReportService#exportReconcileRepaymentReportForBank(java.util.Map)
	 */
	@Override
	public File exportReconcileRepaymentReportForBank(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String bankName = inputParams.get(APIConstant._BANK_NAME_KEY).toString();
		String startDt = inputParams.get(APIConstant._START_DATE_KEY).toString();
		String endDt = inputParams.get(APIConstant._END_DATE_KEY).toString();
		
		RepaymentForBankReport dataReport = buildDataForRepaymentBankReport(bankCode, bankName, startDt, endDt);
		
		return exportReconcileRepaymentReportForBank(dataReport,bankCode, bankName, startDt, endDt);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.report.ReconcileExportReportService#exportReconcileRepaymentReportForNonBank(java.util.Map)
	 */
	@Override
	public File exportReconcileRepaymentReportForNonBank(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String bankName = inputParams.get(APIConstant._BANK_NAME_KEY).toString();
		String startDt = inputParams.get(APIConstant._START_DATE_KEY).toString();
		String endDt = inputParams.get(APIConstant._END_DATE_KEY).toString();
		
		RepaymentForNonBankReport dataReport = buildDataForRepaymentNonBankReport(bankCode, bankName, startDt, endDt);
		
		return exportReconcileRepaymentReportForNonBank(dataReport,bankCode, bankName, startDt, endDt);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.report.ReconcileExportReportService#exportReconcileDisbursalReport(java.util.Map)
	 */
	@Override
	public File exportReconcileDisbursalReport(Map<String, Object> inputParams) throws BaseException {
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String bankName = inputParams.get(APIConstant._BANK_NAME_KEY).toString();
		String startDt = inputParams.get(APIConstant._START_DATE_KEY).toString();
		String endDt = inputParams.get(APIConstant._END_DATE_KEY).toString();
	    DisbursalForBankReport dataReport = buildDataForDisbursalReport(bankCode, bankName, startDt, endDt);
		
		return exportDisbursalReport(dataReport,bankCode, bankName, startDt, endDt);
	}

	@Override
	public File exportDailyReport(Map<String, Object> inputParams) throws BaseException {
		String startDt = inputParams.get(APIConstant._START_DATE_KEY).toString();
		String trxDt = inputParams.get(APIConstant.TRX_DATE_KEY).toString();
		String endDt = inputParams.get(APIConstant._END_DATE_KEY).toString();
	    DailyReportData dataReport = buildDataForDailyReport( startDt, endDt,trxDt);
		
		return exportDailyReport(dataReport);
	}

	@Override
	public File exportPendingReport(Map<String, Object> inputParams) throws BaseException {
		String bankCode = StringUtils.isBlank(inputParams.get(APIConstant._BANK_CODE_KEY).toString())? "":inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String startDt = inputParams.get(APIConstant._START_DATE_KEY).toString();
		String endDt = inputParams.get(APIConstant._END_DATE_KEY).toString();
		return exportPendingReport(bankCode, startDt, endDt);
	}
	
	@Override
	public File exportSuspenseReport(Map<String, Object> inputParams) throws BaseException {
		String bankCode = StringUtils.isBlank(inputParams.get(APIConstant._BANK_CODE_KEY).toString())? "":inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String startDt = inputParams.get(APIConstant._START_DATE_KEY).toString();
		String endDt = inputParams.get(APIConstant._END_DATE_KEY).toString();
		long type = (StringUtils.isBlank(inputParams.get(APIConstant._TYPE_KEY).toString()) ? 0 : Long.parseLong(inputParams.get(APIConstant._TYPE_KEY).toString())); 
		SuspenseReportData suspenseReportData = buildDataForSuspenseReport(bankCode,startDt, endDt, type);
		return exportSuspenseReport(bankCode, startDt, endDt,suspenseReportData);
	}

}
