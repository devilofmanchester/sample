/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.service.ReconcileRetryService;

/**
 * @author shds04
 *
 */
@Service("reconcileRetryService")
@Transactional(readOnly = false, propagation =  Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
public class ReconcileRetryServiceImpl extends AbstractServiceClass implements ReconcileRetryService {

	@Override
	public void retryProcess() throws BaseException {
		Map<String, Object> statementFileMasMap = new HashedMap<String, Object>();
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant._UPLOAD_FILE_PENDING_DELETE_STATUS);
		List<TOmsStmtFileMas> tOmsStmtFileMas = getRepositoryManagerService().getTomsStmtFileMasManagerRepositoryService().getListUploadByDateForRerty(statementFileMasMap);
		Collection<File> files = CommonUtil.getBankStatementFileInFolder(env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_PROCESS_FOLDER));
		Collection<File> filesDisb = CommonUtil.getBankStatementFileInFolder(env.getProperty(APIConstant.PATH_SCAN_DISBURSAL_STATEMENT_PROCESS_FOLDER));
		Collection<File> filesSftp = CommonUtil.getBankStatementFileInFolder(env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_FTP_FOLDER));
		if(tOmsStmtFileMas.size() <1 ) {
			logger.info("**** No record to retry ****");
		}else {
			for (TOmsStmtFileMas fileMas : tOmsStmtFileMas) {
				if(fileMas.getFileType() == APIConstant.LMS_TRX_TYPE_REPAYMENT) {
					Map<String, Object > inputParams =  new HashMap<>();
					inputParams.put(APIConstant.TRX_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
					inputParams.put(APIConstant._BANK_CODE_KEY, fileMas.getBankCode());
					inputParams.put(APIConstant.FILE_ID, fileMas.getId());
					String userName =  fileMas.getUploadUser();
					List<TOmsReconLmsInf> tOmsReconLmsInfs = new ArrayList<>();
					List<TOmsReconStmtInf> tOmsReconStmtInfs = getRepositoryManagerService().getTomsReconStmtInfManagerRepositoryService().getListTrxByBankcodeAndFileId(inputParams);
					List<TOmsReconSuspenseInf> tOmsReconSuspenseInfs = getRepositoryManagerService().gettOmsReconSuspInfManagerRepositoryService().getListTrxByBankcodeAndFileId(inputParams);
					for (TOmsReconStmtInf tOmsReconStmtInf : tOmsReconStmtInfs) {
						Map<String, Object> map = new HashMap<>();
						map.put(APIConstant._BANK_CODE_KEY,tOmsReconStmtInf.getBankCode());
						map.put(APIConstant._REF_NO_KEY,tOmsReconStmtInf.getRefNo());
						map.put(APIConstant._CR_AMT_KEY,tOmsReconStmtInf.getCrAmt());
						map.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
						List<TOmsReconLmsInf> lmsInfs = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getListLmsTrxMatchWithStmtRef(map);
						tOmsReconLmsInfs.addAll(lmsInfs);
						tOmsReconStmtInf.setStatusCode(APIConstant._BANK_STATEMENT_DELETED_STATUS);
						DTOConverter.setUtilityTOmsReconStmtInf(tOmsReconStmtInf, null, null, userName,
								DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
					}
					for (TOmsReconSuspenseInf tOmsReconSuspenseInf : tOmsReconSuspenseInfs) {
						tOmsReconSuspenseInf.setStatusCode(APIConstant._SUSPENSE_DELETE_STATUS);
						DTOConverter.setUtilityTOmsReconSuspenseInf(tOmsReconSuspenseInf, null, null,userName, 
								DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
					}
					for (TOmsReconLmsInf tOmsReconLmsInf : tOmsReconLmsInfs) {
						tOmsReconLmsInf.setStatusCode(APIConstant.LMS_UPLOAD_PENDING);
						tOmsReconLmsInf.setRefID("");
					}
					fileMas.setFileStatus(APIConstant._UPLOAD_FILE_DELETE_STATUS);
					for (File file : filesSftp) {
						if(file.getName().equals(fileMas.getFileName())) {
							CommonUtil.deleteFile(file);
						}
					}
					for (File file : files) {
						if(file.getName().equals(fileMas.getFileName())) {
							CommonUtil.deleteFile(file);
						}
					}
					
					logger.info("***** Start delete OMS bank statement *****");
					updateListTOmsStatementInfToDB(tOmsReconStmtInfs, userName);
					logger.info("***** End delete OMS bank statement *****");
					logger.info("***** Start delete Suspense bank statement *****");
					updateListTOmsReconSuspInfToDB(tOmsReconSuspenseInfs, userName);
					logger.info("***** End delete Suspense bank statement *****");
					logger.info("***** Start delete LMS bank statement *****");
					updateListTReconLmsInfToDB(tOmsReconLmsInfs, userName);
					logger.info("***** End delete LMS bank statement *****");
				}else if(fileMas.getFileType() == APIConstant.LMS_TRX_TYPE_DISBURSAL) {
					Map<String, Object > inputParams =  new HashMap<>();
					inputParams.put(APIConstant.TRX_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
					inputParams.put(APIConstant._BANK_CODE_KEY, fileMas.getBankCode());
					inputParams.put(APIConstant.FILE_ID, fileMas.getId());
					String userName =  fileMas.getUploadUser();
					List<TOmsReconLmsInf> tOmsReconLmsInfs = new ArrayList<>();
					List<TOmsReconDisburInf> disb = getRepositoryManagerService().gettOmsReconDisbursalInfManagerRepositoryService().getListTrxByBankcodeAndFileId(inputParams);
					for (TOmsReconDisburInf tOmsReconStmtInf : disb) {
						Map<String, Object> map = new HashMap<>();
						map.put(APIConstant._BANK_CODE_KEY,tOmsReconStmtInf.getBankCode());
						map.put(APIConstant.LOAN_NO_KEY,(StringUtils.isBlank(tOmsReconStmtInf.getLoanNo()) ? "0":tOmsReconStmtInf.getLoanNo() ));
						map.put(APIConstant._CR_AMT_KEY,tOmsReconStmtInf.getDrAmt());
						map.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
						List<TOmsReconLmsInf> lmsInfs = getRepositoryManagerService().getTomsReconLmsInfManagerRepositoryService().getListLmsTrxMatchByLoanAndCrAmt(map);
						tOmsReconLmsInfs.addAll(lmsInfs);
						tOmsReconStmtInf.setStatusCode(APIConstant._BANK_STATEMENT_DELETED_STATUS);
						DTOConverter.setUtilityTOmsDisbStmtInf(tOmsReconStmtInf, null, null, userName,
								DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT),DateUtils.DATEFORMAT));
					}
					
					for (TOmsReconLmsInf tOmsReconLmsInf : tOmsReconLmsInfs) {
						tOmsReconLmsInf.setStatusCode(APIConstant.LMS_UPLOAD_PENDING);
						tOmsReconLmsInf.setRefID("");
					}
					fileMas.setFileStatus(APIConstant._UPLOAD_FILE_DELETE_STATUS);
					for (File file : filesSftp) {
						if(file.getName().equals(fileMas.getFileName())) {
							CommonUtil.deleteFile(file);
						}
					}
					for (File file : filesDisb) {
						if(file.getName().equals(fileMas.getFileName())) {
							CommonUtil.deleteFile(file);
						}
					}
					
					logger.info("***** Start delete Disburse Infor *****");
					updateListTOmsDisbInfToDB(disb, userName);
					logger.info("***** End delete Disburse Infor *****");
					logger.info("***** Start delete LMS bank statement *****");
					updateListTReconLmsInfToDB(tOmsReconLmsInfs, userName);
					logger.info("***** End delete LMS bank statement *****");
				}
				
			}
			logger.info("***** Start delete Uploaded File Mas *****");
			updateTOmsStmtFileListToDB(tOmsStmtFileMas, APIConstant._USERNAME_BATCHJOB);
			logger.info("***** End delete Uploaded File Mas *****");
		}
			
	}

}
