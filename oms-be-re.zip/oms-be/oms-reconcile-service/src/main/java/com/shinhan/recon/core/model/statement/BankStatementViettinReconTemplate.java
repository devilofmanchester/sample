package com.shinhan.recon.core.model.statement;

public class BankStatementViettinReconTemplate {

	private String trxDt;
	private String accountNo;
	private String loanNo;
	private String credit;
	private String ref;   
	private String description;
	private String exntRef;
	private String exntName;
	private String debit;
	public BankStatementViettinReconTemplate() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public BankStatementViettinReconTemplate(String trxDt, String ref, String loanNo, String credit, String accountNo,
			String description, String exntRef, String exntName, String debit) {
		super();
		this.trxDt = trxDt;
		this.ref = ref;
		this.loanNo = loanNo;
		this.credit = credit;
		this.accountNo = accountNo;
		this.description = description;
		this.exntRef = exntRef;
		this.exntName = exntName;
		this.debit = debit;
	}

	public String getTrxDt() {
		return trxDt;
	}

	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}

	public String getExntName() {
		return exntName;
	}

	public void setExntName(String exntName) {
		this.exntName = exntName;
	}

	public String getDebit() {
		return debit;
	}

	public void setDebit(String debit) {
		this.debit = debit;
	}

	public String getTrxDate() {
		return trxDt;
	}
	public void setTrxDate(String trxDate) {
		this.trxDt = trxDate;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getExntRef() {
		return exntRef;
	}
	public void setExntRef(String exntRef) {
		this.exntRef = exntRef;
	}
	
}
