/**
 * 
 */
package com.shinhan.recon.core.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author shds01
 *
 */
public class LmsTrxInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7066230427023517763L;
	/** LMS Transaction **/
	private Long id;
	private String refNo;
	private String bankCode;
	private Date trxDt;
	private Date valueDt;
	private String cif;
	private String paymode;
	private BigDecimal drAmt;
	private BigDecimal crAmt;
	private String loanNo;
	private Long statusCode;
	private Long subStatusCode;

	private String remark;
	private String remarkNote;

	/**
	 * 
	 */
	public LmsTrxInfo() {
		super();
	}

	/**
	 * @param id
	 * @param refNo
	 * @param bankCode
	 * @param trxDt
	 * @param valueDt
	 * @param cif
	 * @param paymode
	 * @param drAmt
	 * @param crAmt
	 * @param loanNo
	 * @param statusCode
	 * @param subStatusCode
	 * @param remark
	 * @param remarkNote
	 */
	public LmsTrxInfo(Long id, String refNo, String bankCode, Date trxDt, Date valueDt, String cif, String paymode,
			BigDecimal drAmt, BigDecimal crAmt, String loanNo, Long statusCode, Long subStatusCode, String remark, String remarkNote) {
		super();
		this.id = id;
		this.refNo = refNo;
		this.bankCode = bankCode;
		this.trxDt = trxDt;
		this.valueDt = valueDt;
		this.cif = cif;
		this.paymode = paymode;
		this.drAmt = drAmt;
		this.crAmt = crAmt;
		this.loanNo = loanNo;
		this.statusCode = statusCode;
		this.subStatusCode = subStatusCode;
		this.remark = remark;
		this.remarkNote = remarkNote;
	}

	/**
	 * @param drAmt
	 * @param crAmt
	 */
	public LmsTrxInfo(BigDecimal drAmt, BigDecimal crAmt) {
		super();
		this.drAmt = drAmt;
		this.crAmt = crAmt;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the refNo
	 */
	public String getRefNo() {
		return refNo;
	}

	/**
	 * @param refNo the refNo to set
	 */
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	/**
	 * @return the bankCode
	 */
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * @return the trxDt
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getTrxDt() {
		return trxDt;
	}

	/**
	 * @param trxDt the trxDt to set
	 */
	public void setTrxDt(Date trxDt) {
		this.trxDt = trxDt;
	}

	/**
	 * @return the valueDt
	 */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getValueDt() {
		return valueDt;
	}

	/**
	 * @param valueDt the valueDt to set
	 */
	public void setValueDt(Date valueDt) {
		this.valueDt = valueDt;
	}

	/**
	 * @return the cif
	 */
	public String getCif() {
		return cif;
	}

	/**
	 * @param cif the cif to set
	 */
	public void setCif(String cif) {
		this.cif = cif;
	}

	/**
	 * @return the paymode
	 */
	public String getPaymode() {
		return paymode;
	}

	/**
	 * @param paymode the paymode to set
	 */
	public void setPaymode(String paymode) {
		this.paymode = paymode;
	}

	/**
	 * @return the drAmt
	 */
	public BigDecimal getDrAmt() {
		return drAmt;
	}

	/**
	 * @param drAmt the drAmt to set
	 */
	public void setDrAmt(BigDecimal drAmt) {
		this.drAmt = drAmt;
	}

	/**
	 * @return the crAmt
	 */
	public BigDecimal getCrAmt() {
		return crAmt;
	}

	/**
	 * @param crAmt the crAmt to set
	 */
	public void setCrAmt(BigDecimal crAmt) {
		this.crAmt = crAmt;
	}

	/**
	 * @return the loanNo
	 */
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the statusCode
	 */
	public Long getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(Long statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the subStatusCode
	 */
	public Long getSubStatusCode() {
		return subStatusCode;
	}

	/**
	 * @param subStatusCode the subStatusCode to set
	 */
	public void setSubStatusCode(Long subStatusCode) {
		this.subStatusCode = subStatusCode;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @return the remarkNote
	 */
	public String getRemarkNote() {
		return remarkNote;
	}

	/**
	 * @param remarkNote the remarkNote to set
	 */
	public void setRemarkNote(String remarkNote) {
		this.remarkNote = remarkNote;
	}

}
