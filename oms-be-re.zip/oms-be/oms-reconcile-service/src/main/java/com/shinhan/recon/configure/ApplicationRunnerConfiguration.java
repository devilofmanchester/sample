/**
 * 
 */
package com.shinhan.recon.configure;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.shinhan.recon.common.AbstractBasicCommonClass;


/**
 * @author shds01
 *
 */
@Component
public class ApplicationRunnerConfiguration extends AbstractBasicCommonClass implements ApplicationRunner {

	/* (non-Javadoc)
	 * @see org.springframework.boot.ApplicationRunner#run(org.springframework.boot.ApplicationArguments)
	 */
	@Override
	public void run(ApplicationArguments arg0) throws Exception {
		logger.info("***** Start to initial value *****");
		
		logger.info("***** End to initial value *****");
	}

}
