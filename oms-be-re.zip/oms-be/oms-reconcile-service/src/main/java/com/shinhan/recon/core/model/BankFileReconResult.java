package com.shinhan.recon.core.model;

public class BankFileReconResult {
	
	int totCnt;
	int matchedCnt;
	int pendingCnt;
	int financeCnt;
	int revertCnt;
	int refundCnt;
	int creditShieldCnt;
	int redisbCnt;
	public BankFileReconResult() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankFileReconResult(int totCnt, int matchedCnt, int pendingCnt, int financeCnt, int revertCnt,
			int refundCnt, int creditShieldCnt, int redisbCnt) {
		super();
		this.totCnt = totCnt;
		this.matchedCnt = matchedCnt;
		this.pendingCnt = pendingCnt;
		this.financeCnt = financeCnt;
		this.revertCnt = revertCnt;
		this.refundCnt = refundCnt;
		this.creditShieldCnt = creditShieldCnt;
		this.redisbCnt = redisbCnt;
	}
	public int getTotCnt() {
		return totCnt;
	}
	public void setTotCnt(int totCnt) {
		this.totCnt = totCnt;
	}
	public int getMatchedCnt() {
		return matchedCnt;
	}
	public void setMatchedCnt(int matchedCnt) {
		this.matchedCnt = matchedCnt;
	}
	public int getPendingCnt() {
		return pendingCnt;
	}
	public void setPendingCnt(int pendingCnt) {
		this.pendingCnt = pendingCnt;
	}
	public int getFinanceCnt() {
		return financeCnt;
	}
	public void setFinanceCnt(int financeCnt) {
		this.financeCnt = financeCnt;
	}
	public int getRevertCnt() {
		return revertCnt;
	}
	public void setRevertCnt(int revertCnt) {
		this.revertCnt = revertCnt;
	}
	public int getRefundCnt() {
		return refundCnt;
	}
	public void setRefundCnt(int refundCnt) {
		this.refundCnt = refundCnt;
	}
	public int getCreditShieldCnt() {
		return creditShieldCnt;
	}
	public void setCreditShieldCnt(int creditShieldCnt) {
		this.creditShieldCnt = creditShieldCnt;
	}
	public int getRedisbCnt() {
		return redisbCnt;
	}
	public void setRedisbCnt(int redisbCnt) {
		this.redisbCnt = redisbCnt;
	}
	
}
