/**
 * 
 */
package com.shinhan.recon.repository.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_RECON_LMS_INF")
public class TOmsReconLmsInf implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	private String refID;
	private String refNo;
	private String bankCode;
	private Date trxDt;
	private Date valueDt;
	private long transactionType;
	private BigDecimal drAmt;
	private BigDecimal crAmt;
	private String loanNo;
	private String loanStatus;
	private long statusCode;
	private long subStatusCode;
	private String createdUser;
	private Date createdDt;
	private String updatedUser;
	private Date updatedDt;
	private String remark;
	private String cif;
	private String paymode;
	private String remarkNote;
	/**
	 * 
	 */
	public TOmsReconLmsInf() {
		super();
	}

	/**
	 * @param id
	 * @param refID
	 * @param refNo
	 * @param bankCode
	 * @param trxDt
	 * @param valueDt
	 * @param transactionType
	 * @param drAmt
	 * @param crAmt
	 * @param loanNo
	 * @param loanStatus
	 * @param statusCode
	 * @param subStatusCode
	 * @param createdUser
	 * @param createdDt
	 * @param updatedUser
	 * @param updatedDt
	 * @param remark
	 * @param cif
	 * @param paymode
	 * @param remarkNote
	 */
	public TOmsReconLmsInf(Long id, String refID, String refNo, String bankCode, Date trxDt, Date valueDt,
			long transactionType, BigDecimal drAmt, BigDecimal crAmt, String loanNo, String loanStatus, long statusCode,
			long subStatusCode, String createdUser, Date createdDt, String updatedUser, Date updatedDt, String remark,
			String cif, String paymode, String remarkNote) {
		super();
		this.id = id;
		this.refID = refID;
		this.refNo = refNo;
		this.bankCode = bankCode;
		this.trxDt = trxDt;
		this.valueDt = valueDt;
		this.transactionType = transactionType;
		this.drAmt = drAmt;
		this.crAmt = crAmt;
		this.loanNo = loanNo;
		this.loanStatus = loanStatus;
		this.statusCode = statusCode;
		this.subStatusCode = subStatusCode;
		this.createdUser = createdUser;
		this.createdDt = createdDt;
		this.updatedUser = updatedUser;
		this.updatedDt = updatedDt;
		this.remark = remark;
		this.cif = cif;
		this.paymode = paymode;
		this.remarkNote = remarkNote;
	}




	/**
	 * @return the id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OMS_RECON_LMS_INF_SEQ_GEN")
	@SequenceGenerator(name = "OMS_RECON_LMS_INF_SEQ_GEN", sequenceName = "OMS_RECON_LMS_INF_SEQ", allocationSize = 1)
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the refNo
	 */
	@Column(name = "REF_NO")
	public String getRefNo() {
		return refNo;
	}

	/**
	 * @param refNo the refNo to set
	 */
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	/**
	 * @return the bankCode
	 */
	@Column(name = "BANK_CODE")
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * @return the trxDt
	 */
	@Column(name = "TRX_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getTrxDt() {
		return trxDt;
	}

	/**
	 * @param trxDt the trxDt to set
	 */
	public void setTrxDt(Date trxDt) {
		this.trxDt = trxDt;
	}

	/**
	 * @return the valueDt
	 */
	@Column(name = "VALUE_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getValueDt() {
		return valueDt;
	}

	/**
	 * @param valueDt the valueDt to set
	 */
	public void setValueDt(Date valueDt) {
		this.valueDt = valueDt;
	}

	/**
	 * @return the transactionType
	 */
	@Column(name = "TRANSACTION_TYPE")
	public long getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(long transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return the drAmt
	 */
	@Column(name = "DR_AMT")
	public BigDecimal getDrAmt() {
		return drAmt;
	}

	/**
	 * @param drAmt the drAmt to set
	 */
	public void setDrAmt(BigDecimal drAmt) {
		this.drAmt = drAmt;
	}

	/**
	 * @return the crAmt
	 */
	@Column(name = "CR_AMT")
	public BigDecimal getCrAmt() {
		return crAmt;
	}

	/**
	 * @param crAmt the crAmt to set
	 */
	public void setCrAmt(BigDecimal crAmt) {
		this.crAmt = crAmt;
	}

	/**
	 * @return the loanNo
	 */
	@Column(name = "LOAN_NO")
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the loanStatus
	 */
	@Column(name = "LOAN_NO_STATUS")
	public String getLoanStatus() {
		return loanStatus;
	}

	/**
	 * @param loanStatus the loanStatus to set
	 */
	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}

	/**
	 * @return the statusCode
	 */
	@Column(name = "STATUS")
	public long getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(long statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the subStatusCode
	 */
	@Column(name = "SUB_STATUS")
	public long getSubStatusCode() {
		return subStatusCode;
	}

	/**
	 * @param subStatusCode the subStatusCode to set
	 */
	public void setSubStatusCode(long subStatusCode) {
		this.subStatusCode = subStatusCode;
	}

	/**
	 * @return the createdUser
	 */
	@Column(name = "REGIS_INF_USER")
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * @param createdUser the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * @return the createdDt
	 */
	@Column(name = "REGIS_INF_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getCreatedDt() {
		return createdDt;
	}

	/**
	 * @param createdDt the createdDt to set
	 */
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	/**
	 * @return the updatedUser
	 */
	@Column(name = "LCHG_INF_USER")
	public String getUpdatedUser() {
		return updatedUser;
	}

	/**
	 * @param updatedUser the updatedUser to set
	 */
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	/**
	 * @return the updatedDt
	 */
	@Column(name = "LCHG_INF_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getUpdatedDt() {
		return updatedDt;
	}

	/**
	 * @param updatedDt the updatedDt to set
	 */
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	/**
	 * @return the remark
	 */
	@Column(name = "REMARK")
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	@Column(name = "REF_ID")
	public String getRefID() {
		return refID;
	}

	public void setRefID(String refID) {
		this.refID = refID;
	}


	/**
	 * @return the cif
	 */
	@Column(name = "CIF")
	public String getCif() {
		return cif;
	}


	/**
	 * @param cif the cif to set
	 */
	public void setCif(String cif) {
		this.cif = cif;
	}


	/**
	 * @return the paymode
	 */
	@Column(name = "PAYMODE")
	public String getPaymode() {
		return paymode;
	}


	/**
	 * @param paymode the paymode to set
	 */
	public void setPaymode(String paymode) {
		this.paymode = paymode;
	}

	/**
	 * @return the remarkNote
	 */
	@Column(name = "REMARK_NOTE")
	public String getRemarkNote() {
		return remarkNote;
	}

	/**
	 * @param remarkNote the remarkNote to set
	 */
	public void setRemarkNote(String remarkNote) {
		this.remarkNote = remarkNote;
	}
}
