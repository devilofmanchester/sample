/**
 * 
 */
package com.shinhan.recon.report.model.disburs;

import com.shinhan.recon.report.model.RepaymentForHeaderReport;

/**
 * @author shds01
 *
 */
public class DisbursalHeaderReport extends RepaymentForHeaderReport{

	
	/**
	 * 
	 */
	public DisbursalHeaderReport() {
		super();
	}

	/**
	 * @param fromDt
	 * @param toDt
	 * @param bankAccount
	 * @param bankName
	 */
	public DisbursalHeaderReport(String fromDt, String toDt, String bankAccount, String bankName) {
		super();
		this.setFromDt(fromDt);
		this.setToDt(fromDt);
		this.setBankAccount(bankAccount);
		this.setBankName(bankName);
	}

}
