/**
 * 
 */
package com.shinhan.recon.repository.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.springframework.stereotype.Service;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TMetadata;
import com.shinhan.recon.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("utilityManagerRepositoryService")
public class UtilityManagerRepositoryServiceImpl extends AbstractServiceClass
		implements UtilityManagerRepositoryService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.shinhan.recon.repository.service.UtilityManagerRepositoryService#
	 * getAllMetadata(java.util.Map)
	 */
	@Override
	public List<TMetadata> getAllMetadata(Map<String, Object> inputParams) throws BaseException {
		String sql = oracleOMSNamedQueries.get("getAllMetadata");
		Query query = entityManager.createNativeQuery(sql, TMetadata.class);

		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();

		return list;
	}
	
	@Override
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws BaseException {
		String sql = oracleOMSNamedQueries.get("getMetadataByLookupCode");
		Query query = entityManager.createNativeQuery(sql, TMetadata.class);
		query.setParameter("LOOKUPCODE", lookupCode);
		@SuppressWarnings("unchecked")
		List<TMetadata> list = query.getResultList();

		return list;
	}

	@Override
	public List<TBankCommon> getBankCommonByBankName(String bankName) throws BaseException {
		String sql = oracleOMSNamedQueries.get("getBankCommonByBankName");
		Query query = entityManager.createNativeQuery(sql, TBankCommon.class);
		query.setParameter("BANK_NAME", bankName);
		@SuppressWarnings("unchecked")
		List<TBankCommon> list = query.getResultList();

		return list;
	}

	@Override
	public TBankCommon getBankCommonByBankAccNum(String bankAccNum) throws BaseException {
		String sql = oracleOMSNamedQueries.get("getBankCommonByBankAccNum");
		Query query = entityManager.createNativeQuery(sql, TBankCommon.class);
		query.setParameter("BANK_ACC_NUM", bankAccNum);
		TBankCommon item = (TBankCommon)query.getSingleResult();
		
		return item;
	}
	
	@Override
	public List<TBankCommon> getBankCommonByBizValue(String bizValue) throws BaseException {
		String sql = oracleOMSNamedQueries.get("getBankCommonByBizValue");
		Query query = entityManager.createNativeQuery(sql, TBankCommon.class);
		query.setParameter(APIConstant._BANK_COMMON_BIZ_VALUE_, bizValue);
		@SuppressWarnings("unchecked")
		List<TBankCommon> list = query.getResultList();

		return list;
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.UtilityManagerRepositoryService#getOpenBalanceOfBankCodeByDate(java.util.Map)
	 */
	@Override
	public BigDecimal getOpenBalanceOfBankCodeByDate(Map<String, Object> inputParams) throws BaseException {
		String sql = "select sub.OPEN_BLC from (select mas.BANK_CODE, mas.UPLOAD_DT, mas.OPEN_BLC from "
				+ "OMS_STMT_FILE_MAS mas where mas.BANK_CODE = :bankCode and mas.FILE_STATUS = 10 and mas.PROCESS_STATUS = 10 "
				+ "and mas.UPLOAD_DT between :fromDt and :endDt order by mas.UPLOAD_DT ASC, mas.OPEN_BLC desc) sub "
				+ "where rownum = 1";
		
		Query query = entityManager.createNativeQuery(sql);
		
		query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
		query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
		query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
		List<BigDecimal> rsList = query.getResultList();
		BigDecimal openBlc = (rsList.isEmpty() ? APIConstant.DEC_ZERO : rsList.get(0));
		
		return openBlc;
	}


}
