/**
 * 
 */
package com.shinhan.recon.repository.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author shds04
 *
 */
@Entity
@Table(name = "OMS_RECON_SUSPENSE_INF")
public class TOmsReconSuspenseInf implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String bankCode;
	private String refNo;
	private Date trxDt;
	private BigDecimal drAmt;
	private BigDecimal crAmt;
	private String remark;
	private String loanNo;
	private long statusCode;
	private long subStatusCode;
	private String confirmYn;
	private Date confirmDt;
	private String updatedUser;
	private Date updatedDt;
	private Long refIdFileMas;
	private Date createdDt;
	private String createUser;
	private String remarkNote;
	private String suspenseType;
	private String ledgerType;
	private String payMode;
	public TOmsReconSuspenseInf() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TOmsReconSuspenseInf(Long id, String bankCode, String refNo, Date trxDt, BigDecimal drAmt, BigDecimal crAmt,
			String remark, String loanNo, long statusCode, long subStatusCode, String confirmYn, Date confirmDt,
			String updatedUser, Date updatedDt, Date createdDt, String createUser, String remarkNote, String suspenseType, Long refIdFileMas, String ledgerType, String payMode) {
		super();
		this.id = id;
		this.bankCode = bankCode;
		this.refNo = refNo;
		this.trxDt = trxDt;
		this.drAmt = drAmt;
		this.crAmt = crAmt;
		this.remark = remark;
		this.loanNo = loanNo;
		this.statusCode = statusCode;
		this.subStatusCode = subStatusCode;
		this.confirmYn = confirmYn;
		this.confirmDt = confirmDt;
		this.updatedUser = updatedUser;
		this.updatedDt = updatedDt;
		this.createdDt = createdDt;
		this.createUser = createUser;
		this.remarkNote = remarkNote;
		this.suspenseType = suspenseType;
		this.refIdFileMas = refIdFileMas;
		this.ledgerType =ledgerType;
		this.payMode =payMode;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OMS_RECON_SUSPENSE_INF_SEQ_GEN")
	@SequenceGenerator(name = "OMS_RECON_SUSPENSE_INF_SEQ_GEN", sequenceName = "OMS_RECON_SUSPENSE_INF_SEQ", allocationSize = 1)
	@Column(name = "ID")
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@Column(name = "BANK_CODE")
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	@Column(name = "REF_NO")
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	@Column(name = "TRX_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getTrxDt() {
		return trxDt;
	}
	public void setTrxDt(Date trxDt) {
		this.trxDt = trxDt;
	}
	@Column(name = "DR_AMT")
	public BigDecimal getDrAmt() {
		return drAmt;
	}
	public void setDrAmt(BigDecimal drAmt) {
		this.drAmt = drAmt;
	}
	@Column(name = "CR_AMT")
	public BigDecimal getCrAmt() {
		return crAmt;
	}
	public void setCrAmt(BigDecimal crAmt) {
		this.crAmt = crAmt;
	}
	@Column(name = "REMARK")
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Column(name = "LOAN_NO")
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	@Column(name = "STATUS")
	public long getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(long statusCode) {
		this.statusCode = statusCode;
	}
	@Column(name = "SUB_STATUS")
	public long getSubStatusCode() {
		return subStatusCode;
	}
	public void setSubStatusCode(long subStatusCode) {
		this.subStatusCode = subStatusCode;
	}
	@Column(name = "CONFIRM_YN")
	public String getConfirmYn() {
		return confirmYn;
	}
	public void setConfirmYn(String confirmYn) {
		this.confirmYn = confirmYn;
	}
	@Column(name = "CONFIRM_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getConfirmDt() {
		return confirmDt;
	}
	public void setConfirmDt(Date confirmDt) {
		this.confirmDt = confirmDt;
	}
	@Column(name = "LCHG_INF_USER")
	public String getUpdatedUser() {
		return updatedUser;
	}
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}
	@Column(name = "LCHG_INF_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getUpdatedDt() {
		return updatedDt;
	}
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}
	@Column(name = "REGIS_INF_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getCreatedDt() {
		return createdDt;
	}
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}
	@Column(name = "REGIS_INF_USER")
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	@Column(name = "REMARK_NOTE")
	public String getRemarkNote() {
		return remarkNote;
	}
	public void setRemarkNote(String remarkNote) {
		this.remarkNote = remarkNote;
	}
	@Column(name = "SUSPENSE_TYPE")
	public String getSuspenseType() {
		return suspenseType;
	}
	public void setSuspenseType(String suspenseType) {
		this.suspenseType = suspenseType;
	}
	@Column(name = "REF_ID_FILE_MAS")
	public Long getRefIdFileMas() {
		return refIdFileMas;
	}

	/**
	 * @param refIdFileMas the refIdFileMas to set
	 */
	public void setRefIdFileMas(Long refIdFileMas) {
		this.refIdFileMas = refIdFileMas;
	}
	@Column(name = "LEDGER_TYPE")
	public String getLedgerType() {
		return ledgerType;
	}
	public void setLedgerType(String ledgerType) {
		this.ledgerType = ledgerType;
	}
	@Column(name = "PAYMODE")
	public String getPayMode() {
		return payMode;
	}
	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}
	
	
}
