package com.shinhan.recon.job;

import java.time.LocalDateTime;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.shinhan.recon.common.AbstractBasicCommonClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.util.CommonUtil;

@Component
public class ReconcileBatchJobScanFile extends AbstractBasicCommonClass {
	
	
	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.scanBankStatement}") // 1 minutes
	public void scanBankStatementFile() throws Exception {
		
		logger.info("***** Start Scan Re-payment File To Process Reconcile Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		getProcessManagerService().getReconcileScanFileProcessService().scanBankStatementFile();
		
		logger.info("***** End Scan Re-payment File To Process Reconcile Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		logger.info("***** Start Scan Disbursal File To Process Reconcile  Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		getProcessManagerService().getReconcileScanFileProcessService().scanBankDisbursalFile();
		
		logger.info("***** End Scan Disbursal File To Process Reconcile Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
	}
	@Scheduled(cron = "${spring.job.application.fixedDelay.deleteGarbageFiles}" ) // 1 minutes
	public void deleteGarbage()throws Exception{
		logger.info("***** Start Delete garbage files :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_DONE_FOLDER));
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_SCAN_DISBURSAL_STATEMENT_DONE_FOLDER));
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.FOLDER_EXPORT_REPORT));
		logger.info("***** End Delete garbage files :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}

}
