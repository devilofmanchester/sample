/**
 * 
 */
package com.shinhan.recon.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.shinhan.recon.repository.entity.TOmsReconDisburInf;

/**
 * @author shds04
 *
 */
@Repository
public interface TOmsReconDisbursalInfDAO extends JpaRepository<TOmsReconDisburInf, Long> {

}
