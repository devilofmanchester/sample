/**
 * 
 */
package com.shinhan.recon.repository.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.model.LmsTrxInfo;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.dao.TOmsReconLmsInfDAO;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.service.TOmsReconLmsInfManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("tomsReconLmsInfManagerRepositoryService")
public class TOmsReconLmsInfManagerRepositoryServiceImpl extends AbstractServiceClass
		implements TOmsReconLmsInfManagerRepositoryService {

	private TOmsReconLmsInfDAO objectDao;

	@Autowired
	public TOmsReconLmsInfManagerRepositoryServiceImpl(TOmsReconLmsInfDAO objectDao) {
		this.objectDao = objectDao;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconLmsInfManagerRepositoryService#
	 * getListLmsTrxByDate(java.util.Map)
	 */
	@Override
	public List<TOmsReconLmsInf> getListLmsTrxByDate(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconLmsInf> rs = new ArrayList<>();
		String valueDt = inputParams.get(APIConstant.TRX_DATE_KEY).toString();
		long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
				? 0
				: Long.parseLong(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
		String sql = oracleOMSNamedQueries.get("getLmsDataByValueDate");
		
		Query query = entityManager.createNativeQuery(sql, TOmsReconLmsInf.class);
		query.setParameter(APIConstant.TRX_DATE_KEY,DateUtils.converToDate(valueDt) );
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY, trxType);
		rs = query.getResultList();
		return rs;
	}
	
	@Override
	public List<TOmsReconLmsInf> getListLmsTrxByBankCode(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconLmsInf> rs = new ArrayList<>();
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String bankStatus = inputParams.get(APIConstant.UPLOAD_BANKSTATUS_KEY).toString();
		long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
				? 0
				: Long.parseLong(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
		String sql = oracleOMSNamedQueries.get("getLmsDataByBankCode");
		Query query = entityManager.createNativeQuery(sql, TOmsReconLmsInf.class);
		query.setParameter(APIConstant.UPLOAD_BANKCODE_KEY, bankCode);
		query.setParameter(APIConstant.UPLOAD_BANKSTATUS_KEY, bankStatus);
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY, trxType);
		rs = query.getResultList();
		return rs;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconLmsInfManagerRepositoryService#
	 * create(java.util.Map)
	 */
	@Override
	public boolean create(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconLmsInf item = (TOmsReconLmsInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconLmsInfManagerRepositoryService#
	 * createAll(java.util.Map)
	 */
	@Override
	public boolean createAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconLmsInf> items = (List<TOmsReconLmsInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconLmsInfManagerRepositoryService#
	 * getOne(java.util.Map)
	 */
	@Override
	public TOmsReconLmsInf getOne(Map<String, Object> inputParams) throws BaseException {
		String omsId = inputParams.get(APIConstant.OMSID).toString();
		if (StringUtils.isBlank(omsId)) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_004"));
		}
		try {
			TOmsReconLmsInf item = objectDao.findById(Long.valueOf(omsId)).get();
			return item;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + omsId + "");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.shinhan.recon.repository.service.TOmsReconLmsInfManagerRepositoryService#
	 * update(java.util.Map)
	 */
	@Override
	public boolean update(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconLmsInf item = (TOmsReconLmsInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean updateALL(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconLmsInf> items = (List<TOmsReconLmsInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconLmsInfManagerRepositoryService#countTotalUnMatchLMSTrxByDate(java.util.Map)
	 */
	@Override
	public BigDecimal countTotalUnMatchLMSTrxByDate(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT count( distinct lms.ID) "
					+ "FROM OMS_RECON_LMS_INF lms "
					+ "WHERE lms.TRX_DT <= :endDt "
					+ "and lms.TRANSACTION_TYPE = :transactionType "
					+ "and lms.BANK_CODE =:bankCode "
					+ "and lms.STATUS not in (1) "
					+ "and DECODE(:statusCode,0,lms.STATUS,:statusCode) = lms.STATUS "
					+ "and (:ref is NULL or lms.REF_NO =:ref) "
					+ "and (:loanNo is NULL or lms.LOAN_NO =:loanNo) "
					+ "and (:payMode is NULL or lms.PAYMODE =:payMode) "
					+ "and (:cif is NULL or lms.CIF =:cif) ";
			
			Query query = entityManager.createNativeQuery(sql);
			long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
					? APIConstant.LMS_TRX_TYPE_REPAYMENT
					: Integer.parseInt(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
			long statusCode = StringUtils.isBlank(inputParams.get(APIConstant._STATUS_KEY).toString())
					? 0
					: Long.parseLong(inputParams.get(APIConstant._STATUS_KEY).toString());
			//query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("transactionType", trxType);
			query.setParameter("statusCode", statusCode);
			query.setParameter("payMode", inputParams.get(APIConstant.PAY_MODE_KEY).toString());
			query.setParameter("cif", inputParams.get(APIConstant.CIF_KEY).toString());
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	
	@Override
	public List<LmsTrxInfo> getUnmatchListLMSTrxByDate(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT new com.shinhan.recon.core.model.LmsTrxInfo("
					+ "lms.id as id, lms.refNo as refNo, lms.bankCode as bankCode, lms.trxDt as trxDt, "
					+ "lms.valueDt as valueDtLMS, lms.cif as cifLMS, lms.paymode as paymodeLMS, "
					+ "lms.drAmt as drAmt, lms.crAmt as crAmt, lms.loanNo as loanNo, "
					+ "lms.statusCode as statusCode, lms.subStatusCode as subStatusCode, lms.remark as remark, lms.remarkNote as remarkNote"
					+ ") "
					+ "FROM TOmsReconLmsInf lms "
					+ "where lms.trxDt <= :endDt "
					+ "and lms.bankCode =:bankCode "
					+ "and lms.transactionType = :transactionType "
					+ "and lms.statusCode not in (1) "
					+ "and DECODE(:statusCode,0,lms.statusCode,:statusCode) = lms.statusCode "
					+ "and (:ref is NULL or lms.refNo =:ref) "
					+ "and (:loanNo is NULL or lms.loanNo =:loanNo) "
					+ "and (:payMode is NULL or lms.paymode =:payMode) "
					+ "and (:cif is NULL or lms.cif =:cif) ";
			
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
					? APIConstant.LMS_TRX_TYPE_REPAYMENT
					: Long.parseLong(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
			long statusCode = StringUtils.isBlank(inputParams.get(APIConstant._STATUS_KEY).toString())
					? 0
					: Long.parseLong(inputParams.get(APIConstant._STATUS_KEY).toString());
			Query query = entityManager.createQuery(sql);
			
			//query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode",statusCode);
			query.setParameter("transactionType",trxType);
			query.setParameter("payMode", inputParams.get(APIConstant.PAY_MODE_KEY).toString());
			query.setParameter("cif", inputParams.get(APIConstant.CIF_KEY).toString());
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			List<LmsTrxInfo> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}


	@Override
	public List<TOmsReconLmsInf> getListLmsTrxMatchWithStmtRef(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconLmsInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getLmsMatchStmtRef");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String refNo = inputParams.get(APIConstant._REF_NO_KEY).toString();
		String drAmtString = inputParams.get(APIConstant._CR_AMT_KEY).toString();
		long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
				? APIConstant.LMS_TRX_TYPE_REPAYMENT
				: Long.parseLong(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
		BigDecimal drAmt = new BigDecimal( StringUtils.isBlank(drAmtString) ? "0" :drAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconLmsInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant._REF_NO_KEY,refNo);
		query.setParameter(APIConstant._DR_AMT_KEY,drAmt);
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY,trxType);
		list = query.getResultList();
		return list;
	}
	@Override
	public List<TOmsReconLmsInf> getListLmsTrxMatchWithRevertRef(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconLmsInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getListLmsTrxMatchWithRevertRef");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String refNo = inputParams.get(APIConstant._REF_NO_KEY).toString();
		String crAmtString = inputParams.get(APIConstant._CR_AMT_KEY).toString();
		long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
				? APIConstant.LMS_TRX_TYPE_REPAYMENT
						: Long.parseLong(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
		BigDecimal crAmt = new BigDecimal( StringUtils.isBlank(crAmtString) ? "0" :crAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconLmsInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant._REF_NO_KEY,refNo);
		query.setParameter(APIConstant._CR_AMT_KEY,crAmt);
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY,trxType);
		list = query.getResultList();
		return list;
	}
	@Override
	public List<TOmsReconLmsInf> getListLmsTrxMatchByLoanAndCrAmt(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconLmsInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getLmsMatchByLoanAndCrAmt");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		String crAmtString = inputParams.get(APIConstant._CR_AMT_KEY).toString();
		long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
				|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
				? APIConstant.LMS_TRX_TYPE_REPAYMENT
				: Long.parseLong(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
		BigDecimal crAmt = new BigDecimal( StringUtils.isBlank(crAmtString) ? "0" :crAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconLmsInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant.LOAN_NO_KEY,loanNo);
		query.setParameter(APIConstant._CR_AMT_KEY,crAmt);
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY,trxType);
		list = query.getResultList();
		return list;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconLmsInfManagerRepositoryService#getUnMatchListTrxByDateAndBankCodeAndStatus(java.util.Map)
	 */
	@Override
	public List<Object[]> getUnMatchListTrxByDateAndBankCodeAndStatus(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT "
					+ "'' as trxDt, '' as refNo, '' as remark, "
					+ "'' as drAmt, '' as crAmt, '' as loanNo, "
					+ "lms.TRX_DT as trxDtLMS, lms.REF_NO as refNoLMS, lms.LOAN_NO as loanNoLMS, "
					+ "lms.CIF as cif, lms.paymode as paymode, "
					+ "lms.DR_AMT as drAmtLMS, lms.CR_AMT as crAmtLMS, lms.REMARK_NOTE as remarkNoteLMS "
					+ "FROM OMS_RECON_LMS_INF lms "
					+ "WHERE lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.TRANSACTION_TYPE = :transactionType "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS = :statusCode "
					+ "ORDER BY lms.REF_NO";
			
			Query query = entityManager.createNativeQuery(sql);
			long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
					? APIConstant.LMS_TRX_TYPE_REPAYMENT
					: Long.parseLong(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("transactionType", trxType);
			
			query.setParameter("statusCode", Long.valueOf(inputParams.get(APIConstant._STATUS_KEY).toString()));
			
			return query.getResultList();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	@Override
	public List<Object[]> getListTrxByDateAndBankCodeAndStatuses(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT "
					+ "'' as trxDt, '' as refNo, '' as remark, "
					+ "'' as drAmt, '' as crAmt, '' as loanNo, "
					+ "lms.TRX_DT as trxDtLMS, lms.REF_NO as refNoLMS, lms.LOAN_NO as loanNoLMS, "
					+ "lms.CIF as cif, lms.PAYMODE as paymode, "
					+ "lms.DR_AMT as drAmtLMS, lms.CR_AMT as crAmtLMS, lms.REMARK_NOTE as remarkNoteLMS "
					+ "FROM OMS_RECON_LMS_INF lms "
					+ "WHERE lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.TRANSACTION_TYPE = :transactionType "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS IN :statusCodes "
					+ "ORDER BY lms.REF_NO";
			
			Query query = entityManager.createNativeQuery(sql);
			long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
					? APIConstant.LMS_TRX_TYPE_REPAYMENT
							: Long.parseLong(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("transactionType", trxType);
			
			query.setParameter("statusCodes", (List<Long>)(inputParams.get(APIConstant._STATUS_KEY)));
			
			return query.getResultList();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	@Override
	public List<Object[]> getUnMatchListTrxByDateAndBankCodeAndNonStatus(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT "
					+ "'' as trxDt, '' as refNo, '' as remark, "
					+ "'' as drAmt, '' as crAmt, '' as loanNo, "
					+ "lms.TRX_DT as trxDtLMS, lms.REF_NO as refNoLMS, lms.LOAN_NO as loanNoLMS, "
					+ "lms.CIF as cif, lms.PAYMODE as paymode, "
					+ "lms.DR_AMT as drAmtLMS, lms.CR_AMT as crAmtLMS, lms.REMARK_NOTE as remarkNoteLMS "
					+ "FROM OMS_RECON_LMS_INF lms "
					+ "WHERE lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.TRANSACTION_TYPE = :transactionType "
					+ "and lms.STATUS <> 7"
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS <> :statusCode "
					+ "ORDER BY lms.REF_NO";
			
			Query query = entityManager.createNativeQuery(sql);
			long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
					? APIConstant.LMS_TRX_TYPE_REPAYMENT
							: Long.parseLong(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("transactionType", trxType);
			
			query.setParameter("statusCode", Long.valueOf(inputParams.get(APIConstant._STATUS_KEY).toString()));
			
			return query.getResultList();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.recon.repository.service.TOmsReconLmsInfManagerRepositoryService#sumDrAndCrUnMatchListLMSTrxByDateAndBankCode(java.util.Map)
	 */
	@Override
	public BankStatementLmsTrxInfo sumDrAndCrUnMatchListLMSTrxByDateAndBankCode(
			Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT "
					+ "SUM(lms.DR_AMT) as drAmt, SUM(lms.CR_AMT) as crAmt "
					+ "FROM OMS_RECON_LMS_INF lms "
					+ "WHERE "
					+ "lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.TRANSACTION_TYPE = :transactionType "
					+ "and lms.STATUS <> 7 "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS <> :statusCode ";
			
			Query query = entityManager.createNativeQuery(sql);
			long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
					? APIConstant.LMS_TRX_TYPE_REPAYMENT
					: Long.parseLong(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant.LMS_TRX_MATCHED));
			query.setParameter("transactionType",trxType);
			List<Object[]> lst = query.getResultList();
			
			for(Object[] item : lst){
				if(item[0] == null) {
					return new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
				}
				return new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, new BigDecimal(item[0] + ""), new BigDecimal(item[1] + ""));
			}
			return new BankStatementLmsTrxInfo();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}

	@Override
	public List<TOmsReconLmsInf> getListLmsTrxByBankCodeAndDate(Map<String, Object> inputParams) throws BaseException {
		List< TOmsReconLmsInf> rs = new ArrayList<>();
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String trxDt = inputParams.get(APIConstant.TRX_DATE_KEY).toString();
		String trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString();
		String sql = oracleOMSNamedQueries.get("getLmsDataByBankCodeAndDate");
		Query query = entityManager.createNativeQuery(sql, TOmsReconLmsInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY, bankCode);
		query.setParameter(APIConstant.TRX_DATE_KEY, DateUtils.convertDate(trxDt, DateUtils.DATEFORMAT));
		query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY, trxType);
		rs = query.getResultList();
		return rs;
	}

	@Override
	public List<Object[]> getPendingListTrxForReport(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT "
					+ "lms.TRX_DT as trxDtLMS, lms.REF_NO as refNoLMS, lms.REMARK as reamrk, "
					+ "lms.DR_AMT as drAmtLMS, lms.CR_AMT as crAmtLMS, lms.LOAN_NO as loanNoLMS, lms.REMARK_NOTE as remarkNoteLMS "
					+ "FROM OMS_RECON_LMS_INF lms "
					+ "WHERE lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.TRANSACTION_TYPE = :transactionType "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS = :statusCode ";
			long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
					? APIConstant.LMS_TRX_TYPE_REPAYMENT
					: Long.parseLong(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
			Query query = entityManager.createNativeQuery(sql);
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("transactionType",trxType);
			query.setParameter("statusCode", APIConstant.LMS_UPLOAD_PENDING);
			List<Object[]>  rs = new ArrayList<>();
			rs =  query.getResultList();
			
			return rs;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}


}
