/**
 * 
 */
package com.shinhan.autodebit.api.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.BaseException;
import com.shinhan.autodebit.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.core.model.CommunicationSystemCallBackRequest;
import com.shinhan.autodebit.core.util.CommonUtil;

/**
 * @author shds01
 *
 */
@RestController
public class UtilityController extends BaseController{

	
	@RequestMapping(value = "shinhan/common/connection", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public String testGet() throws ServiceRuntimeException, InterruptedException {
		return triggerSuccessOutPut(null, JsonObject.class, "connect server successfully");
	}

	@RequestMapping(value = "shinhan/common/exception", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public String testException(Locale locale) throws BaseException {
		testException();
		return "Success";
	}
	
	@RequestMapping(value = "shinhan/common/cs/tracking", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	public String callBackURLForCommunicationSystem(@RequestBody String document, Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		
		CommunicationSystemCallBackRequest item = getProcessManagerService().getUtilityApiService().callBackURLForCommunicationSystem(inputParams);
		return triggerSuccessOutPut(CommonUtil.toJson(item), JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/autodebit/template", produces = {"application/json;charset=utf-8", "application/pdf"}, method = RequestMethod.GET)
	public ResponseEntity<Object> exportReconcileReport (
			@RequestParam(required = true) String _templateName,
			Locale locale) throws BaseException, FileNotFoundException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._TEMPLATE_NAME_KEY, _templateName);
		
		File item = getProcessManagerService().getUtilityApiService().getTemplateNameToImport(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_004"));
		}
		
		return triggerSuccessResponseFile(item);
	}
	
	@Scheduled(cron = "${spring.job.remove.file.everyday}") // 0 PM everyday
	public void cleanFileReport() throws BaseException, IOException {
		logger.info("***** Start remove file export report Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_EXPORT_AUTODEBIT));
		logger.info("***** End remove file export report Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		logger.info("***** Start remove file import Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_IMPORT_REGIS_AUTODEBIT));
		logger.info("***** End remove file import Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
	
	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.sendSMS.firstDueDate}") // 1 minutes
	public void jobScanTrxToSendingSMSFirstDueDate() throws BaseException {
		logger.info("***** Start Send SMS for First Due Date Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		Map<String, Object> inputParams = new HashMap<>();
		
		getProcessManagerService().getUtilityApiService().scanADTrxToSendSMSFirstDueDt(inputParams);
		logger.info("***** End Send SMS for First Due Date Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
	
	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.sendSMS.bankFail}") // 1 minutes
	public void jobScanTrxToSendingSMSBankFail() throws BaseException {
		logger.info("***** Start Send SMS for Bank Fail Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		Map<String, Object> inputParams = new HashMap<>();
		
		getProcessManagerService().getUtilityApiService().scanADTrxToSendSMSBankFail(inputParams);
		logger.info("***** End Send SMS for Bank Fail Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
}
