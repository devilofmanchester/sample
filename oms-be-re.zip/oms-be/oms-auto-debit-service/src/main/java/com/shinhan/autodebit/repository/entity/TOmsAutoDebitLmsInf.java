/**
 * 
 */
package com.shinhan.autodebit.repository.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_AD_LMS_INF")
public class TOmsAutoDebitLmsInf implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String loanNo;
	private Date sendDt;
	private String signedLocation;
	private String sendUser;
	private Date receiveDt;
	private String receiveUser;
	private Date drDt;
	private Date sendBankDt;
	private Date smsDueDt;
	private Date bankResultDt;
	private String registrationResult;
	private String reason;
	private Date smsADDt;
	private String statusCode;

	private String createdUser;
	private Date createdDt;
	private String updatedUser;
	private Date updatedDt;

	private String smsDueDtStatus;
	private String smsADDtStatus;
	private Long sendDtIndex;
	private Long receiveDtIndex;
	
	/**
	 * 
	 */
	public TOmsAutoDebitLmsInf() {
		super();
	}

	/**
	 * @param loanNo
	 * @param sendDt
	 * @param signedLocation
	 * @param sendUser
	 * @param receiveDt
	 * @param receiveUser
	 * @param drDt
	 * @param sendBankDt
	 * @param smsDueDt
	 * @param bankResultDt
	 * @param registrationResult
	 * @param reason
	 * @param smsADDt
	 * @param statusCode
	 * @param createdUser
	 * @param createdDt
	 * @param updatedUser
	 * @param updatedDt
	 * @param smsDueDtStatus
	 * @param smsADDtStatus
	 */
	public TOmsAutoDebitLmsInf(String loanNo, Date sendDt, String signedLocation, String sendUser, Date receiveDt,
			String receiveUser, Date drDt, Date sendBankDt, Date smsDueDt, Date bankResultDt, String registrationResult,
			String reason, Date smsADDt, String statusCode, String createdUser, Date createdDt, String updatedUser,
			Date updatedDt, String smsDueDtStatus, String smsADDtStatus) {
		super();
		this.loanNo = loanNo;
		this.sendDt = sendDt;
		this.signedLocation = signedLocation;
		this.sendUser = sendUser;
		this.receiveDt = receiveDt;
		this.receiveUser = receiveUser;
		this.drDt = drDt;
		this.sendBankDt = sendBankDt;
		this.smsDueDt = smsDueDt;
		this.bankResultDt = bankResultDt;
		this.registrationResult = registrationResult;
		this.reason = reason;
		this.smsADDt = smsADDt;
		this.statusCode = statusCode;
		this.createdUser = createdUser;
		this.createdDt = createdDt;
		this.updatedUser = updatedUser;
		this.updatedDt = updatedDt;
		this.smsDueDtStatus = smsDueDtStatus;
		this.smsADDtStatus = smsADDtStatus;
	}

	/**
	 * @return the loanNo
	 */
	@Id
	@Column(name = "LOAN_NO")
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the sendDt
	 */
	@Column(name = "SEND_DT")
	public Date getSendDt() {
		return sendDt;
	}

	/**
	 * @param sendDt the sendDt to set
	 */
	public void setSendDt(Date sendDt) {
		this.sendDt = sendDt;
	}

	/**
	 * @return the signedLocation
	 */
	@Column(name = "SIGNED_LOCATION")
	public String getSignedLocation() {
		return signedLocation;
	}

	/**
	 * @param signedLocation the signedLocation to set
	 */
	public void setSignedLocation(String signedLocation) {
		this.signedLocation = signedLocation;
	}

	/**
	 * @return the sendUser
	 */
	@Column(name = "SEND_USER")
	public String getSendUser() {
		return sendUser;
	}

	/**
	 * @param sendUser the sendUser to set
	 */
	public void setSendUser(String sendUser) {
		this.sendUser = sendUser;
	}

	/**
	 * @return the receiveDt
	 */
	@Column(name = "RECEIVED_DT")
	public Date getReceiveDt() {
		return receiveDt;
	}

	/**
	 * @param receiveDt the receiveDt to set
	 */
	public void setReceiveDt(Date receiveDt) {
		this.receiveDt = receiveDt;
	}

	/**
	 * @return the receiveUser
	 */
	@Column(name = "RECEIVED_USER")
	public String getReceiveUser() {
		return receiveUser;
	}

	/**
	 * @param receiveUser the receiveUser to set
	 */
	public void setReceiveUser(String receiveUser) {
		this.receiveUser = receiveUser;
	}

	/**
	 * @return the drDt
	 */
	@Column(name = "DR_DT")
	public Date getDrDt() {
		return drDt;
	}

	/**
	 * @param drDt the drDt to set
	 */
	public void setDrDt(Date drDt) {
		this.drDt = drDt;
	}

	/**
	 * @return the sendBankDt
	 */
	@Column(name = "SEND_BANK_DT")
	public Date getSendBankDt() {
		return sendBankDt;
	}

	/**
	 * @param sendBankDt the sendBankDt to set
	 */
	public void setSendBankDt(Date sendBankDt) {
		this.sendBankDt = sendBankDt;
	}

	/**
	 * @return the smsDueDt
	 */
	@Column(name = "SMS_DUE_DT")
	public Date getSmsDueDt() {
		return smsDueDt;
	}

	/**
	 * @param smsDueDt the smsDueDt to set
	 */
	public void setSmsDueDt(Date smsDueDt) {
		this.smsDueDt = smsDueDt;
	}

	/**
	 * @return the bankResultDt
	 */
	@Column(name = "BANK_RESULT_DT")
	public Date getBankResultDt() {
		return bankResultDt;
	}

	/**
	 * @param bankResultDt the bankResultDt to set
	 */
	public void setBankResultDt(Date bankResultDt) {
		this.bankResultDt = bankResultDt;
	}

	/**
	 * @return the registrationResult
	 */
	@Column(name = "REGISTRATION_RESULT")
	public String getRegistrationResult() {
		return registrationResult;
	}

	/**
	 * @param registrationResult the registrationResult to set
	 */
	public void setRegistrationResult(String registrationResult) {
		this.registrationResult = registrationResult;
	}

	/**
	 * @return the reason
	 */
	@Column(name = "REASON")
	public String getReason() {
		return reason;
	}

	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}

	/**
	 * @return the smsADDt
	 */
	@Column(name = "SMS_AD_DT")
	public Date getSmsADDt() {
		return smsADDt;
	}

	/**
	 * @param smsADDt the smsADDt to set
	 */
	public void setSmsADDt(Date smsADDt) {
		this.smsADDt = smsADDt;
	}

	/**
	 * @return the statusCode
	 */
	@Column(name = "STATUS_CODE")
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the createdUser
	 */
	@Column(name = "REGIS_INF_USER")
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * @param createdUser the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * @return the createdDt
	 */
	@Column(name = "REGIS_INF_DT")
	public Date getCreatedDt() {
		return createdDt;
	}

	/**
	 * @param createdDt the createdDt to set
	 */
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	/**
	 * @return the updatedUser
	 */
	@Column(name = "LCHG_INF_USER")
	public String getUpdatedUser() {
		return updatedUser;
	}

	/**
	 * @param updatedUser the updatedUser to set
	 */
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	/**
	 * @return the updatedDt
	 */
	@Column(name = "LCHG_INF_DT")
	public Date getUpdatedDt() {
		return updatedDt;
	}

	/**
	 * @param updatedDt the updatedDt to set
	 */
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	/**
	 * @return the smsDueDtStatus
	 */
	@Column(name = "SMS_DUE_DT_STATUS")
	public String getSmsDueDtStatus() {
		return smsDueDtStatus;
	}

	/**
	 * @param smsDueDtStatus the smsDueDtStatus to set
	 */
	public void setSmsDueDtStatus(String smsDueDtStatus) {
		this.smsDueDtStatus = smsDueDtStatus;
	}

	/**
	 * @return the smsADDtStatus
	 */
	@Column(name = "SMS_AD_DT_STATUS")
	public String getSmsADDtStatus() {
		return smsADDtStatus;
	}

	/**
	 * @param smsADDtStatus the smsADDtStatus to set
	 */
	public void setSmsADDtStatus(String smsADDtStatus) {
		this.smsADDtStatus = smsADDtStatus;
	}

	/**
	 * @return the sendDtIndex
	 */
	@Column(name = "SEND_DT_INDEX")
	public Long getSendDtIndex() {
		return sendDtIndex;
	}

	/**
	 * @param sendDtIndex the sendDtIndex to set
	 */
	public void setSendDtIndex(Long sendDtIndex) {
		this.sendDtIndex = sendDtIndex;
	}

	/**
	 * @return the receiveDtIndex
	 */
	@Column(name = "RECEIVED_DT_INDEX")
	public Long getReceiveDtIndex() {
		return receiveDtIndex;
	}

	/**
	 * @param receiveDtIndex the receiveDtIndex to set
	 */
	public void setReceiveDtIndex(Long receiveDtIndex) {
		this.receiveDtIndex = receiveDtIndex;
	}
	
}
