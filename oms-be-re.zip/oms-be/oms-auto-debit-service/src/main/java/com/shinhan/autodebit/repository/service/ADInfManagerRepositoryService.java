/**
 * 
 */
package com.shinhan.autodebit.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.autodebit.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.core.model.AutoDebitTrxInfo;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsInf;

/**
 * @author shds01
 *
 */
public interface ADInfManagerRepositoryService {

	public TOmsAutoDebitLmsInf getOne(String loanNo) throws ServiceRuntimeException;
	
	public TOmsAutoDebitLmsInf getOneByLoanNo(String loanNo) throws ServiceRuntimeException;
	
	public TOmsAutoDebitLmsInf getOneByLoanNoAndStatusCode(String loanNo, String statusCode) throws ServiceRuntimeException;
	
	public List<AutoDebitTrxInfo> getListRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<Object[]> exportRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public boolean update(TOmsAutoDebitLmsInf inf) throws ServiceRuntimeException;
	
	public boolean updateAll(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<TOmsAutoDebitLmsInf> getListAutoDebitTrxForExport(String bankCode) throws ServiceRuntimeException;
	
	public List<AutoDebitTrxInfo> getListRegisterAutoDebitTrxByPeriodDate(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countRegisterAutoDebitTrxByPeriodDate(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<Object[]> exportRegisterAutoDebitTrxByPeriodDate(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<Object[]> exportReportSummaryAutoDebitTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<Object[]> exportReportTATSummaryAutoDebitTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<Object[]> exportReportBankResultAutoDebitTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<Object[]> exportReportBankResultFailAutoDebitTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<Object[]> exportReportBankTransactionAutoDebitTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<Object[]> exportReportTATBankAutoDebitTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<Object[]> exportReportTATBankTransactionAutoDebitTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<TOmsAutoDebitLmsInf> getListAutoDebitTrxForSendSMSFirstDueDt() throws ServiceRuntimeException;
	
	public List<TOmsAutoDebitLmsInf> getListAutoDebitTrxForSendSMSFailBank() throws ServiceRuntimeException;
}
