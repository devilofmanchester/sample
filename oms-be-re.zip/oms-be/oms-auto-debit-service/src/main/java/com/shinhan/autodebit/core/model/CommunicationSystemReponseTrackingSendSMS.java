/**
 * 
 */
package com.shinhan.autodebit.core.model;

/**
 * @author shds01
 *
 */
public class CommunicationSystemReponseTrackingSendSMS {

	private String delivery_time;
	private String tracking_id;

	/**
	 * 
	 */
	public CommunicationSystemReponseTrackingSendSMS() {
		super();
	}

	/**
	 * @param delivery_time
	 * @param tracking_id
	 */
	public CommunicationSystemReponseTrackingSendSMS(String delivery_time, String tracking_id) {
		super();
		this.delivery_time = delivery_time;
		this.tracking_id = tracking_id;
	}

	/**
	 * @return the delivery_time
	 */
	public String getDelivery_time() {
		return delivery_time;
	}

	/**
	 * @param delivery_time the delivery_time to set
	 */
	public void setDelivery_time(String delivery_time) {
		this.delivery_time = delivery_time;
	}

	/**
	 * @return the tracking_id
	 */
	public String getTracking_id() {
		return tracking_id;
	}

	/**
	 * @param tracking_id the tracking_id to set
	 */
	public void setTracking_id(String tracking_id) {
		this.tracking_id = tracking_id;
	}

}
