/**
 * 
 */
package com.shinhan.autodebit.common;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

import com.shinhan.autodebit.core.constant.APIConstant;
import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.core.model.BankTemplateFormat;
import com.shinhan.autodebit.core.util.CommonUtil;
import com.shinhan.autodebit.core.util.DTOConverter;
import com.shinhan.autodebit.core.util.DateUtils;
import com.shinhan.autodebit.core.util.WriteToExcelTemplate;
import com.shinhan.autodebit.repository.entity.TBankCommon;
import com.shinhan.autodebit.repository.entity.TMetadata;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsInf;
/**
 * @author shds01
 *
 */
public abstract class AbstractServiceClass extends AbstractRepositoryClass {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public Environment env;

	@Autowired
	private ProcessManagerService processManagerService;

	@Autowired
	private AsyncManagerService asyncManagerService;

	@Autowired
	private ValidationManagerService validationManagerService;

	/**
	 * @return the processManagerService
	 */
	public ProcessManagerService getProcessManagerService() {
		return processManagerService;
	}

	/**
	 * @param processManagerService the processManagerService to set
	 */
	public void setProcessManagerService(
			@Qualifier("processManagerService") ProcessManagerService processManagerService) {
		this.processManagerService = processManagerService;
	}

	/**
	 * @return the asyncManagerService
	 */
	public AsyncManagerService getAsyncManagerService() {
		return asyncManagerService;
	}

	/**
	 * @param asyncManagerService the asyncManagerService to set
	 */
	public void setAsyncManagerService(@Qualifier("asyncManagerService") AsyncManagerService asyncManagerService) {
		this.asyncManagerService = asyncManagerService;
	}

	/**
	 * @return the validationManagerService
	 */
	public ValidationManagerService getValidationManagerService() {
		return validationManagerService;
	}

	/**
	 * @param validationManagerService the validationManagerService to set
	 */
	public void setValidationManagerService(@Qualifier("validationManagerService") ValidationManagerService validationManagerService) {
		this.validationManagerService = validationManagerService;
	}
	
	/** 
	 * Build data to binding report to export the list auto debit trx for Bank
	 * */
	public List<Object[]> buildDataADTrxReportByBank(String bankName) throws ServiceRuntimeException {
		Map<String, Object> inputParams = new HashMap<String, Object>();
		inputParams.put(APIConstant._BANK, bankName);
		
		return DTOConverter.transferDataToFillHeaderForReport(getRepositoryManagerService().getAdMasManagerRepositoryService().buildDataADTrxReportByBankTemplate(inputParams), bankName);
	}
	
	
	/** 
	 * process export the auto debit trx for register to bank
	 * @param templateData
	 * @throws ServiceRuntimeException 
	 * */
	public File exportADTrxReportForBank(List<Object[]> templateData, String bankCode) throws ServiceRuntimeException {
		// Get template file
		TMetadata templateFileName = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_AD_TEMPLATE_EXPORT_DATA_BANK_REGISTRATION, bankCode);
		String fileSource = env.getProperty(APIConstant.PATH_TEMPLATE_BANK_AUTODEBIT) + templateFileName.getValue();
		String fileDestinationExport = env.getProperty(APIConstant.PATH_TEMPLATE_EXPORT_BANK_REGISTRATION_AUTODEBIT) + bankCode
				+ DateUtils.formatToString(new Date(), DateUtils.ddMMyyyyhhmmss) + APIConstant.FILE_TYPE_EXCEL_OLD;
		
		//get BankCommon
		TBankCommon bankCommon = (TBankCommon) getRepositoryManagerService().getUtilityManagerRepositoryService().getBankCommonByBankCodeAndBizVal(bankCode, APIConstant.BANK_COMMON_BIZ_TEMPLATE_VALUE_FORMAT);
		
		//get bank format
		BankTemplateFormat templateInfo = DTOConverter.getBankTemplateFormat(bankCommon);
		
		/** Start Process fill data */
		Workbook wb = WriteToExcelTemplate.loadTemplateAndFillDataReport(fileSource, templateData, templateInfo.getSheetName(), templateInfo.getFromRow());
		/** End Process fill data */
		
		switch (bankCode) {
		case APIConstant.ACB_TEMPLATE_BANK_REGISTRATION:
			// get last row of sheet
			int lastRowOfSheetAcb = wb.getSheet(templateInfo.getSheetName()).getLastRowNum();
			
			// get list index of item need to merge
			int[] lstIndexMergeAcb = CommonUtil.getIndexOfItem(lastRowOfSheetAcb, templateInfo.getIndexOfMegreItem());
			templateInfo.setIndexOfMegreItem(lstIndexMergeAcb);
			
			formatExcelTemplate(wb, templateInfo);
			
			/** Start Write Excel file */
			return WriteToExcelTemplate.writeToExcelFile(wb, fileDestinationExport);
			/** End Write Excel file */
			
		case APIConstant.AGRIBANK_TEMPLATE_BANK_REGISTRATION:
			//get last row of sheet
			int lastRowOfSheetAri = wb.getSheet(templateInfo.getSheetName()).getLastRowNum();
			
			// get list index of item need to merge
			int[] lstIndexMergeAri = CommonUtil.getIndexOfItem(lastRowOfSheetAri, templateInfo.getIndexOfMegreItem());
			templateInfo.setIndexOfMegreItem(lstIndexMergeAri);
			
			// get list index of item need to custom
			int[] lstIndexCustom = CommonUtil.getIndexOfItem(lastRowOfSheetAri, templateInfo.getCustomRow());
			templateInfo.setCustomRow(lstIndexCustom);
			
			formatExcelTemplate(wb, templateInfo);
			
			/** Start Write Excel file */
			return WriteToExcelTemplate.writeToExcelFile(wb, fileDestinationExport);
			/** End Write Excel file */
			
		case APIConstant.TECHCOMBANK_TEMPLATE_BANK_REGISTRATION:
			// get last row of sheet
			int lastRowOfSheetTechcom = wb.getSheet(templateInfo.getSheetName()).getLastRowNum();
			
			// get list index of item need to merge
			int[] lstIndexMergeTechcom = CommonUtil.getIndexOfItem(lastRowOfSheetTechcom, templateInfo.getIndexOfMegreItem());
			templateInfo.setIndexOfMegreItem(lstIndexMergeTechcom);
			
			formatExcelTemplate(wb, templateInfo);
			
			/** Start Write Excel file */
			return WriteToExcelTemplate.writeToExcelFile(wb, fileDestinationExport);
			/** End Write Excel file */
			
		case APIConstant.VCB_TEMPLATE_BANK_REGISTRATION:
			
			// get last row of sheet
			int lastRowOfSheetVcb = wb.getSheet(templateInfo.getSheetName()).getLastRowNum();

			// get list index of item need to merge
			int[] lstIndexMergeVcb = CommonUtil.getIndexOfItem(lastRowOfSheetVcb, templateInfo.getIndexOfMegreItem());
			templateInfo.setIndexOfMegreItem(lstIndexMergeVcb);
			formatExcelTemplate(wb, templateInfo);
			
			/** Start Write Excel file */
			return WriteToExcelTemplate.writeToExcelFile(wb, fileDestinationExport);
			/** End Write Excel file */
			
		case APIConstant.VIETTINBANK_TEMPLATE_BANK_REGISTRATION:
			// get last row of sheet
			int lastRowOfSheetVietin = wb.getSheet(templateInfo.getSheetName()).getLastRowNum();
			
			// get list index of item need to merge
			int[] lstIndexMergeVietin = CommonUtil.getIndexOfItem(lastRowOfSheetVietin, templateInfo.getIndexOfMegreItem());
			templateInfo.setIndexOfMegreItem(lstIndexMergeVietin);
			
			// get list index of item need to custom
			int[] lstIndexCustomVietin = CommonUtil.getIndexOfItem(lastRowOfSheetVietin, templateInfo.getCustomRow());
			templateInfo.setCustomRow(lstIndexCustomVietin);
			
			formatExcelTemplate(wb, templateInfo);
			
			/** Start Write Excel file */
			return WriteToExcelTemplate.writeToExcelFile(wb, fileDestinationExport);
			/** End Write Excel file */
			
		default:
			return null;
		}
	}
	
	// [Start] -- Quang Pham -- Fix Bug -- 2021/05/17
	public static void formatExcelTemplate(Workbook wb, BankTemplateFormat template) {
		
		//set height
		if(template.getCustomRow() != null) {
			for(int i = 0; i < template.getCustomRow().length; i++) {
				WriteToExcelTemplate.setHeightForRow(template.getCustomRow()[i],template.getHeightOfCustomRow()[i],template.getSheetName(), wb);
			}
		}
		//set date 
		if(template.getDateExportReport() != null) {
			WriteToExcelTemplate.fillCurrentDateToCell(template.getFromHeaderRow(), template.getFromHeaderCol(), template.getSheetName(), wb, template.getDateExportReport());
		}
		
		//merge cells
		if(template.getIndexOfMegreItem() != null) {
			for(int i = 0; i < template.getIndexOfMegreItem().length; i++) {
				WriteToExcelTemplate.mergeCell(template.getIndexOfMegreItem()[i], template.getMergeFrom()[i], template.getMergeTo()[i], template.getSheetName(), wb);
			}
		}
		
	}
	
	// [End] -- Quang Pham -- Fix Bug -- 2021/05/17
}
