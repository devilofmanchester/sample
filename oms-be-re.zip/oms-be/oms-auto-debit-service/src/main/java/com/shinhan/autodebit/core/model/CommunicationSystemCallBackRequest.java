/**
 * 
 */
package com.shinhan.autodebit.core.model;

/**
 * @author shds01
 *
 */
public class CommunicationSystemCallBackRequest {

	private String event_name;
	private String source;
	private CommunicationSystemReponseTrackingSendSMS message;

	/**
	 * 
	 */
	public CommunicationSystemCallBackRequest() {
		super();
		this.message = new CommunicationSystemReponseTrackingSendSMS();
	}

	/**
	 * @param event_name
	 * @param source
	 * @param message
	 */
	public CommunicationSystemCallBackRequest(String event_name, String source,
			CommunicationSystemReponseTrackingSendSMS message) {
		super();
		this.event_name = event_name;
		this.source = source;
		this.message = message;
	}

	/**
	 * @return the event_name
	 */
	public String getEvent_name() {
		return event_name;
	}

	/**
	 * @param event_name the event_name to set
	 */
	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}

	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}

	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return the message
	 */
	public CommunicationSystemReponseTrackingSendSMS getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(CommunicationSystemReponseTrackingSendSMS message) {
		this.message = message;
	}

}
