/**
 * 
 */
package com.shinhan.redisburse.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.shinhan.redisburse.report.RedisbursalExportReportService;
import com.shinhan.redisburse.service.ReDisbursalApiService;


/**
 * @author shds01
 *
 */
@Service("processManagerService")
public class ProcessManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private ReDisbursalApiService reDisbursalApiService;
	
	@Autowired
	private RedisbursalExportReportService redisbursalExportReportService;

	public ReDisbursalApiService getReDisbursalApiService() {
		return reDisbursalApiService;
	}

	public void setReDisbursalApiService(
			@Qualifier("reDisbursalApiService")	ReDisbursalApiService reDisbursalApiService) {
		this.reDisbursalApiService = reDisbursalApiService;
	}

	public RedisbursalExportReportService getRedisbursalExportReportService() {
		return redisbursalExportReportService;
	}

	public void setRedisbursalExportReportService(
			@Qualifier("redisbursalExportReportService")	RedisbursalExportReportService redisbursalExportReportService) {
		this.redisbursalExportReportService = redisbursalExportReportService;
	}
	
	
}
