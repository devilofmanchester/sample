/**
 * 
 */
package com.shinhan.redisburse.api.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shinhan.redisburse.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.redisburse.core.model.BankStatemenTrxInfo;
import com.shinhan.redisburse.core.constant.APIConstant;
import com.shinhan.redisburse.core.exception.BaseException;
import com.shinhan.redisburse.core.model.BankReDisbursalInf;
import com.shinhan.redisburse.core.util.DateUtils;

/**
 * @author shds01
 *
 */
@RestController
public class ReconcileController extends BaseController{
	
	@RequestMapping(value = "shinhan/service/redisb/redisburs", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public ResponseEntity<Object> getStatementTrxList(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _bankCode,
			
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _endDt,
			
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant.LOAN_NO_KEY, _loanNo);
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		
		List<BankReDisbursalInf> lst = getProcessManagerService().getReDisbursalApiService().getListBankRedisb(inputParams);
		BigDecimal countTotal = getProcessManagerService().getReDisbursalApiService().getCoundListRedisb(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	@RequestMapping(value = "shinhan/service/redisb/redisburs", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.PATCH)
	public ResponseEntity<Object> updateStatementTrxList(@RequestParam(required = false, defaultValue = "") String _start,
			@RequestBody String document,
			@RequestParam(required = false, defaultValue = "") String _number,
			
			@RequestParam(required = false, defaultValue = "") String _loanNo,
			@RequestParam(required = false, defaultValue = "") String _bankCode,
			
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _endDt,
			
			Locale locale) throws BaseException {
		
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._START_KEY, _start);
		inputParams.put(APIConstant._NUMBER_KEY, _number);
		
		inputParams.put(APIConstant.LOAN_NO_KEY, _loanNo);
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		
		List<BankReDisbursalInf> lst = getProcessManagerService().getReDisbursalApiService().updateRedisbProcStatus(inputParams);
		BigDecimal countTotal = getProcessManagerService().getReDisbursalApiService().getCoundListRedisb(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
	@RequestMapping(value = "shinhan/service/redisb/report", produces = {"application/json;charset=utf-8", "application/pdf"}, method = RequestMethod.POST)
	public ResponseEntity<Object> exportReconcileReport(
			@RequestParam(required = true) String _startDt,
			@RequestParam(required = true) String _endDt,
			@RequestParam(required = false, defaultValue = "") String _bankCode,
			@RequestBody String document, Locale locale) throws BaseException, FileNotFoundException {
		
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		inputParams.put(APIConstant._START_DATE_KEY, StringUtils.isBlank(_startDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _startDt);
		inputParams.put(APIConstant._END_DATE_KEY, StringUtils.isBlank(_endDt) ? DateUtils.getSystemDateStr(DateUtils.DATEFORMAT) : _endDt);
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		
		File item = getProcessManagerService().getReDisbursalApiService().exportRedisbInf(inputParams);
		
		if(item == null){
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		
		return triggerSuccessResponseFile(item);
	}
	@RequestMapping(value = "shinhan/service/redisb/disbtrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public ResponseEntity<Object> getUnMatchDisburList(
			@RequestParam(required = true, defaultValue = "") String _ref,
			@RequestParam(required = true) String _bankCode,
			Locale locale) throws BaseException {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		inputParams.put(APIConstant.REF_KEY, _ref);
		
		inputParams.put(APIConstant._BANK_CODE_KEY, _bankCode);
		
		List<BankStatemenTrxInfo> lst = getProcessManagerService().getReDisbursalApiService().getUnmatchListDisbByDate(inputParams);
		BigDecimal countTotal = getProcessManagerService().getReDisbursalApiService().countTotalUnMatchDisbByDate(inputParams);
		
		return triggerSuccessOutPut(lst, countTotal);
	}
}
