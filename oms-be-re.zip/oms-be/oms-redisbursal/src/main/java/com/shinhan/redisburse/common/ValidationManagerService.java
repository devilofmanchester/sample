/**
 * 
 */
package com.shinhan.redisburse.common;

import org.springframework.stereotype.Service;


/**
 * @author shds01
 *
 */
@Service("validationManagerService")
public class ValidationManagerService extends AbstractRepositoryClass{

	
	
}
