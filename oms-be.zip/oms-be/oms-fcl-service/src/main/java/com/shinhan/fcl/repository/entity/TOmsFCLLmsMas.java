/**
 * 
 */
package com.shinhan.fcl.repository.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_FCL_LMS_MAS")
public class TOmsFCLLmsMas implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4844757815682197418L;
	private Long id;

	private String loan_no;
	private String cif;
	private String customer_name;
	private BigDecimal rpa_amount;
	private Date last_due_date;

	private BigDecimal last_payment_amount;
	private Date last_payment_date;
	private String last_payment_bank_ref;

	private BigDecimal principal_bal;
	private BigDecimal interest_amount;
	private BigDecimal last_change_amount;
	private BigDecimal overdue_fee;
	private String delq_status;

	private String customer_phone_no;
	private String collection_account;
	
	private String bank_narration;
	private BigDecimal bank_credit_amount;
	private BigDecimal emi_amount;
	private Date transaction_date;
	private BigDecimal outstanding_principle;
	private BigDecimal excess_amount;
	private BigDecimal penalty_fees;
	private String partner_bank;
	
	private BigDecimal repayment_amount;
	private BigDecimal total_outstanding;
	private String loan_status;
	
	private BigDecimal et_amount;
	private Date simulated_et_date;
	private Date et_form_scan_date;
	private BigDecimal total_to_pay;
	private BigDecimal total_payment_received;
	private String term_status;

	/**
	 * 
	 */
	public TOmsFCLLmsMas() {
		super();
	}

	/**
	 * @return the id
	 */
	@Id
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the loan_no
	 */
	@Column(name = "LOAN_NO")
	public String getLoan_no() {
		return loan_no;
	}

	/**
	 * @param loan_no the loan_no to set
	 */
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}

	/**
	 * @return the cif
	 */
	@Column(name = "CIF")
	public String getCif() {
		return cif;
	}

	/**
	 * @param cif the cif to set
	 */
	public void setCif(String cif) {
		this.cif = cif;
	}

	/**
	 * @return the customer_name
	 */
	@Column(name = "CUSTOMER_NAME")
	public String getCustomer_name() {
		return customer_name;
	}

	/**
	 * @param customer_name the customer_name to set
	 */
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	/**
	 * @return the rpa_amount
	 */
	@Column(name = "RPA_AMOUNT")
	public BigDecimal getRpa_amount() {
		return rpa_amount;
	}

	/**
	 * @param rpa_amount the rpa_amount to set
	 */
	public void setRpa_amount(BigDecimal rpa_amount) {
		this.rpa_amount = rpa_amount;
	}

	/**
	 * @return the last_due_date
	 */
	@Column(name = "LAST_DUE_DATE")
	public Date getLast_due_date() {
		return last_due_date;
	}

	/**
	 * @param last_due_date the last_due_date to set
	 */
	public void setLast_due_date(Date last_due_date) {
		this.last_due_date = last_due_date;
	}

	/**
	 * @return the last_payment_amount
	 */
	@Column(name = "LAST_PAYMENT_AMOUNT")
	public BigDecimal getLast_payment_amount() {
		return last_payment_amount;
	}

	/**
	 * @param last_payment_amount the last_payment_amount to set
	 */
	public void setLast_payment_amount(BigDecimal last_payment_amount) {
		this.last_payment_amount = last_payment_amount;
	}

	/**
	 * @return the last_payment_date
	 */
	@Column(name = "LAST_PAYMENT_DATE")
	public Date getLast_payment_date() {
		return last_payment_date;
	}

	/**
	 * @param last_payment_date the last_payment_date to set
	 */
	public void setLast_payment_date(Date last_payment_date) {
		this.last_payment_date = last_payment_date;
	}

	/**
	 * @return the last_payment_bank_ref
	 */
	@Column(name = "LAST_PAYMENT_BANK_REF")
	public String getLast_payment_bank_ref() {
		return last_payment_bank_ref;
	}

	/**
	 * @param last_payment_bank_ref the last_payment_bank_ref to set
	 */
	public void setLast_payment_bank_ref(String last_payment_bank_ref) {
		this.last_payment_bank_ref = last_payment_bank_ref;
	}

	/**
	 * @return the principal_bal
	 */
	@Column(name = "PRINCIPAL_BAL")
	public BigDecimal getPrincipal_bal() {
		return principal_bal;
	}

	/**
	 * @param principal_bal the principal_bal to set
	 */
	public void setPrincipal_bal(BigDecimal principal_bal) {
		this.principal_bal = principal_bal;
	}

	/**
	 * @return the interest_amount
	 */
	@Column(name = "INTEREST_AMOUNT")
	public BigDecimal getInterest_amount() {
		return interest_amount;
	}

	/**
	 * @param interest_amount the interest_amount to set
	 */
	public void setInterest_amount(BigDecimal interest_amount) {
		this.interest_amount = interest_amount;
	}

	/**
	 * @return the last_change_amount
	 */
	@Column(name = "LAST_CHANGE_AMOUNT")
	public BigDecimal getLast_change_amount() {
		return last_change_amount;
	}

	/**
	 * @param last_change_amount the last_change_amount to set
	 */
	public void setLast_change_amount(BigDecimal last_change_amount) {
		this.last_change_amount = last_change_amount;
	}

	/**
	 * @return the overdue_fee
	 */
	@Column(name = "OVERDUE_FEE")
	public BigDecimal getOverdue_fee() {
		return overdue_fee;
	}

	/**
	 * @param overdue_fee the overdue_fee to set
	 */
	public void setOverdue_fee(BigDecimal overdue_fee) {
		this.overdue_fee = overdue_fee;
	}

	/**
	 * @return the delq_status
	 */
	@Column(name = "DELQ_STATUS")
	public String getDelq_status() {
		return delq_status;
	}

	/**
	 * @param delq_status the delq_status to set
	 */
	public void setDelq_status(String delq_status) {
		this.delq_status = delq_status;
	}

	/**
	 * @return the customer_phone_no
	 */
	@Column(name = "CUSTOMER_PHONE_NO")
	public String getCustomer_phone_no() {
		return customer_phone_no;
	}

	/**
	 * @param customer_phone_no the customer_phone_no to set
	 */
	public void setCustomer_phone_no(String customer_phone_no) {
		this.customer_phone_no = customer_phone_no;
	}

	/**
	 * @return the collection_account
	 */
	@Column(name = "COLLECTION_ACCOUNT")
	public String getCollection_account() {
		return collection_account;
	}

	/**
	 * @param collection_account the collection_account to set
	 */
	public void setCollection_account(String collection_account) {
		this.collection_account = collection_account;
	}

	/**
	 * @return the bank_narration
	 */
	@Column(name = "BANK_NARRATION")
	public String getBank_narration() {
		return bank_narration;
	}

	/**
	 * @param bank_narration the bank_narration to set
	 */
	public void setBank_narration(String bank_narration) {
		this.bank_narration = bank_narration;
	}

	/**
	 * @return the bank_credit_amount
	 */
	@Column(name = "BANK_CREDIT_AMOUNT")
	public BigDecimal getBank_credit_amount() {
		return bank_credit_amount;
	}

	/**
	 * @param bank_credit_amount the bank_credit_amount to set
	 */
	public void setBank_credit_amount(BigDecimal bank_credit_amount) {
		this.bank_credit_amount = bank_credit_amount;
	}

	/**
	 * @return the emi_amount
	 */
	@Column(name = "EMI_AMOUNT")
	public BigDecimal getEmi_amount() {
		return emi_amount;
	}

	/**
	 * @param emi_amount the emi_amount to set
	 */
	public void setEmi_amount(BigDecimal emi_amount) {
		this.emi_amount = emi_amount;
	}

	/**
	 * @return the transaction_date
	 */
	@Column(name = "TRANSACTION_DATE")
	public Date getTransaction_date() {
		return transaction_date;
	}

	/**
	 * @param transaction_date the transaction_date to set
	 */
	public void setTransaction_date(Date transaction_date) {
		this.transaction_date = transaction_date;
	}

	/**
	 * @return the outstanding_principle
	 */
	@Column(name = "OUTSTANDING_PRINCIPLE")
	public BigDecimal getOutstanding_principle() {
		return outstanding_principle;
	}

	/**
	 * @param outstanding_principle the outstanding_principle to set
	 */
	public void setOutstanding_principle(BigDecimal outstanding_principle) {
		this.outstanding_principle = outstanding_principle;
	}

	/**
	 * @return the excess_amount
	 */
	@Column(name = "EXCESS_AMOUNT")
	public BigDecimal getExcess_amount() {
		return excess_amount;
	}

	/**
	 * @param excess_amount the excess_amount to set
	 */
	public void setExcess_amount(BigDecimal excess_amount) {
		this.excess_amount = excess_amount;
	}

	/**
	 * @return the penalty_fees
	 */
	@Column(name = "PENALTY_FEES")
	public BigDecimal getPenalty_fees() {
		return penalty_fees;
	}

	/**
	 * @param penalty_fees the penalty_fees to set
	 */
	public void setPenalty_fees(BigDecimal penalty_fees) {
		this.penalty_fees = penalty_fees;
	}

	/**
	 * @return the partner_bank
	 */
	@Column(name = "PARTNER_BANK")
	public String getPartner_bank() {
		return partner_bank;
	}

	/**
	 * @param partner_bank the partner_bank to set
	 */
	public void setPartner_bank(String partner_bank) {
		this.partner_bank = partner_bank;
	}

	/**
	 * @return the repayment_amount
	 */
	@Column(name = "REPAYMENT_AMOUNT")
	public BigDecimal getRepayment_amount() {
		return repayment_amount;
	}

	/**
	 * @param repayment_amount the repayment_amount to set
	 */
	public void setRepayment_amount(BigDecimal repayment_amount) {
		this.repayment_amount = repayment_amount;
	}

	/**
	 * @return the total_outstanding
	 */
	@Column(name = "TOTAL_OUTSTANDING")
	public BigDecimal getTotal_outstanding() {
		return total_outstanding;
	}

	/**
	 * @param total_outstanding the total_outstanding to set
	 */
	public void setTotal_outstanding(BigDecimal total_outstanding) {
		this.total_outstanding = total_outstanding;
	}

	/**
	 * @return the loan_status
	 */
	@Column(name = "LOAN_STATUS")
	public String getLoan_status() {
		return loan_status;
	}

	/**
	 * @param loan_status the loan_status to set
	 */
	public void setLoan_status(String loan_status) {
		this.loan_status = loan_status;
	}

	/**
	 * @return the et_amount
	 */
	@Column(name = "ET_AMOUNT")
	public BigDecimal getEt_amount() {
		return et_amount;
	}

	/**
	 * @param et_amount the et_amount to set
	 */
	public void setEt_amount(BigDecimal et_amount) {
		this.et_amount = et_amount;
	}

	/**
	 * @return the simulated_et_date
	 */
	@Column(name = "SIMULATED_ET_DATE")
	public Date getSimulated_et_date() {
		return simulated_et_date;
	}

	/**
	 * @param simulated_et_date the simulated_et_date to set
	 */
	public void setSimulated_et_date(Date simulated_et_date) {
		this.simulated_et_date = simulated_et_date;
	}

	/**
	 * @return the et_form_scan_date
	 */
	@Column(name = "ET_FORM_SCAN_DATE")
	public Date getEt_form_scan_date() {
		return et_form_scan_date;
	}

	/**
	 * @param et_form_scan_date the et_form_scan_date to set
	 */
	public void setEt_form_scan_date(Date et_form_scan_date) {
		this.et_form_scan_date = et_form_scan_date;
	}

	/**
	 * @return the total_to_pay
	 */
	@Column(name = "TOTAL_TO_PAY")
	public BigDecimal getTotal_to_pay() {
		return total_to_pay;
	}

	/**
	 * @param total_to_pay the total_to_pay to set
	 */
	public void setTotal_to_pay(BigDecimal total_to_pay) {
		this.total_to_pay = total_to_pay;
	}

	/**
	 * @return the total_payment_received
	 */
	@Column(name = "TOTAL_PAYMENT_RECEIVED")
	public BigDecimal getTotal_payment_received() {
		return total_payment_received;
	}

	/**
	 * @param total_payment_received the total_payment_received to set
	 */
	public void setTotal_payment_received(BigDecimal total_payment_received) {
		this.total_payment_received = total_payment_received;
	}

	/**
	 * @return the term_status
	 */
	@Column(name = "TERM_STATUS")
	public String getTerm_status() {
		return term_status;
	}

	/**
	 * @param term_status the term_status to set
	 */
	public void setTerm_status(String term_status) {
		this.term_status = term_status;
	}

}
