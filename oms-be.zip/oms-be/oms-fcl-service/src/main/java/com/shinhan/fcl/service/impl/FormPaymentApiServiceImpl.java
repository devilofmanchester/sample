/**
 * 
 */
package com.shinhan.fcl.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.service.FormPaymentApiService;

/**
 * @author shds01
 *
 */

@Service("formPaymentApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class FormPaymentApiServiceImpl extends AbstractBasicCommonClass implements FormPaymentApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#getListFormPaymentAvailable(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListFormPaymentAvailable(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getFormPaymentManagerRepositoryService().getListFormPaymentAvailable(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#countFormPaymentAvailableTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countFormPaymentAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getFormPaymentManagerRepositoryService().countFormPaymentAvailableTrx(inputParams);
	}

}
