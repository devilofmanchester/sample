/**
 * 
 */
package com.shinhan.fcl.service;

/**
 * @author shds01
 *
 */
public interface UtilityApiService {
	
	
}
