/**
 * 
 */
package com.shinhan.fcl.api.controller;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Locale;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.fcl.configure.SFTPIntegrationConfiguration.SFTPGateway;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.util.CommonUtil;

/**
 * @author shds01
 *
 */
@RestController
public class UtilityController extends BaseController{

	@Autowired
	private SFTPGateway gatewayOption;
	
	@RequestMapping(value = "shinhan/common/connection", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public String testGet() throws ServiceRuntimeException, InterruptedException {
		return triggerSuccessOutPut(null, JsonObject.class, "connect server successfully");
	}

	@RequestMapping(value = "shinhan/common/exception", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public String testException(Locale locale) throws BaseException {
		testException();
		return "Success";
	}
	
	@Scheduled(cron = "${spring.job.remove.file.everyday}") // 0 PM everyday
	public void cleanFileReport() throws BaseException, IOException {
		logger.info("***** Start remove file export report Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_EXPORT_FCL));
		logger.info("***** End remove file export report Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		logger.info("***** Start remove file waiveOff Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_EXPORT_FCL_WAIVEOFF_DONE));
		logger.info("***** End remove file waiveOff Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		logger.info("***** Start remove file dummy trx Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_EXPORT_FCL_DUMMY_DONE));
		logger.info("***** End remove file dummy trx Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
	
	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.waiveoff.sendToSftp}") // 1 minutes
	public void jobScanTrxToSendingSMSFirstDueDate() throws BaseException, IOException {
		logger.info("***** Start Sent File to SFTP for Waive Trx Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		String[] types = {"csv"};
		Collection<File> files = new ArrayList<File>();
		File ftpOutDir = new File(env.getProperty(APIConstant.PATH_EXPORT_FCL_WAIVEOFF_DONE));
		if (ftpOutDir.exists()) {
			files = FileUtils.listFiles(ftpOutDir, types, true);
		}
		
		for (File file : files) {
			logger.info("***** Start Sent File to SFTP *****");
			logger.info("***** fileName : " + file.getAbsolutePath() +" *****");
			gatewayOption.sendToSftp(file);
			logger.info("***** End Sent File to SFTP *****");
		}
		
		if(CollectionUtils.isNotEmpty(files)) {
			logger.info("***** Start Clean Folder *****");
			CommonUtil.cleanFileInFolder(env.getProperty(APIConstant.PATH_EXPORT_FCL_WAIVEOFF_DONE));
			logger.info("***** End Clean Folder *****");
		}
		
		logger.info("***** End Sent File to SFTP for Waive Trx Task :: Execution Time - " + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
}
