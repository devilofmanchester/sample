/**
 * 
 */
package com.shinhan.fcl.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;

/**
 * @author shds01
 *
 */
public interface FormPaymentManagerRepositoryService {
	
	public List<EarlyTerminationTrx> getListFormPaymentAvailable(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countFormPaymentAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
}
