/**
 * 
 */
package com.shinhan.fcl.core.model;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.util.CommonUtil;

/**
 * @author shds01
 *
 */
public class EarlyTerminationTrx {

	/** TOmsFCLLmsMas */
	private String loan_no;
	private String cif;
	private String customer_name;
	private BigDecimal rpa_amount;
	private Date last_due_date;

	private BigDecimal last_payment_amount;
	private Date last_payment_date;
	private String last_payment_bank_ref;

	private BigDecimal principal_bal;
	private BigDecimal interest_amount;
	private BigDecimal last_change_amount;
	private BigDecimal overdue_fee;
	private String delq_status;

	private String customer_phone_no;
	private String collection_account;

	private String bank_narration;
	private BigDecimal bank_credit_amount;
	private BigDecimal emi_amount;
	private Date transaction_date;
	private BigDecimal outstanding_principle;
	private BigDecimal excess_amount;
	private BigDecimal penalty_fees;
	private String partner_bank;

	private BigDecimal repayment_amount;
	private BigDecimal total_outstanding;
	private String loan_status;

	private BigDecimal et_amount;
	private Date simulated_et_date;
	private Date et_form_scan_date;
	private BigDecimal total_to_pay;
	private BigDecimal total_payment_received;
	private String term_status;

	/** TOmsAutoDebitLmsInf */

	/** TOmsFCLFollowEMIInf */
	private String followup_note;
	
	/** TOmsFCLMaturitynf */
	private String statusCode;
	
	
	/** Other */
	private String day_diff;
	private String day_diff_due_date;
	private String day_diff_pmt_date;
	private String remarks;
	private String errorMessage;
	
	/**
	 * 
	 */
	public EarlyTerminationTrx() {
		super();
	}

	/**
	 * @param loan_no
	 * @param cif
	 * @param customer_name
	 * @param rpa_amount
	 * @param last_due_date
	 * @param last_payment_amount
	 * @param last_payment_date
	 * @param last_payment_bank_ref
	 * @param principal_bal
	 * @param interest_amount
	 * @param last_change_amount
	 * @param overdue_fee
	 * @param delq_status
	 * @param customer_phone_no
	 * @param collection_account
	 * @param bank_narration
	 * @param bank_credit_amount
	 * @param emi_amount
	 * @param transaction_date
	 * @param outstanding_principle
	 * @param excess_amount
	 * @param penalty_fees
	 * @param partner_bank
	 * @param repayment_amount
	 * @param total_outstanding
	 * @param loan_status
	 * @param et_amount
	 * @param simulated_et_date
	 * @param et_form_scan_date
	 * @param total_to_pay
	 * @param total_payment_received
	 * @param term_status
	 * @param errorMessage
	 */
	public EarlyTerminationTrx(String loan_no, String cif, String customer_name, BigDecimal rpa_amount,
			Date last_due_date, BigDecimal last_payment_amount, Date last_payment_date, String last_payment_bank_ref,
			BigDecimal principal_bal, BigDecimal interest_amount, BigDecimal last_change_amount, BigDecimal overdue_fee,
			String delq_status, String customer_phone_no, String collection_account, String bank_narration,
			BigDecimal bank_credit_amount, BigDecimal emi_amount, Date transaction_date,
			BigDecimal outstanding_principle, BigDecimal excess_amount, BigDecimal penalty_fees, String partner_bank,
			BigDecimal repayment_amount, BigDecimal total_outstanding, String loan_status, BigDecimal et_amount,
			Date simulated_et_date, Date et_form_scan_date, BigDecimal total_to_pay, BigDecimal total_payment_received,
			String term_status, String errorMessage) {
		super();
		this.loan_no = loan_no;
		this.cif = cif;
		this.customer_name = customer_name;
		this.rpa_amount = rpa_amount;
		this.last_due_date = last_due_date;
		this.last_payment_amount = last_payment_amount;
		this.last_payment_date = last_payment_date;
		this.last_payment_bank_ref = last_payment_bank_ref;
		this.principal_bal = principal_bal;
		this.interest_amount = interest_amount;
		this.last_change_amount = last_change_amount;
		this.overdue_fee = overdue_fee;
		this.delq_status = delq_status;
		this.customer_phone_no = customer_phone_no;
		this.collection_account = collection_account;
		this.bank_narration = bank_narration;
		this.bank_credit_amount = bank_credit_amount;
		this.emi_amount = emi_amount;
		this.transaction_date = transaction_date;
		this.outstanding_principle = outstanding_principle;
		this.excess_amount = excess_amount;
		this.penalty_fees = penalty_fees;
		this.partner_bank = partner_bank;
		this.repayment_amount = repayment_amount;
		this.total_outstanding = total_outstanding;
		this.loan_status = loan_status;
		this.et_amount = et_amount;
		this.simulated_et_date = simulated_et_date;
		this.et_form_scan_date = et_form_scan_date;
		this.total_to_pay = total_to_pay;
		this.total_payment_received = total_payment_received;
		this.term_status = term_status;
		this.errorMessage = errorMessage;
	}

	// For Form Available

	/**
	 * @param loan_no
	 * @param cif
	 * @param customer_name
	 * @param rpa_amount
	 * @param last_payment_amount
	 * @param last_payment_date
	 * @param et_amount
	 * @param simulated_et_date
	 * @param et_form_scan_date
	 * @param remarks
	 */
	public EarlyTerminationTrx(String loan_no, String cif, String customer_name, BigDecimal rpa_amount,
			BigDecimal last_payment_amount, Date last_payment_date, BigDecimal et_amount, Date simulated_et_date,
			Date et_form_scan_date, String remarks) {
		super();
		this.loan_no = loan_no;
		this.cif = cif;
		this.customer_name = customer_name;
		this.rpa_amount = rpa_amount;
		this.last_payment_amount = last_payment_amount;
		this.last_payment_date = last_payment_date;
		this.et_amount = et_amount;
		this.simulated_et_date = simulated_et_date;
		this.et_form_scan_date = et_form_scan_date;
		this.remarks = remarks;
	}

	// For Payment Available

	/**
	 * @param loan_no
	 * @param cif
	 * @param customer_name
	 * @param rpa_amount
	 * @param last_payment_amount
	 * @param last_payment_date
	 * @param last_payment_bank_ref
	 * @param last_due_date
	 * @param remarks
	 */
	public EarlyTerminationTrx(String loan_no, String cif, String customer_name, BigDecimal rpa_amount,
			BigDecimal last_payment_amount, Date last_payment_date, String last_payment_bank_ref, Date last_due_date, String remarks) {
		super();
		this.loan_no = loan_no;
		this.cif = cif;
		this.customer_name = customer_name;
		this.rpa_amount = rpa_amount;
		this.last_payment_amount = last_payment_amount;
		this.last_payment_date = last_payment_date;
		this.last_payment_bank_ref = last_payment_bank_ref;
		this.last_due_date = last_due_date;
		this.remarks = remarks;
	}
	
	// For Form & Payment Available

	/**
	 * @param loan_no
	 * @param cif
	 * @param customer_name
	 * @param rpa_amount
	 * @param last_payment_amount
	 * @param last_payment_date
	 * @param last_payment_bank_ref
	 * @param et_amount
	 * @param simulated_et_date
	 * @param et_form_scan_date
	 */
	public EarlyTerminationTrx(String loan_no, String cif, String customer_name, BigDecimal rpa_amount,
			BigDecimal last_payment_amount, Date last_payment_date, String last_payment_bank_ref, BigDecimal et_amount,
			Date simulated_et_date, Date et_form_scan_date) {
		super();
		this.loan_no = loan_no;
		this.cif = cif;
		this.customer_name = customer_name;
		this.rpa_amount = rpa_amount;
		this.last_payment_amount = last_payment_amount;
		this.last_payment_date = last_payment_date;
		this.last_payment_bank_ref = last_payment_bank_ref;
		this.et_amount = et_amount;
		this.simulated_et_date = simulated_et_date;
		this.et_form_scan_date = et_form_scan_date;
	}

	// For Maturity Waive
	
	/**
	 * @param loan_no
	 * @param cif
	 * @param customer_name
	 * @param rpa_amount
	 * @param last_due_date
	 * @param principal_bal
	 * @param interest_amount
	 * @param last_change_amount
	 * @param overdue_fee
	 * @param delq_status
	 * @param day_diff
	 * @param statusCode
	 */
	public EarlyTerminationTrx(String loan_no, String cif, String customer_name, BigDecimal rpa_amount,
			Date last_due_date, BigDecimal principal_bal, BigDecimal interest_amount, BigDecimal last_change_amount,
			BigDecimal overdue_fee, String delq_status, double day_diff, String statusCode) {
		
		super();
		this.loan_no = loan_no;
		this.cif = cif;
		this.customer_name = customer_name;
		this.rpa_amount = rpa_amount;
		this.last_due_date = last_due_date;
		this.principal_bal = principal_bal;
		this.interest_amount = interest_amount;
		this.last_change_amount = last_change_amount;
		this.overdue_fee = overdue_fee;
		this.delq_status = delq_status;
		this.day_diff = CommonUtil.writeDecimal(day_diff, APIConstant.FORMAT_FACTOR);
		this.statusCode = statusCode;
		
	}
	
	// For Maturity Book Inc
	
	/**
	 * @param loan_no
	 * @param cif
	 * @param customer_name
	 * @param rpa_amount
	 * @param last_due_date
	 * @param last_payment_date
	 * @param principal_bal
	 * @param last_change_amount
	 * @param overdue_fee
	 * @param delq_status
	 * @param day_diff_due_date
	 * @param day_diff_pmt_date
	 */
	public EarlyTerminationTrx(String loan_no, String cif, String customer_name, BigDecimal rpa_amount,
			Date last_due_date, Date last_payment_date, BigDecimal principal_bal, BigDecimal last_change_amount,
			BigDecimal overdue_fee, String delq_status, double day_diff_due_date, double day_diff_pmt_date) {
		super();
		this.loan_no = loan_no;
		this.cif = cif;
		this.customer_name = customer_name;
		this.rpa_amount = rpa_amount;
		this.last_due_date = last_due_date;
		this.last_payment_date = last_payment_date;
		this.principal_bal = principal_bal;
		this.last_change_amount = last_change_amount;
		this.overdue_fee = overdue_fee;
		this.delq_status = delq_status;
		this.day_diff_due_date = CommonUtil.writeDecimal(day_diff_due_date, APIConstant.FORMAT_FACTOR);
		this.day_diff_pmt_date = CommonUtil.writeDecimal(day_diff_pmt_date, APIConstant.FORMAT_FACTOR);
	}

	// For Maturity Refund
	
	/**
	 * @param loan_no
	 * @param cif
	 * @param customer_name
	 * @param rpa_amount
	 * @param last_due_date
	 * @param last_payment_date
	 * @param principal_bal
	 * @param interest_amount
	 * @param last_change_amount
	 * @param overdue_fee
	 * @param delq_status
	 * @param day_diff
	 */
	public EarlyTerminationTrx(String loan_no, String cif, String customer_name, BigDecimal rpa_amount,
			Date last_due_date, Date last_payment_date, BigDecimal principal_bal, BigDecimal interest_amount, BigDecimal last_change_amount,
			BigDecimal overdue_fee, String delq_status, double day_diff) {
		super();
		this.loan_no = loan_no;
		this.cif = cif;
		this.customer_name = customer_name;
		this.rpa_amount = rpa_amount;
		this.last_due_date = last_due_date;
		this.last_payment_date = last_payment_date;
		this.principal_bal = principal_bal;
		this.interest_amount = interest_amount;
		this.last_change_amount = last_change_amount;
		this.overdue_fee = overdue_fee;
		this.delq_status = delq_status;
		this.day_diff = CommonUtil.writeDecimal(day_diff, APIConstant.FORMAT_FACTOR);
	}
	
	// For Follow Up 3EMI
	
	/**
	 * @param loan_no
	 * @param cif
	 * @param customer_name
	 * @param customer_phone_no
	 * @param last_due_date
	 * @param last_payment_bank_ref
	 * @param collection_account
	 * @param bank_narration
	 * @param bank_credit_amount
	 * @param emi_amount
	 * @param transaction_date
	 * @param outstanding_principle
	 * @param excess_amount
	 * @param penalty_fees
	 * @param partner_bank
	 * @param followup_note
	 * @param remarks
	 */
	public EarlyTerminationTrx(String loan_no, String cif, String customer_name, String customer_phone_no, Date last_due_date,
			String last_payment_bank_ref, String collection_account, String bank_narration,
			BigDecimal bank_credit_amount, BigDecimal emi_amount, Date transaction_date,
			BigDecimal outstanding_principle, BigDecimal excess_amount, BigDecimal penalty_fees, String partner_bank,
			String followup_note, String remarks) {
		super();
		this.loan_no = loan_no;
		this.cif = cif;
		this.customer_name = customer_name;
		this.customer_phone_no = customer_phone_no;
		this.last_due_date = last_due_date;
		this.last_payment_bank_ref = last_payment_bank_ref;
		this.collection_account = collection_account;
		this.bank_narration = bank_narration;
		this.bank_credit_amount = bank_credit_amount;
		this.emi_amount = emi_amount;
		this.transaction_date = transaction_date;
		this.outstanding_principle = outstanding_principle;
		this.excess_amount = excess_amount;
		this.penalty_fees = penalty_fees;
		this.partner_bank = partner_bank;
		this.followup_note = followup_note;
		this.remarks = remarks;
	}
	
	/**
	 * @return the loan_no
	 */
	public String getLoan_no() {
		return loan_no;
	}
	
	/**
	 * @param loan_no the loan_no to set
	 */
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}

	/**
	 * @return the cif
	 */
	public String getCif() {
		return cif;
	}

	/**
	 * @param cif the cif to set
	 */
	public void setCif(String cif) {
		this.cif = cif;
	}

	/**
	 * @return the customer_name
	 */
	public String getCustomer_name() {
		return customer_name;
	}

	/**
	 * @param customer_name the customer_name to set
	 */
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	/**
	 * @return the rpa_amount
	 */
	public BigDecimal getRpa_amount() {
		return rpa_amount;
	}

	/**
	 * @param rpa_amount the rpa_amount to set
	 */
	public void setRpa_amount(BigDecimal rpa_amount) {
		this.rpa_amount = rpa_amount;
	}

	/**
	 * @return the last_due_date
	 */
	public Date getLast_due_date() {
		return last_due_date;
	}

	/**
	 * @param last_due_date the last_due_date to set
	 */
	public void setLast_due_date(Date last_due_date) {
		this.last_due_date = last_due_date;
	}

	/**
	 * @return the last_payment_amount
	 */
	public BigDecimal getLast_payment_amount() {
		return last_payment_amount;
	}

	/**
	 * @param last_payment_amount the last_payment_amount to set
	 */
	public void setLast_payment_amount(BigDecimal last_payment_amount) {
		this.last_payment_amount = last_payment_amount;
	}

	/**
	 * @return the last_payment_date
	 */
	public Date getLast_payment_date() {
		return last_payment_date;
	}

	/**
	 * @param last_payment_date the last_payment_date to set
	 */
	public void setLast_payment_date(Date last_payment_date) {
		this.last_payment_date = last_payment_date;
	}

	/**
	 * @return the last_payment_bank_ref
	 */
	public String getLast_payment_bank_ref() {
		return last_payment_bank_ref;
	}

	/**
	 * @param last_payment_bank_ref the last_payment_bank_ref to set
	 */
	public void setLast_payment_bank_ref(String last_payment_bank_ref) {
		this.last_payment_bank_ref = last_payment_bank_ref;
	}

	/**
	 * @return the principal_bal
	 */
	public BigDecimal getPrincipal_bal() {
		return principal_bal;
	}

	/**
	 * @param principal_bal the principal_bal to set
	 */
	public void setPrincipal_bal(BigDecimal principal_bal) {
		this.principal_bal = principal_bal;
	}

	/**
	 * @return the interest_amount
	 */
	public BigDecimal getInterest_amount() {
		return interest_amount;
	}

	/**
	 * @param interest_amount the interest_amount to set
	 */
	public void setInterest_amount(BigDecimal interest_amount) {
		this.interest_amount = interest_amount;
	}

	/**
	 * @return the last_change_amount
	 */
	public BigDecimal getLast_change_amount() {
		return last_change_amount;
	}

	/**
	 * @param last_change_amount the last_change_amount to set
	 */
	public void setLast_change_amount(BigDecimal last_change_amount) {
		this.last_change_amount = last_change_amount;
	}

	/**
	 * @return the overdue_fee
	 */
	public BigDecimal getOverdue_fee() {
		return overdue_fee;
	}

	/**
	 * @param overdue_fee the overdue_fee to set
	 */
	public void setOverdue_fee(BigDecimal overdue_fee) {
		this.overdue_fee = overdue_fee;
	}

	/**
	 * @return the delq_status
	 */
	public String getDelq_status() {
		return delq_status;
	}

	/**
	 * @param delq_status the delq_status to set
	 */
	public void setDelq_status(String delq_status) {
		this.delq_status = delq_status;
	}

	/**
	 * @return the customer_phone_no
	 */
	public String getCustomer_phone_no() {
		return customer_phone_no;
	}

	/**
	 * @param customer_phone_no the customer_phone_no to set
	 */
	public void setCustomer_phone_no(String customer_phone_no) {
		this.customer_phone_no = customer_phone_no;
	}

	/**
	 * @return the collection_account
	 */
	public String getCollection_account() {
		return collection_account;
	}

	/**
	 * @param collection_account the collection_account to set
	 */
	public void setCollection_account(String collection_account) {
		this.collection_account = collection_account;
	}

	/**
	 * @return the bank_narration
	 */
	public String getBank_narration() {
		return bank_narration;
	}

	/**
	 * @param bank_narration the bank_narration to set
	 */
	public void setBank_narration(String bank_narration) {
		this.bank_narration = bank_narration;
	}

	/**
	 * @return the bank_credit_amount
	 */
	public BigDecimal getBank_credit_amount() {
		return bank_credit_amount;
	}

	/**
	 * @param bank_credit_amount the bank_credit_amount to set
	 */
	public void setBank_credit_amount(BigDecimal bank_credit_amount) {
		this.bank_credit_amount = bank_credit_amount;
	}

	/**
	 * @return the emi_amount
	 */
	public BigDecimal getEmi_amount() {
		return emi_amount;
	}

	/**
	 * @param emi_amount the emi_amount to set
	 */
	public void setEmi_amount(BigDecimal emi_amount) {
		this.emi_amount = emi_amount;
	}

	/**
	 * @return the transaction_date
	 */
	public Date getTransaction_date() {
		return transaction_date;
	}

	/**
	 * @param transaction_date the transaction_date to set
	 */
	public void setTransaction_date(Date transaction_date) {
		this.transaction_date = transaction_date;
	}

	/**
	 * @return the outstanding_principle
	 */
	public BigDecimal getOutstanding_principle() {
		return outstanding_principle;
	}

	/**
	 * @param outstanding_principle the outstanding_principle to set
	 */
	public void setOutstanding_principle(BigDecimal outstanding_principle) {
		this.outstanding_principle = outstanding_principle;
	}

	/**
	 * @return the excess_amount
	 */
	public BigDecimal getExcess_amount() {
		return excess_amount;
	}

	/**
	 * @param excess_amount the excess_amount to set
	 */
	public void setExcess_amount(BigDecimal excess_amount) {
		this.excess_amount = excess_amount;
	}

	/**
	 * @return the penalty_fees
	 */
	public BigDecimal getPenalty_fees() {
		return penalty_fees;
	}

	/**
	 * @param penalty_fees the penalty_fees to set
	 */
	public void setPenalty_fees(BigDecimal penalty_fees) {
		this.penalty_fees = penalty_fees;
	}

	/**
	 * @return the partner_bank
	 */
	public String getPartner_bank() {
		return partner_bank;
	}

	/**
	 * @param partner_bank the partner_bank to set
	 */
	public void setPartner_bank(String partner_bank) {
		this.partner_bank = partner_bank;
	}

	/**
	 * @return the repayment_amount
	 */
	public BigDecimal getRepayment_amount() {
		return repayment_amount;
	}

	/**
	 * @param repayment_amount the repayment_amount to set
	 */
	public void setRepayment_amount(BigDecimal repayment_amount) {
		this.repayment_amount = repayment_amount;
	}

	/**
	 * @return the total_outstanding
	 */
	public BigDecimal getTotal_outstanding() {
		return total_outstanding;
	}

	/**
	 * @param total_outstanding the total_outstanding to set
	 */
	public void setTotal_outstanding(BigDecimal total_outstanding) {
		this.total_outstanding = total_outstanding;
	}

	/**
	 * @return the loan_status
	 */
	public String getLoan_status() {
		return loan_status;
	}

	/**
	 * @param loan_status the loan_status to set
	 */
	public void setLoan_status(String loan_status) {
		this.loan_status = loan_status;
	}

	/**
	 * @return the et_amount
	 */
	public BigDecimal getEt_amount() {
		return et_amount;
	}

	/**
	 * @param et_amount the et_amount to set
	 */
	public void setEt_amount(BigDecimal et_amount) {
		this.et_amount = et_amount;
	}

	/**
	 * @return the simulated_et_date
	 */
	public Date getSimulated_et_date() {
		return simulated_et_date;
	}

	/**
	 * @param simulated_et_date the simulated_et_date to set
	 */
	public void setSimulated_et_date(Date simulated_et_date) {
		this.simulated_et_date = simulated_et_date;
	}

	/**
	 * @return the et_form_scan_date
	 */
	public Date getEt_form_scan_date() {
		return et_form_scan_date;
	}

	/**
	 * @param et_form_scan_date the et_form_scan_date to set
	 */
	public void setEt_form_scan_date(Date et_form_scan_date) {
		this.et_form_scan_date = et_form_scan_date;
	}

	/**
	 * @return the total_to_pay
	 */
	public BigDecimal getTotal_to_pay() {
		return total_to_pay;
	}

	/**
	 * @param total_to_pay the total_to_pay to set
	 */
	public void setTotal_to_pay(BigDecimal total_to_pay) {
		this.total_to_pay = total_to_pay;
	}

	/**
	 * @return the total_payment_received
	 */
	public BigDecimal getTotal_payment_received() {
		return total_payment_received;
	}

	/**
	 * @param total_payment_received the total_payment_received to set
	 */
	public void setTotal_payment_received(BigDecimal total_payment_received) {
		this.total_payment_received = total_payment_received;
	}

	/**
	 * @return the term_status
	 */
	public String getTerm_status() {
		return term_status;
	}

	/**
	 * @param term_status the term_status to set
	 */
	public void setTerm_status(String term_status) {
		this.term_status = term_status;
	}

	/**
	 * @return the followup_note
	 */
	public String getFollowup_note() {
		return followup_note;
	}

	/**
	 * @param followup_note the followup_note to set
	 */
	public void setFollowup_note(String followup_note) {
		this.followup_note = followup_note;
	}

	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the day_diff
	 */
	public String getDay_diff() {
		return day_diff;
	}

	/**
	 * @param day_diff the day_diff to set
	 */
	public void setDay_diff(String day_diff) {
		this.day_diff = day_diff;
	}

	/**
	 * @return the day_diff_due_date
	 */
	public String getDay_diff_due_date() {
		return day_diff_due_date;
	}

	/**
	 * @param day_diff_due_date the day_diff_due_date to set
	 */
	public void setDay_diff_due_date(String day_diff_due_date) {
		this.day_diff_due_date = day_diff_due_date;
	}

	/**
	 * @return the day_diff_pmt_date
	 */
	public String getDay_diff_pmt_date() {
		return day_diff_pmt_date;
	}

	/**
	 * @param day_diff_pmt_date the day_diff_pmt_date to set
	 */
	public void setDay_diff_pmt_date(String day_diff_pmt_date) {
		this.day_diff_pmt_date = day_diff_pmt_date;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public boolean getValid() {
		if (StringUtils.isNotBlank(errorMessage)) {
			return false;
		}
		return true;
	}
}
