/**
 * 
 */
package com.shinhan.fcl.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.repository.entity.TOmsFCLMaturitynf;

/**
 * @author shds01
 *
 */
public interface MaturityManagerRepositoryService {
	
	public List<EarlyTerminationTrx> getListMaturityWaiveOff(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countMaturityWaiveOffTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<Object[]> exportReportWaiveOffTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public List<EarlyTerminationTrx> getListMaturityBookInc(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countMaturityBookIncTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> getListMaturityRefund(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countMaturityRefundTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<Object[]> exportReportRefundDoneTrx(String startDt, String endDt) throws ServiceRuntimeException, ServiceInvalidAgurmentException;
	
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public TOmsFCLMaturitynf getMaturityTrxByLoanNo(String loanNo) throws ServiceRuntimeException;
	
}
