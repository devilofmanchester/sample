/**
 * 
 */
package com.shinhan.fcl.common;

import java.io.File;
import java.io.PrintWriter;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.WaiveOffDocumentTrx;
import com.shinhan.fcl.core.util.CommonUtil;

/**
 * @author shds01
 *
 */
public abstract class AbstractBasicCommonClass extends AbstractServiceClass {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	public static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

	@Autowired
	public Environment env;

	@Autowired
	protected HttpServletRequest httpServletRequest;

	@Autowired
	protected HttpServletResponse httpServletResponse;

	protected String testException() throws ServiceRuntimeException {
		try {
			String a = "";
			String c = "";
			int b = Integer.parseInt(a) + Integer.parseInt(c);
			return String.valueOf(b);
		} catch (Exception e) {
			logger.info(e.getMessage());
			throw new ServiceRuntimeException("Errror ", e.getCause());
		}
	}

	public boolean writeCSVFileToWaiveOff(List<WaiveOffDocumentTrx> docs, String pathDir, String fileName) throws ServiceRuntimeException  {
		try {
			logger.info(" Start writeCSVFileToWaiveOff ");
			logger.info("Create process CSV : " + pathDir + fileName);
			File processTxt = new File(pathDir + fileName);
			PrintWriter pw = new PrintWriter(processTxt);
			for(WaiveOffDocumentTrx doc : docs){
				logger.info("icm process Str : " + doc.generateWaiveString());
				pw.println(doc.generateWaiveString());
			}
			pw.close();
			
			logger.info("Copy to FTP Waiveoff folder: " + pathDir + fileName);
			CommonUtil.copyFile(processTxt, new File(APIConstant.PATH_EXPORT_FCL_WAIVEOFF_DONE + fileName));
			
			logger.info(" End writeCSVFileToWaiveOff ");
			return true;
		} catch(Exception ex) {
			throw new ServiceRuntimeException("Errror ", ex.getCause());
		}
		
	}
}
