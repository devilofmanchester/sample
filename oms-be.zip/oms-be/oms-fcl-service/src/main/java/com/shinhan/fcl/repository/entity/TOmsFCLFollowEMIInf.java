/**
 * 
 */
package com.shinhan.fcl.repository.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_FCL_FOLLOWEMI_INF")
public class TOmsFCLFollowEMIInf implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String loanNo;
	private String statusCode;
	private String remarks;
	private String createdUser;
	private Date createdDt;
	private String updatedUser;
	private Date updatedDt;

	/**
	 * 
	 */
	public TOmsFCLFollowEMIInf() {
		super();
	}

	/**
	 * @param loanNo
	 * @param statusCode
	 * @param remarks
	 * @param createdUser
	 * @param createdDt
	 * @param updatedUser
	 * @param updatedDt
	 */
	public TOmsFCLFollowEMIInf(String loanNo, String statusCode, String remarks, String createdUser, Date createdDt, String updatedUser,
			Date updatedDt) {
		super();
		this.loanNo = loanNo;
		this.statusCode = statusCode;
		this.remarks = remarks;
		this.createdUser = createdUser;
		this.createdDt = createdDt;
		this.updatedUser = updatedUser;
		this.updatedDt = updatedDt;
	}

	/**
	 * @return the loanNo
	 */
	@Id
	@Column(name = "LOAN_NO")
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the statusCode
	 */
	@Column(name = "STATUS_CODE")
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the remarks
	 */
	@Column(name = "REMARKS")
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the createdUser
	 */
	@Column(name = "REGIS_INF_USER")
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * @param createdUser the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * @return the createdDt
	 */
	@Column(name = "REGIS_INF_DT")
	public Date getCreatedDt() {
		return createdDt;
	}

	/**
	 * @param createdDt the createdDt to set
	 */
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	/**
	 * @return the updatedUser
	 */
	@Column(name = "LCHG_INF_USER")
	public String getUpdatedUser() {
		return updatedUser;
	}

	/**
	 * @param updatedUser the updatedUser to set
	 */
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	/**
	 * @return the updatedDt
	 */
	@Column(name = "LCHG_INF_DT")
	public Date getUpdatedDt() {
		return updatedDt;
	}

	/**
	 * @param updatedDt the updatedDt to set
	 */
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

}
