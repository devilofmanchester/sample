/**
 * 
 */
package com.shinhan.fcl.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.service.UtilityApiService;

/**
 * @author shds01
 *
 */

@Service("utilityApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class UtilityApiServiceImpl extends AbstractBasicCommonClass implements UtilityApiService {


}
