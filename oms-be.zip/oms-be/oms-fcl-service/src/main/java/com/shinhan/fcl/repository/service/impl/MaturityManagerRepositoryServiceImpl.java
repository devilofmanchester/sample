/**
 * 
 */
package com.shinhan.fcl.repository.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.fcl.common.AbstractServiceClass;
import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.util.DateUtils;
import com.shinhan.fcl.repository.dao.TOmsFCLLmsMasDAO;
import com.shinhan.fcl.repository.dao.TOmsFCLMaturityDAO;
import com.shinhan.fcl.repository.entity.TOmsFCLMaturitynf;
import com.shinhan.fcl.repository.service.MaturityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("maturityManagerRepositoryService")
public class MaturityManagerRepositoryServiceImpl extends AbstractServiceClass
		implements MaturityManagerRepositoryService {

	private TOmsFCLLmsMasDAO objectMasDao;
	
	private TOmsFCLMaturityDAO objectMaturityDao;

	@Autowired
	public MaturityManagerRepositoryServiceImpl(TOmsFCLLmsMasDAO objectMasDao, TOmsFCLMaturityDAO objectMaturityDao) {
		this.objectMasDao = objectMasDao;
		this.objectMaturityDao = objectMaturityDao;
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormManagerRepositoryService#getListMaturityWaiveOff(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListMaturityWaiveOff(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String sql = "SELECT new com.shinhan.fcl.core.model.EarlyTerminationTrx("
					
					+ "mas.loan_no, mas.cif, mas.customer_name, mas.rpa_amount, "
					+ "mas.last_due_date, mas.principal_bal, mas.interest_amount, mas.last_change_amount, "
					+ "mas.overdue_fee, mas.delq_status, "
					+ "to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - to_date(to_char(mas.last_due_date, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') as day_diff, "
					+ "inf.statusCode "
					+ ") "
					+ "from TOmsFCLLmsMas mas left join TOmsFCLMaturitynf inf on mas.loan_no = inf.loanNo "
					+ "where UPPER(mas.loan_status) = :loan_status "
					+ "and UPPER(mas.delq_status) in ('REG', 'TB1', 'TB2', 'TB3', 'TB4', 'TB5') "
					+ "and :current_date > mas.last_due_date "
					+ "and (mas.principal_bal = 0 or mas.principal_bal is null) "
					+ "and (mas.interest_amount = 0 or mas.interest_amount is null) "
					+ "and (mas.rpa_amount = 0 or mas.rpa_amount is null) "
					+ "and (inf.statusCode is null or inf.statusCode != :statusCode ) "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					
					;
		
			String orderBy = " order by mas.last_due_date asc";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_ACTIVE);
			query.setParameter("current_date", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
			query.setParameter("sys_date", DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
			query.setParameter("statusCode", APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			@SuppressWarnings("unchecked")
			List<EarlyTerminationTrx> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.FormManagerRepositoryService#countMaturityWaiveOffTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countMaturityWaiveOffTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String sql = "select count(mas.loan_no) from oms_fcl_lms_mas mas left join oms_fcl_maturity_inf inf on mas.loan_no = inf.loan_no "
					+ "where UPPER(mas.loan_status) = :loan_status "
					+ "and UPPER(mas.delq_status) in ('REG', 'TB1', 'TB2', 'TB3', 'TB4', 'TB5') "
					+ "and :current_date > mas.last_due_date "
					+ "and (mas.principal_bal = 0 or mas.principal_bal is null) "
					+ "and (mas.interest_amount = 0 or mas.interest_amount is null) "
					+ "and (mas.rpa_amount = 0 or mas.rpa_amount is null) "
					+ "and (inf.status_code is null or inf.status_code != :statusCode) "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					;
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_ACTIVE);
			query.setParameter("current_date", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
			query.setParameter("statusCode", APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.MaturityManagerRepositoryService#exportReportWaiveOffTrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportWaiveOffTrx(String startDt, String endDt)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		try {
			String sql = "SELECT "
					+ "mas.loan_no, mas.customer_name, mas.delq_status, "
					+ "mas.last_due_date, mas.principal_bal, mas.interest_amount, "
					+ "mas.last_change_amount, mas.overdue_fee, mas.rpa_amount, mas.cif "
					
					+ "from TOmsFCLLmsMas mas "
					+ "where UPPER(mas.loan_status) = :loan_status "
					+ "and UPPER(mas.delq_status) = '"+APIConstant.LOAN_DELQ_STATUS_TB6+"'"
					+ "and :current_date > mas.last_due_date "
					+ "and (mas.principal_bal = 0 or mas.principal_bal is null) "
					+ "and (mas.interest_amount = 0 or mas.interest_amount is null) "
					+ "and (mas.rpa_amount = 0 or mas.rpa_amount is null) "
					;
			
			String orderBy = "order by mas.last_due_date asc, mas.loan_no asc ";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_ACTIVE);
			query.setParameter("current_date", DateUtils.getCurrentDate(DateUtils.DATEFORMAT));
			
			List<Object[]> list = query.getResultList();
			if(CollectionUtils.isEmpty(list)) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			return list;
		} catch (ServiceInvalidAgurmentException ex) {
			throw new ServiceInvalidAgurmentException(ex.getMessage());
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.MaturityManagerRepositoryService#getListMaturityBookInc(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListMaturityBookInc(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String sql = "SELECT new com.shinhan.fcl.core.model.EarlyTerminationTrx("
					
					+ "mas.loan_no, mas.cif, mas.customer_name, mas.rpa_amount, "
					+ "mas.last_due_date, mas.last_payment_date, mas.principal_bal, mas.last_change_amount, "
					+ "mas.overdue_fee, mas.delq_status, "
					+ "to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - to_date(to_char(mas.last_due_date, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') as day_diff_due_date, "
					+ "to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - to_date(to_char(mas.last_payment_date, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') as day_diff_pmt_date "
					
					+ ") "
					+ "from TOmsFCLLmsMas mas "
					+ "where UPPER(mas.loan_status) = :loan_status "
					
					+ "and ((to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - mas.last_due_date > 1 and rpa_amount > 0 and rpa_amount < 10000) or (to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - mas.last_payment_date >= 21 and rpa_amount > 10000 and rpa_amount < 50000 ) ) "
					
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					+ "and NOT EXISTS (select loanNo from TOmsFCLMaturitynf inf where inf.statusCode = '"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE+"' and mas.loan_no = inf.loanNo) "
					;
		
			String orderBy = " order by mas.rpa_amount asc, day_diff_due_date asc, day_diff_pmt_date asc";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_ACTIVE);
			query.setParameter("sys_date", DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			@SuppressWarnings("unchecked")
			List<EarlyTerminationTrx> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.MaturityManagerRepositoryService#countMaturityBookIncTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countMaturityBookIncTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String sql = "select count(*) from oms_fcl_lms_mas mas "
					+ "where UPPER(mas.loan_status) = :loan_status "
					+ "and ((to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - mas.last_due_date > 1 and rpa_amount > 0 and rpa_amount < 10000) or (to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - mas.last_payment_date >= 21 and rpa_amount > 10000 and rpa_amount < 50000 ) ) "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					+ "and NOT EXISTS (select loan_no from oms_fcl_maturity_inf inf where inf.status_code = '"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE+"' and mas.loan_no = inf.loan_no) "
					;
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_ACTIVE);
			query.setParameter("sys_date", DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.MaturityManagerRepositoryService#getListMaturityRefund(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListMaturityRefund(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		try {
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			String sql = "SELECT new com.shinhan.fcl.core.model.EarlyTerminationTrx("
					
					+ "mas.loan_no, mas.cif, mas.customer_name, mas.rpa_amount, "
					+ "mas.last_due_date, mas.last_payment_date, mas.principal_bal, mas.interest_amount, mas.last_change_amount, "
					+ "mas.overdue_fee, mas.delq_status, "
					+ "to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - to_date(to_char(mas.last_payment_date, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') as day_diff "
					
					+ ") "
					+ "from TOmsFCLLmsMas mas "
					+ "where UPPER(mas.loan_status) = :loan_status "
					
					+ "and (to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - mas.last_due_date >= 21 and rpa_amount >= 50000 ) "
					
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					+ "and NOT EXISTS (select loanNo from TOmsFCLMaturitynf inf where inf.statusCode = '"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE+"' and mas.loan_no = inf.loanNo) "
					;
		
			String orderBy = " order by mas.rpa_amount asc, day_diff asc";
			
			Query query = entityManager.createQuery(sql + orderBy);
			
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_ACTIVE);
			query.setParameter("sys_date", DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			@SuppressWarnings("unchecked")
			List<EarlyTerminationTrx> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.MaturityManagerRepositoryService#countMaturityRefundTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countMaturityRefundTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			String sql = "select count(*) from oms_fcl_lms_mas mas "
					+ "where UPPER(mas.loan_status) = :loan_status "
					+ "and (to_date(:sys_date,'"+DateUtils.DATEFORMAT+"') - mas.last_due_date >= 21 and rpa_amount >= 50000 ) "
					+ "and (:loanNo is NULL or mas.loan_no = :loanNo) "
					+ "and (:cifNo is NULL or mas.cif = :cifNo) "
					+ "and NOT EXISTS (select loan_no from oms_fcl_maturity_inf inf where inf.status_code = '"+APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE+"' and mas.loan_no = inf.loan_no) "
					;
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_ACTIVE);
			query.setParameter("sys_date", DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
			
			query.setParameter("loanNo", inputParams.get(APIConstant._LOAN_NO).toString());
			query.setParameter("cifNo", inputParams.get(APIConstant._CIF_NO).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.MaturityManagerRepositoryService#exportReportRefundDoneTrx(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Object[]> exportReportRefundDoneTrx(String startDt, String endDt)
			throws ServiceRuntimeException, ServiceInvalidAgurmentException {
		try {
			String sql = "SELECT "
					+ "rownum, sub.* from ( "
					+ "SELECT "
					+ "mas.loan_no, mas.customer_name, "
					+ "inf.lchg_inf_dt, inf.rpa_amount, inf.lchg_inf_user "
					+ "from oms_fcl_maturity_inf inf left join oms_fcl_lms_mas mas on inf.loan_no = mas.loan_no "
					+ "where to_date(to_char(inf.lchg_inf_dt, '"+DateUtils.DATEFORMAT+"'),'"+DateUtils.DATEFORMAT+"') between :startDt and :endDt "
					+ "and UPPER(inf.status_code) = :statusCode and inf.rpa_amount is not null "
					+ "and UPPER(mas.loan_status) = :loan_status "
					;
			
			String orderBy = " order by inf.lchg_inf_dt asc) sub";
			
			Query query = entityManager.createNativeQuery(sql + orderBy);
			
			query.setParameter("startDt", DateUtils.converToDate(startDt));
			query.setParameter("endDt", DateUtils.converToDate(endDt));
			
			query.setParameter("statusCode", APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE);
			query.setParameter("loan_status", APIConstant.LOAN_STATUS_CLOSE);
			
			List<Object[]> list = query.getResultList();
			if(CollectionUtils.isEmpty(list)) {
				throw new ServiceInvalidAgurmentException(String.format(env.getProperty("MSG_017"), startDt, endDt));
			}
			return list;
		} catch (ServiceInvalidAgurmentException ex) {
			throw new ServiceInvalidAgurmentException(ex.getMessage());
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}
	
	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.MaturityManagerRepositoryService#createAll(java.util.Map)
	 */
	@Override
	public boolean createAll(Map<String, Object> inputParams) throws ServiceRuntimeException {
		try {
			@SuppressWarnings("unchecked")
			List<TOmsFCLMaturitynf> items = (List<TOmsFCLMaturitynf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectMaturityDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.repository.service.MaturityManagerRepositoryService#getMaturityTrxByLoanNo(java.lang.String)
	 */
	@Override
	public TOmsFCLMaturitynf getMaturityTrxByLoanNo(String loanNo) throws ServiceRuntimeException {
		if (StringUtils.isBlank(loanNo)) {
			return null;
		}
		try {
			TOmsFCLMaturitynf item = objectMaturityDao.getItemByLoanNo(loanNo);
			return item;
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + loanNo + "");
		}
	}
	
}
