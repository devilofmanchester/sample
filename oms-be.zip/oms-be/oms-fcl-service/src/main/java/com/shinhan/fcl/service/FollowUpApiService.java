/**
 * 
 */
package com.shinhan.fcl.service;

import java.io.File;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.fcl.core.exception.BaseException;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;

/**
 * @author shds01
 *
 */
public interface FollowUpApiService {
	
	public List<EarlyTerminationTrx> getListFollowUpEMI(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countFollowUpEMITrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<EarlyTerminationTrx> updateNoteFollowUpEMI(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public File exportReportByTemplate(Map<String, Object> inputParams) throws BaseException;
	
}
