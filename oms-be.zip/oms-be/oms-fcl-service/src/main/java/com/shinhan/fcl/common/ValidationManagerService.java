/**
 * 
 */
package com.shinhan.fcl.common;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.shinhan.fcl.core.constant.APIConstant;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.core.util.DTOConverter;
import com.shinhan.fcl.repository.entity.TMetadata;
import com.shinhan.fcl.repository.entity.TOmsFCLFollowEMIInf;
import com.shinhan.fcl.repository.entity.TOmsFCLLmsMas;
import com.shinhan.fcl.repository.entity.TOmsFCLMaturitynf;

/**
 * @author shds01
 *
 */
@Service("validationManagerService")
public class ValidationManagerService extends AbstractRepositoryClass {

	public TOmsFCLFollowEMIInf checkValidationUpdateNoteFollowUpEMI(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no()) 
				|| ("".equalsIgnoreCase(trx.getFollowup_note()) && "".equalsIgnoreCase(trx.getRemarks())) ) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLLmsMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check Metadata Fol
		if(StringUtils.isBlank(error) && StringUtils.isNotBlank(trx.getFollowup_note())) {
			TMetadata item = getRepositoryManagerService().getUtilityManagerRepositoryService().getMetadataByLookupCodeAndId(APIConstant.LOOKUP_CODE_FOLLOWUP_EMI_NOTE, trx.getFollowup_note());
			if(item == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getFollowup_note());
			}
		}
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLFollowEMIInf inf = getRepositoryManagerService().getFollowUpManagerRepositoryService().getFollowUpEMITrxByLoanNo(trx.getLoan_no());
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLMaturitynf checkValidationExecuteWaiveMaturityWaiveOff(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLLmsMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
			DTOConverter.populateDataExecuteWaive(trx, mas);
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLMaturitynf inf = getRepositoryManagerService().getMaturityManagerRepositoryService().getMaturityTrxByLoanNo(trx.getLoan_no());
			if(inf != null && 
					(APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_WAIVEOFF_VALUE.equalsIgnoreCase(inf.getStatusCode()) || APIConstant.LOOKUP_CODE_FCL_LOAN_STATUS_DONE_VALUE.equalsIgnoreCase(inf.getStatusCode()))
			) {
				throw new ServiceRuntimeException(String.format(env.getProperty("MSG_005"), String.valueOf(trx.getLoan_no())));
			}
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLMaturitynf checkValidationExecuteDoneMaturityBookInc(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLLmsMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLMaturitynf inf = getRepositoryManagerService().getMaturityManagerRepositoryService().getMaturityTrxByLoanNo(trx.getLoan_no());
			return inf;
		}
		
		//Check business rule
		
		
		trx.setErrorMessage(error);
		return null;
	}
	
	public TOmsFCLMaturitynf checkValidationExecuteDoneMaturityRefund(EarlyTerminationTrx trx) throws ServiceRuntimeException {
		String error = "";
		//Mandatory
		if(StringUtils.isBlank(trx.getLoan_no())) {
			error = env.getProperty("MSG_001");
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLLmsMas mas = getRepositoryManagerService().getUtilityManagerRepositoryService().getFCLMasTrxByLoanNo(trx.getLoan_no());
			if(mas == null) {
				error = String.format(env.getProperty("MSG_007"), trx.getLoan_no());
			} else {
				trx.setRpa_amount(mas.getRpa_amount());
			}
		}
		
		//Check in DB
		if(StringUtils.isBlank(error)) {
			TOmsFCLMaturitynf inf = getRepositoryManagerService().getMaturityManagerRepositoryService().getMaturityTrxByLoanNo(trx.getLoan_no());
			return inf;
		}
		
		trx.setErrorMessage(error);
		return null;
	}
}
