/**
 * 
 */
package com.shinhan.fcl.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.fcl.common.AbstractBasicCommonClass;
import com.shinhan.fcl.core.exception.ServiceRuntimeException;
import com.shinhan.fcl.core.model.EarlyTerminationTrx;
import com.shinhan.fcl.service.PaymentApiService;

/**
 * @author shds01
 *
 */

@Service("paymentApiService")
@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
public class PaymentApiServiceImpl extends AbstractBasicCommonClass implements PaymentApiService {

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#getListPaymentAvailable(java.util.Map)
	 */
	@Override
	public List<EarlyTerminationTrx> getListPaymentAvailable(Map<String, Object> inputParams)
			throws ServiceRuntimeException {
		return getRepositoryManagerService().getPaymentManagerRepositoryService().getListPaymentAvailable(inputParams);
	}

	/* (non-Javadoc)
	 * @see com.shinhan.fcl.service.FormApiService#countPaymentAvailableTrx(java.util.Map)
	 */
	@Override
	public BigDecimal countPaymentAvailableTrx(Map<String, Object> inputParams) throws ServiceRuntimeException {
		return getRepositoryManagerService().getPaymentManagerRepositoryService().countPaymentAvailableTrx(inputParams);
	}

}
