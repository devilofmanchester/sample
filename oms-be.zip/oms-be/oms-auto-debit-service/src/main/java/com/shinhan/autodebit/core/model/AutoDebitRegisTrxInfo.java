/**
 * 
 */
package com.shinhan.autodebit.core.model;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;

/**
 * @author shds01
 *
 */
public class AutoDebitRegisTrxInfo {

	private String loanNo;
	private Date effectiveDt;
	private String location;
	private String errorMessage;

	/**
	 * 
	 */
	public AutoDebitRegisTrxInfo() {
		super();
	}

	/**
	 * @param loanNo
	 * @param effectiveDt
	 * @param location
	 */
	public AutoDebitRegisTrxInfo(String loanNo, Date effectiveDt, String location) {
		super();
		this.loanNo = loanNo;
		this.effectiveDt = effectiveDt;
		this.location = location;
	}

	/**
	 * @return the loanNo
	 */
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the effectiveDt
	 */
	public Date getEffectiveDt() {
		return effectiveDt;
	}

	/**
	 * @param effectiveDt the effectiveDt to set
	 */
	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}
	
	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public boolean getValid() {
		if (StringUtils.isNotBlank(errorMessage)) {
			return false;
		}
		return true;
	}
}
