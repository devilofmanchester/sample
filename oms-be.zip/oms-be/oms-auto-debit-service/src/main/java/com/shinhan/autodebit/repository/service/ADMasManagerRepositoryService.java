/**
 * 
 */
package com.shinhan.autodebit.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.autodebit.core.exception.ServiceRuntimeException;
import com.shinhan.autodebit.core.model.AutoDebitTrxInfo;
import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsMas;

/**
 * @author shds01
 *
 */
public interface ADMasManagerRepositoryService {

	public TOmsAutoDebitLmsMas getByLoanNo(String loanNo) throws ServiceRuntimeException;
	
	public List<AutoDebitTrxInfo> getListUnRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public BigDecimal countUnRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<Object[]> exportUnRegisterAutoDebitTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<TOmsAutoDebitLmsMas> buildDataADTrxReportByBank(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
	public List<TOmsAutoDebitLmsMas> buildDataADTrxReportByBankTemplate(Map<String, Object> inputParams) throws ServiceRuntimeException;

}
