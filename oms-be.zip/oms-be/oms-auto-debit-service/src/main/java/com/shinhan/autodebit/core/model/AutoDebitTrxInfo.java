/**
 * 
 */
package com.shinhan.autodebit.core.model;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;

/**
 * @author shds01
 *
 */
public class AutoDebitTrxInfo {

	/** TOmsAutoDebitLmsMas */
	private String loanNo;
	private String customerName;
	private Date authorizeDt;
	private Date firstDt;
	private String branch;
	private String roUser;
	private String bankName;
	private String adType;
	private String autosalDay;
	private String doc36;

	/** TOmsAutoDebitLmsInf */
	private Date sendDt;
	private String signedLocation;
	private String sendUser;
	private Date receiveDt;
	private String receiveUser;
	private Date drDt;
	private Date sendBankDt;
	private Date smsDueDt;
	private Date bankResultDt;
	private String registrationResult;
	private String reason;
	private Date smsADDt;
	private String statusCode;
	private String smsDueDtStatus;
	private String smsADDtStatus;
	
	/** Other */
	private String errorMessage;
	/**
	 * 
	 */
	public AutoDebitTrxInfo() {
		super();
	}

	/**
	 * @param loanNo
	 * @param customerName
	 * @param authorizeDt
	 * @param firstDt
	 * @param branch
	 * @param roUser
	 * @param bankName
	 * @param adType
	 * @param autosalDay
	 * @param doc36
	 */
	public AutoDebitTrxInfo(String loanNo, String customerName, Date authorizeDt, Date firstDt, String branch,
			String roUser, String bankName, String adType, String autosalDay, String doc36) {
		super();
		this.loanNo = loanNo;
		this.customerName = customerName;
		this.authorizeDt = authorizeDt;
		this.firstDt = firstDt;
		this.branch = branch;
		this.roUser = roUser;
		this.bankName = bankName;
		this.adType = adType;
		this.autosalDay = autosalDay;
		this.doc36 = doc36;
	}

	/**
	 * @param loanNo
	 * @param sendDt
	 * @param signedLocation
	 * @param sendUser
	 * @param receiveDt
	 * @param receiveUser
	 * @param drDt
	 * @param sendBankDt
	 * @param smsDueDt
	 * @param bankResultDt
	 * @param registrationResult
	 * @param reason
	 * @param smsADDt
	 * @param statusCode
	 * @param smsDueDtStatus
	 * @param smsADDtStatus
	 */
	public AutoDebitTrxInfo(String loanNo, Date sendDt, String signedLocation, String sendUser, Date receiveDt,
			String receiveUser, Date drDt, Date sendBankDt, Date smsDueDt, Date bankResultDt, String registrationResult,
			String reason, Date smsADDt, String statusCode, String smsDueDtStatus, String smsADDtStatus) {
		super();
		this.loanNo = loanNo;
		this.sendDt = sendDt;
		this.signedLocation = signedLocation;
		this.sendUser = sendUser;
		this.receiveDt = receiveDt;
		this.receiveUser = receiveUser;
		this.drDt = drDt;
		this.sendBankDt = sendBankDt;
		this.smsDueDt = smsDueDt;
		this.bankResultDt = bankResultDt;
		this.registrationResult = registrationResult;
		this.reason = reason;
		this.smsADDt = smsADDt;
		this.statusCode = statusCode;
		this.smsDueDtStatus = smsDueDtStatus;
		this.smsADDtStatus = smsADDtStatus;
	}

	/**
	 * @param loanNo
	 * @param customerName
	 * @param authorizeDt
	 * @param firstDt
	 * @param branch
	 * @param roUser
	 * @param bankName
	 * @param adType
	 * @param autosalDay
	 * @param doc36
	 * @param sendDt
	 * @param signedLocation
	 * @param sendUser
	 * @param receiveDt
	 * @param receiveUser
	 * @param drDt
	 * @param sendBankDt
	 * @param smsDueDt
	 * @param bankResultDt
	 * @param registrationResult
	 * @param reason
	 * @param smsADDt
	 * @param statusCode
	 * @param smsDueDtStatus
	 * @param smsADDtStatus
	 */
	public AutoDebitTrxInfo(String loanNo, String customerName, Date authorizeDt, Date firstDt, String branch,
			String roUser, String bankName, String adType, String autosalDay, String doc36,
			Date sendDt, String signedLocation, String sendUser, Date receiveDt, String receiveUser, Date drDt, Date sendBankDt,
			Date smsDueDt, Date bankResultDt, String registrationResult, String reason, Date smsADDt,
			String statusCode, String smsDueDtStatus, String smsADDtStatus) {
		super();
		this.loanNo = loanNo;
		this.customerName = customerName;
		this.authorizeDt = authorizeDt;
		this.firstDt = firstDt;
		this.branch = branch;
		this.roUser = roUser;
		this.bankName = bankName;
		this.adType = adType;
		this.autosalDay = autosalDay;
		this.doc36 = doc36;

		this.sendDt = sendDt;
		this.signedLocation = signedLocation;
		this.sendUser = sendUser;
		this.receiveDt = receiveDt;
		this.receiveUser = receiveUser;
		this.drDt = drDt;
		this.sendBankDt = sendBankDt;
		this.smsDueDt = smsDueDt;
		this.bankResultDt = bankResultDt;
		this.registrationResult = registrationResult;
		this.reason = reason;
		this.smsADDt = smsADDt;
		this.statusCode = statusCode;
		this.smsDueDtStatus = smsDueDtStatus;
		this.smsADDtStatus = smsADDtStatus;
	}

	/**
	 * @return the loanNo
	 */
	public String getLoanNo() {
		return loanNo;
	}

	/**
	 * @param loanNo the loanNo to set
	 */
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the authorizeDt
	 */
	public Date getAuthorizeDt() {
		return authorizeDt;
	}

	/**
	 * @param authorizeDt the authorizeDt to set
	 */
	public void setAuthorizeDt(Date authorizeDt) {
		this.authorizeDt = authorizeDt;
	}

	/**
	 * @return the firstDt
	 */
	public Date getFirstDt() {
		return firstDt;
	}

	/**
	 * @param firstDt the firstDt to set
	 */
	public void setFirstDt(Date firstDt) {
		this.firstDt = firstDt;
	}

	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}

	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}

	/**
	 * @return the roUser
	 */
	public String getRoUser() {
		return roUser;
	}

	/**
	 * @param roUser the roUser to set
	 */
	public void setRoUser(String roUser) {
		this.roUser = roUser;
	}

	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * @return the adType
	 */
	public String getAdType() {
		return adType;
	}

	/**
	 * @param adType the adType to set
	 */
	public void setAdType(String adType) {
		this.adType = adType;
	}

	/**
	 * @return the autosalDay
	 */
	public String getAutosalDay() {
		return autosalDay;
	}

	/**
	 * @param autosalDay the autosalDay to set
	 */
	public void setAutosalDay(String autosalDay) {
		this.autosalDay = autosalDay;
	}

	/**
	 * @return the doc36
	 */
	public String getDoc36() {
		return doc36;
	}

	/**
	 * @param doc36 the doc36 to set
	 */
	public void setDoc36(String doc36) {
		this.doc36 = doc36;
	}

	/**
	 * @return the sendDt
	 */
	public Date getSendDt() {
		return sendDt;
	}

	/**
	 * @param sendDt the sendDt to set
	 */
	public void setSendDt(Date sendDt) {
		this.sendDt = sendDt;
	}

	/**
	 * @return the signedLocation
	 */
	public String getSignedLocation() {
		return signedLocation;
	}

	/**
	 * @param signedLocation the signedLocation to set
	 */
	public void setSignedLocation(String signedLocation) {
		this.signedLocation = signedLocation;
	}

	/**
	 * @return the sendUser
	 */
	public String getSendUser() {
		return sendUser;
	}

	/**
	 * @param sendUser the sendUser to set
	 */
	public void setSendUser(String sendUser) {
		this.sendUser = sendUser;
	}

	/**
	 * @return the receiveDt
	 */
	public Date getReceiveDt() {
		return receiveDt;
	}

	/**
	 * @param receiveDt the receiveDt to set
	 */
	public void setReceiveDt(Date receiveDt) {
		this.receiveDt = receiveDt;
	}

	/**
	 * @return the receiveUser
	 */
	public String getReceiveUser() {
		return receiveUser;
	}

	/**
	 * @param receiveUser the receiveUser to set
	 */
	public void setReceiveUser(String receiveUser) {
		this.receiveUser = receiveUser;
	}

	/**
	 * @return the drDt
	 */
	public Date getDrDt() {
		return drDt;
	}

	/**
	 * @param drDt the drDt to set
	 */
	public void setDrDt(Date drDt) {
		this.drDt = drDt;
	}

	/**
	 * @return the sendBankDt
	 */
	public Date getSendBankDt() {
		return sendBankDt;
	}

	/**
	 * @param sendBankDt the sendBankDt to set
	 */
	public void setSendBankDt(Date sendBankDt) {
		this.sendBankDt = sendBankDt;
	}

	/**
	 * @return the smsDueDt
	 */
	public Date getSmsDueDt() {
		return smsDueDt;
	}

	/**
	 * @param smsDueDt the smsDueDt to set
	 */
	public void setSmsDueDt(Date smsDueDt) {
		this.smsDueDt = smsDueDt;
	}

	/**
	 * @return the bankResultDt
	 */
	public Date getBankResultDt() {
		return bankResultDt;
	}

	/**
	 * @param bankResultDt the bankResultDt to set
	 */
	public void setBankResultDt(Date bankResultDt) {
		this.bankResultDt = bankResultDt;
	}

	/**
	 * @return the registrationResult
	 */
	public String getRegistrationResult() {
		return registrationResult;
	}

	/**
	 * @param registrationResult the registrationResult to set
	 */
	public void setRegistrationResult(String registrationResult) {
		this.registrationResult = registrationResult;
	}

	/**
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}

	/**
	 * @return the smsADDt
	 */
	public Date getSmsADDt() {
		return smsADDt;
	}

	/**
	 * @param smsADDt the smsADDt to set
	 */
	public void setSmsADDt(Date smsADDt) {
		this.smsADDt = smsADDt;
	}

	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the smsDueDtStatus
	 */
	public String getSmsDueDtStatus() {
		return smsDueDtStatus;
	}

	/**
	 * @param smsDueDtStatus the smsDueDtStatus to set
	 */
	public void setSmsDueDtStatus(String smsDueDtStatus) {
		this.smsDueDtStatus = smsDueDtStatus;
	}

	/**
	 * @return the smsADDtStatus
	 */
	public String getSmsADDtStatus() {
		return smsADDtStatus;
	}

	/**
	 * @param smsADDtStatus the smsADDtStatus to set
	 */
	public void setSmsADDtStatus(String smsADDtStatus) {
		this.smsADDtStatus = smsADDtStatus;
	}

	public boolean getValid() {
		if (StringUtils.isNotBlank(errorMessage)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AutoDebitTrxInfo [loanNo=" + loanNo + ", customerName=" + customerName + ", authorizeDt=" + authorizeDt
				+ ", firstDt=" + firstDt + ", branch=" + branch + ", bankName=" + bankName + "]";
	}
}
