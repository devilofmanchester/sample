/**
 * 
 */
package com.shinhan.autodebit.core.model;

/**
 * @author shds01
 *
 */
public class CommunicationSystemSendSMSTemplate {

	private String phone;
	private String template_id;
	private String source;
	private String callback_url;
	private CommunicationSystemSendSMSTemplateData template_data;

	/**
	 * 
	 */
	public CommunicationSystemSendSMSTemplate() {
		super();
	}

	/**
	 * @param phone
	 * @param template_id
	 * @param source
	 * @param template_data
	 */
	public CommunicationSystemSendSMSTemplate(String phone, String template_id, String source,
			CommunicationSystemSendSMSTemplateData template_data) {
		super();
		this.phone = phone;
		this.template_id = template_id;
		this.source = source;
		this.template_data = template_data;
	}

	/**
	 * @param phone
	 * @param template_id
	 * @param source
	 * @param callback_url
	 * @param template_data
	 */
	public CommunicationSystemSendSMSTemplate(String phone, String template_id, String source, String callback_url,
			CommunicationSystemSendSMSTemplateData template_data) {
		super();
		this.phone = phone;
		this.template_id = template_id;
		this.source = source;
		this.callback_url = callback_url;
		this.template_data = template_data;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @return the template_id
	 */
	public String getTemplate_id() {
		return template_id;
	}

	/**
	 * @param template_id the template_id to set
	 */
	public void setTemplate_id(String template_id) {
		this.template_id = template_id;
	}

	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}

	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return the callback_url
	 */
	public String getCallback_url() {
		return callback_url;
	}

	/**
	 * @param callback_url the callback_url to set
	 */
	public void setCallback_url(String callback_url) {
		this.callback_url = callback_url;
	}

	/**
	 * @return the template_data
	 */
	public CommunicationSystemSendSMSTemplateData getTemplate_data() {
		return template_data;
	}

	/**
	 * @param template_data the template_data to set
	 */
	public void setTemplate_data(CommunicationSystemSendSMSTemplateData template_data) {
		this.template_data = template_data;
	}

}
