/**
 * 
 */
package com.shinhan.autodebit.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.shinhan.autodebit.repository.entity.TOmsAutoDebitLmsMas;

/**
 * @author shds01
 *
 */
@Repository
public interface TOmsAutoDebitLmsMasDAO extends JpaRepository<TOmsAutoDebitLmsMas, Long> ,JpaSpecificationExecutor<TOmsAutoDebitLmsMas>{

	@Query("SELECT item FROM TOmsAutoDebitLmsMas item WHERE LOWER(item.loanNo) = LOWER(:loanNo)")
	public TOmsAutoDebitLmsMas getItemByLoanNo(@Param("loanNo") String loanNo);
}
