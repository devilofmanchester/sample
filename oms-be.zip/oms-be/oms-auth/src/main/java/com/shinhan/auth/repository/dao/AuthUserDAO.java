/**
 * 
 */
package com.shinhan.auth.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.shinhan.auth.repository.entity.AuthUser;

/**
 * @author shds01
 *
 */
@Repository
public interface AuthUserDAO extends JpaRepository<AuthUser, Long> {

	@Query("SELECT item FROM AuthUser item WHERE username = :username")
	public AuthUser getProfileByUsername(@Param("username") String username);
}
