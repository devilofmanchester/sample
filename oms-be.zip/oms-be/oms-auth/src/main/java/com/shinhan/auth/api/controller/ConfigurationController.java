/**
 * 
 */
package com.shinhan.auth.api.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.auth.core.constant.APIConstant;
import com.shinhan.auth.core.exception.BaseException;
import com.shinhan.auth.core.model.UserFeatureInfo;
import com.shinhan.auth.repository.entity.TMetadata;


/**
 * @author shds01
 *
 */
@RestController
public class ConfigurationController extends BaseController{
	/** Roles */
	@RequestMapping(value = "shinhan/service/configuration/roles", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	public ResponseEntity<Object> getListRoles(Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		List<TMetadata> listTMetadata = getProcessManagerService().getConfigurationApiService().getListRole(inputParams);
		return triggerSuccessOutPut(listTMetadata, listTMetadata.size());
	}
	
	@RequestMapping(value = "shinhan/service/configuration/roles", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> createRole(@RequestBody String document, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		TMetadata item = getProcessManagerService().getConfigurationApiService().createRole(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/roles/{roleId}/summary", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getRoleDetailSummary(@PathVariable String roleId, Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.OMSID, roleId);
		
		TMetadata item = getProcessManagerService().getConfigurationApiService().getRoleDetailSummary(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/roles/{roleId}", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getRoleDetail(@PathVariable String roleId, Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.OMSID, roleId);
		
		Object item = getProcessManagerService().getConfigurationApiService().getRoleDetail(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/roles/{roleId}/summary", produces = "application/json;charset=utf-8", method = RequestMethod.PATCH)
	@ResponseBody
	public ResponseEntity<Object> updateRoleSummary(@RequestBody String document, @PathVariable String roleId, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.OMSID, roleId);
		
		TMetadata item = getProcessManagerService().getConfigurationApiService().updateRoleSummary(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/roles/{roleId}", produces = "application/json;charset=utf-8", method = RequestMethod.PATCH)
	@ResponseBody
	public ResponseEntity<Object> updateRole(@RequestBody String document, @PathVariable String roleId, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.OMSID, roleId);
		
		Object item = getProcessManagerService().getConfigurationApiService().updateRole(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/roles/{roleId}", produces = "application/json;charset=utf-8", method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<Object> deleteRole(@RequestBody String document, @PathVariable String roleId, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.OMSID, roleId);
		
		TMetadata item = getProcessManagerService().getConfigurationApiService().deleteRole(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/roles/{roleId}/features", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getListFeatureByRole(@PathVariable String roleId, Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.OMSID, roleId);
		
		Object item = getProcessManagerService().getConfigurationApiService().getListFeatureByRole(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/roles/{roleId}/features", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> createFeatureForRole(@RequestBody String document, @PathVariable String roleId, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.OMSID, roleId);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		UserFeatureInfo item = getProcessManagerService().getConfigurationApiService().createFeatureForRole(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	/** Features */
	@RequestMapping(value = "shinhan/service/configuration/features", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	public ResponseEntity<Object> getListFeature(Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		List<TMetadata> listTMetadata = getProcessManagerService().getConfigurationApiService().getListFeature(inputParams);
		return triggerSuccessOutPut(listTMetadata, listTMetadata.size());
	}
	
	@RequestMapping(value = "shinhan/service/configuration/features", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> createFeature(@RequestBody String document, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		TMetadata item = getProcessManagerService().getConfigurationApiService().createFeature(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/features/{featureId}", produces = "application/json;charset=utf-8", method = RequestMethod.PATCH)
	@ResponseBody
	public ResponseEntity<Object> updateFeature(@RequestBody String document, @PathVariable String featureId, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.OMSID, featureId);
		
		TMetadata item = getProcessManagerService().getConfigurationApiService().updateFeature(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/features/{featureId}", produces = "application/json;charset=utf-8", method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<Object> deleteFeature(@RequestBody String document, @PathVariable String featureId, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.OMSID, featureId);
		
		TMetadata item = getProcessManagerService().getConfigurationApiService().deleteFeature(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
}
