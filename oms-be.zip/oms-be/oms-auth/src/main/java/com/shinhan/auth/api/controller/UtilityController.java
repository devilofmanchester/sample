/**
 * 
 */
package com.shinhan.auth.api.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.auth.core.constant.APIConstant;
import com.shinhan.auth.core.exception.BaseException;
import com.shinhan.auth.core.exception.ServiceRuntimeException;
import com.shinhan.auth.repository.entity.TMetadata;

/**
 * @author shds01
 *
 */
@RestController
public class UtilityController extends BaseController{

	
	@RequestMapping(value = "shinhan/common/connection", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public ResponseEntity<Object> testGet() throws ServiceRuntimeException, InterruptedException {
		return triggerSuccessOutPut(null, JsonObject.class, "connect server successfully");
	}

	@RequestMapping(value = "shinhan/common/exception", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.GET)
	public String testException(Locale locale) throws BaseException {
		testException();
		return "Success";
	}
	
	@RequestMapping(value = "shinhan/service/metadata", produces = "application/json;charset=utf-8", method = RequestMethod.GET)
	public ResponseEntity<Object> getAllMetadata(@RequestParam(required = false, defaultValue = "") String _lookupCode, Locale locale) throws BaseException {
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant._LOOKUP_CODE_KEY, StringUtils.isEmpty(_lookupCode) ? APIConstant.ALL : _lookupCode);
		
		List<TMetadata> listTMetadata = getProcessManagerService().getUtilityApiService().getAllMetadata(inputParams);
		return triggerSuccessOutPut(listTMetadata, listTMetadata.size());
	}
	
	@RequestMapping(value = "shinhan/service/configuration/metadata", produces = "application/json;charset=utf-8", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> createMetadata(@RequestBody String document, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		
		TMetadata item = getProcessManagerService().getUtilityApiService().createMetadata(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/metadata/{metadataId}", produces = "application/json;charset=utf-8", method = RequestMethod.PATCH)
	@ResponseBody
	public ResponseEntity<Object> updateMetadata(@RequestBody String document, @PathVariable String metadataId, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.OMSID, metadataId);
		
		TMetadata item = getProcessManagerService().getUtilityApiService().updateMetadata(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
	
	@RequestMapping(value = "shinhan/service/configuration/metadata/{metadataId}", produces = "application/json;charset=utf-8", method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<Object> deleteMetadata(@RequestBody String document, @PathVariable String metadataId, Locale locale) throws BaseException {
		httpServletRequest.setAttribute(APIConstant.HTTP_REQUEST_BODY_STR, document);
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		inputParams.put(APIConstant.USERNAME_KEY, httpServletRequest.getAttribute(APIConstant.USERNAME_KEY).toString());
		inputParams.put(APIConstant.OMSID, metadataId);
		
		TMetadata item = getProcessManagerService().getUtilityApiService().deleteMetadata(inputParams);
		return triggerSuccessOutPut(item, JsonObject.class, null);
	}
}
