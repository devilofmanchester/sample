/**
 * 
 */
package com.shinhan.redisburse.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.shinhan.redisburse.repository.service.TOmsReDisbursalInfManagerRepositoryService;
import com.shinhan.redisburse.repository.service.TOmsReDisbursalHisInfManagerREpositoryService;
import com.shinhan.redisburse.repository.service.UtilityManagerRepositoryService;

/**
 * @author shds01
 *
 */
@Service("repositoryManagerService")
public class RepositoryManagerService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private TOmsReDisbursalInfManagerRepositoryService tOmsReconDisbursalInfManagerRepositoryService;
	
	@Autowired
	private TOmsReDisbursalHisInfManagerREpositoryService tOmsReDisbursalHisInfManagerREpositoryService;
	
	@Autowired
	private UtilityManagerRepositoryService utilityManagerRepositoryService;

	public TOmsReDisbursalInfManagerRepositoryService gettOmsReconDisbursalInfManagerRepositoryService() {
		return tOmsReconDisbursalInfManagerRepositoryService;
	}

	public void settOmsReconDisbursalInfManagerRepositoryService(
			@Qualifier("tOmsReconDisbursalInfManagerRepositoryService")	TOmsReDisbursalInfManagerRepositoryService tOmsReconDisbursalInfManagerRepositoryService) {
		this.tOmsReconDisbursalInfManagerRepositoryService = tOmsReconDisbursalInfManagerRepositoryService;
	}

	public UtilityManagerRepositoryService getUtilityManagerRepositoryService() {
		return utilityManagerRepositoryService;
	}

	public void setUtilityManagerRepositoryService(
			@Qualifier("utilityManagerRepositoryService")	UtilityManagerRepositoryService utilityManagerRepositoryService) {
		this.utilityManagerRepositoryService = utilityManagerRepositoryService;
	}

	public TOmsReDisbursalHisInfManagerREpositoryService gettOmsReDisbursalHisInfManagerREpositoryService() {
		return tOmsReDisbursalHisInfManagerREpositoryService;
	}

	public void settOmsReDisbursalHisInfManagerREpositoryService(
			@Qualifier("tOmsReDisbursalHisInfManagerREpositoryService")	TOmsReDisbursalHisInfManagerREpositoryService tOmsReDisbursalHisInfManagerREpositoryService) {
		this.tOmsReDisbursalHisInfManagerREpositoryService = tOmsReDisbursalHisInfManagerREpositoryService;
	}
	
	
	
}
