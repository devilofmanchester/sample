/**
 * 
 */
package com.shinhan.migrate.repository.service;

import java.util.List;
import java.util.Map;

import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.repository.entity.TMetadata;

/**
 * @author shds01
 *
 */
public interface UtilityManagerRepositoryService {

	public List<TMetadata> getAllMetadata(Map<String, Object> inputParams) throws BaseException;
	
	public List<TMetadata> getMetadataByLookupCode(String lookupCode) throws BaseException;
	
}
