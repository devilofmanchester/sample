/**
 * 
 */
package com.shinhan.migrate.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.shinhan.migrate.repository.entity.TOmsReconSuspenseInf;

/**
 * @author shds04
 *
 */
public interface TOmsReconSuspInfDAO extends JpaRepository<TOmsReconSuspenseInf, Long>,JpaSpecificationExecutor<TOmsReconSuspenseInf> {

}
