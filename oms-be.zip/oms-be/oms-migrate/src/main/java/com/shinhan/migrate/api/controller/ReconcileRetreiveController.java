/**
 * 
 */
package com.shinhan.migrate.api.controller;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.shinhan.migrate.core.constant.APIConstant;
import com.shinhan.migrate.core.exception.ServiceInvalidAgurmentException;

/**
 * @author shds01
 *
 */
@RestController
public class ReconcileRetreiveController extends BaseController{
	
	/** Begin For Statement File **/
	@RequestMapping(value = "shinhan/service/reconcile/lmstrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.POST)
	public ResponseEntity<Object> retreiveLMSData(
			@RequestParam(required = true) String _dataType,
			@RequestBody String document, Locale locale) throws Exception {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DATA_TYPE_KEY, _dataType);
		inputParams.put(APIConstant.DOCUMENT, document);
		boolean flag = getProcessManagerService().getReconcileRetreiveApiService().retreiveLMSData(inputParams);
		if(!flag) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		return triggerSuccessOutPut(APIConstant.SUCCESS_KEY, JsonObject.class, null);
		
	}
	@RequestMapping(value = "shinhan/service/reconcile/repaymenttrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.POST)
	public ResponseEntity<Object> retreiveLMSDataRep(
			@RequestBody String document, Locale locale) throws Exception {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		boolean flag = getProcessManagerService().getReconcileRetreiveApiService().retreiveLMSDataRep(inputParams);
		if(!flag) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		return triggerSuccessOutPut(APIConstant.SUCCESS_KEY, JsonObject.class, null);
		
	}
	@RequestMapping(value = "shinhan/service/reconcile/reverttrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.POST)
	public ResponseEntity<Object> retreiveLMSDataRev(
			@RequestBody String document, Locale locale) throws Exception {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		boolean flag = getProcessManagerService().getReconcileRetreiveApiService().retreiveLMSDataRevert(inputParams);
		if(!flag) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		return triggerSuccessOutPut(APIConstant.SUCCESS_KEY, JsonObject.class, null);
		
	}
	@RequestMapping(value = "shinhan/service/reconcile/disbtrx", produces = {"application/json;charset=utf-8", "application/xml;charset=utf-8"}, method = RequestMethod.POST)
	public ResponseEntity<Object> retreiveLMSDataDisb(
			@RequestBody String document, Locale locale) throws Exception {
		
		Map<String, Object> inputParams = new HashMap<>();
		inputParams.put(APIConstant.DOCUMENT, document);
		boolean flag = getProcessManagerService().getReconcileRetreiveApiService().retreiveLMSDataDisb(inputParams);
		if(!flag) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_002"));
		}
		return triggerSuccessOutPut(APIConstant.SUCCESS_KEY, JsonObject.class, null);
		
	}

}
