/**
 * 
 */
package com.shinhan.migrate.repository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.shinhan.migrate.repository.entity.TOmsReconLmsInf;

/**
 * @author shds01
 *
 */
@Repository
public interface TOmsReconLmsInfDAO extends JpaRepository<TOmsReconLmsInf, Long>,JpaSpecificationExecutor<TOmsReconLmsInf> {

}
