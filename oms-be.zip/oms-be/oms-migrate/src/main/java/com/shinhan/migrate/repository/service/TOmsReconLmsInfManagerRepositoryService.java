/**
 * 
 */
package com.shinhan.migrate.repository.service;

import java.util.List;
import java.util.Map;

import com.shinhan.migrate.core.exception.BaseException;
import com.shinhan.migrate.core.exception.ServiceRuntimeException;
import com.shinhan.migrate.repository.entity.TOmsReconLmsInf;	

/**
 * @author shds01
 *
 */
public interface TOmsReconLmsInfManagerRepositoryService {

	
	public boolean createAll(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsReconLmsInf> getListLmsTrxMatchWithRepTrx(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsReconLmsInf> getListLmsTrxMatchWithRevTrx(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsReconLmsInf> getListLMSMatchedListRepTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;

	public List<TOmsReconLmsInf> getListLMSMatchedListRevTrx(Map<String, Object> inputParams) throws ServiceRuntimeException;
	
}
