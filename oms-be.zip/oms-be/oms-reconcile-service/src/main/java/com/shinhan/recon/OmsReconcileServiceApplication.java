package com.shinhan.recon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author shds01
 *
 */
@RestController
@SpringBootApplication(scanBasePackages={"com.shinhan.recon"})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class})
@EnableScheduling
public class OmsReconcileServiceApplication extends SpringBootServletInitializer{

	@RequestMapping("/")
	String home() {
		return "Hello Shinhan DS Vietnam!";
	}
	
	public static void main(String[] args) {
		SpringApplication.run(OmsReconcileServiceApplication.class, args);
	}
	
	/**
	 * Used when run as WAR
	 */
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(OmsReconcileServiceApplication.class);
	}

}
