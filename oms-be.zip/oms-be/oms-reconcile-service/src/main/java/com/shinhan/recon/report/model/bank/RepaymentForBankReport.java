/**
 * 
 */
package com.shinhan.recon.report.model.bank;

/**
 * @author shds01
 *
 */
public class RepaymentForBankReport {

	private RepaymentForBankHeaderReport headerReport;
	private RepaymentForBankMatchingDataReport dataMatchingReport;
	private RepaymentForBankUnMatchingDataReport dataUnMatchingReport;
	private RepaymentForBankFooterReport footerReport;

	/**
	 * 
	 */
	public RepaymentForBankReport() {
		super();
	}

	/**
	 * @param headerReport
	 */
	public RepaymentForBankReport(RepaymentForBankHeaderReport headerReport) {
		super();
		this.headerReport = headerReport;
	}

	/**
	 * @return the headerReport
	 */
	public RepaymentForBankHeaderReport getHeaderReport() {
		return headerReport;
	}

	/**
	 * @param headerReport the headerReport to set
	 */
	public void setHeaderReport(RepaymentForBankHeaderReport headerReport) {
		this.headerReport = headerReport;
	}

	/**
	 * @return the dataMatchingReport
	 */
	public RepaymentForBankMatchingDataReport getDataMatchingReport() {
		return dataMatchingReport;
	}

	/**
	 * @param dataMatchingReport the dataMatchingReport to set
	 */
	public void setDataMatchingReport(RepaymentForBankMatchingDataReport dataMatchingReport) {
		this.dataMatchingReport = dataMatchingReport;
	}

	/**
	 * @return the dataUnMatchingReport
	 */
	public RepaymentForBankUnMatchingDataReport getDataUnMatchingReport() {
		return dataUnMatchingReport;
	}

	/**
	 * @param dataUnMatchingReport the dataUnMatchingReport to set
	 */
	public void setDataUnMatchingReport(RepaymentForBankUnMatchingDataReport dataUnMatchingReport) {
		this.dataUnMatchingReport = dataUnMatchingReport;
	}

	/**
	 * @return the footerReport
	 */
	public RepaymentForBankFooterReport getFooterReport() {
		return footerReport;
	}

	/**
	 * @param footerReport the footerReport to set
	 */
	public void setFooterReport(RepaymentForBankFooterReport footerReport) {
		this.footerReport = footerReport;
	}

}
