/**
 * 
 */
package com.shinhan.recon.service;

import com.shinhan.recon.core.exception.BaseException;

/**
 * @author shds04
 *
 */
public interface ReconcileRetryService {
	public void retryProcess() throws BaseException;
}
