/**
 * 
 */
package com.shinhan.recon.repository.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author shds01
 *
 */
@Entity
@Table(name = "OMS_STMT_FILE_MAS")
public class TOmsStmtFileMas implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;

	private Date uploadDt;
	private String bankCode;
	private int seqNo;

	private String fileName;
	private Date valueDt;
	private BigDecimal openBalance;
	private BigDecimal closeBalance;
	private Long processStatus;
	private String uploadUser;
	private Long fileStatus;
	private int totalCount;
	private int successCount;
	private int fileValidCount;
	private String remark;
	private long fileType;
	private String addInf;

	/**
	 * 
	 */
	public TOmsStmtFileMas() {
		super();
	}

	/**
	 * @param id
	 * @param uploadDt
	 * @param bankCode
	 * @param seqNo
	 * @param fileName
	 * @param valueDt
	 * @param openBalance
	 * @param closeBalance
	 * @param processStatus
	 * @param uploadUser
	 * @param fileStatus
	 * @param totalCount
	 * @param successCount
	 * @param fileValidCount
	 * @param remark
	 */
	public TOmsStmtFileMas(Long id, Date uploadDt, String bankCode, int seqNo, String fileName, Date valueDt,
			BigDecimal openBalance, BigDecimal closeBalance, Long processStatus, String uploadUser, Long fileStatus,
			int totalCount, int successCount, int fileValidCount, String remark, long fileType, String addInf) {
		super();
		this.id = id;
		this.uploadDt = uploadDt;
		this.bankCode = bankCode;
		this.seqNo = seqNo;
		this.fileName = fileName;
		this.valueDt = valueDt;
		this.openBalance = openBalance;
		this.closeBalance = closeBalance;
		this.processStatus = processStatus;
		this.uploadUser = uploadUser;
		this.fileStatus = fileStatus;
		this.totalCount = totalCount;
		this.successCount = successCount;
		this.fileValidCount = fileValidCount;
		this.remark = remark;
		this.fileType = fileType;
		this.addInf = addInf;
	}

	/**
	 * @return the id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "OMS_STMT_FILE_MAS_SEQ_GEN")
	@SequenceGenerator(name = "OMS_STMT_FILE_MAS_SEQ_GEN", sequenceName = "OMS_STMT_FILE_MAS_SEQ", allocationSize = 1)
	@Column(name = "ID")
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the uploadDt
	 */
	@Column(name = "UPLOAD_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getUploadDt() {
		return uploadDt;
	}

	/**
	 * @param uploadDt the uploadDt to set
	 */
	public void setUploadDt(Date uploadDt) {
		this.uploadDt = uploadDt;
	}

	/**
	 * @return the bankCode
	 */
	@Column(name = "BANK_CODE")
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * @param bankCode the bankCode to set
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * @return the seqNo
	 */
	@Column(name = "SEQ_NO")
	public int getSeqNo() {
		return seqNo;
	}

	/**
	 * @param seqNo the seqNo to set
	 */
	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}

	/**
	 * @return the fileName
	 */
	@Column(name = "FILE_NAME")
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the valueDt
	 */
	@Column(name = "VALUE_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "GMT+07:00")
	public Date getValueDt() {
		return valueDt;
	}

	/**
	 * @param valueDt the valueDt to set
	 */
	public void setValueDt(Date valueDt) {
		this.valueDt = valueDt;
	}

	/**
	 * @return the openBalance
	 */
	@Column(name = "OPEN_BLC")
	public BigDecimal getOpenBalance() {
		return openBalance;
	}

	/**
	 * @param openBalance the openBalance to set
	 */
	public void setOpenBalance(BigDecimal openBalance) {
		this.openBalance = openBalance;
	}

	/**
	 * @return the closeBalance
	 */
	@Column(name = "CLOSE_BLC")
	public BigDecimal getCloseBalance() {
		return closeBalance;
	}

	/**
	 * @param closeBalance the closeBalance to set
	 */
	public void setCloseBalance(BigDecimal closeBalance) {
		this.closeBalance = closeBalance;
	}

	/**
	 * @return the processStatus
	 */
	@Column(name = "PROCESS_STATUS")
	public Long getProcessStatus() {
		return processStatus;
	}

	/**
	 * @param processStatus the processStatus to set
	 */
	public void setProcessStatus(Long processStatus) {
		this.processStatus = processStatus;
	}

	/**
	 * @return the uploadUser
	 */
	@Column(name = "UPLOADED_USER")
	public String getUploadUser() {
		return uploadUser;
	}

	/**
	 * @param uploadUser the uploadUser to set
	 */
	public void setUploadUser(String uploadUser) {
		this.uploadUser = uploadUser;
	}

	/**
	 * @return the fileStatus
	 */
	@Column(name = "FILE_STATUS")
	public Long getFileStatus() {
		return fileStatus;
	}

	/**
	 * @param fileStatus the fileStatus to set
	 */
	public void setFileStatus(Long fileStatus) {
		this.fileStatus = fileStatus;
	}

	/**
	 * @return the totalCount
	 */
	@Column(name = "TOTAL_CNT")
	public int getTotalCount() {
		return totalCount;
	}

	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * @return the successCount
	 */
	@Column(name = "SUCCESS_CNT")
	public int getSuccessCount() {
		return successCount;
	}

	/**
	 * @param successCount the successCount to set
	 */
	public void setSuccessCount(int successCount) {
		this.successCount = successCount;
	}

	/**
	 * @return the fileValidCount
	 */
	@Column(name = "FILE_VALID_CNT")
	public int getFileValidCount() {
		return fileValidCount;
	}

	/**
	 * @param fileValidCount the fileValidCount to set
	 */
	public void setFileValidCount(int fileValidCount) {
		this.fileValidCount = fileValidCount;
	}

	/**
	 * @return the remark
	 */
	@Column(name = "REMARK")
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Column(name = "FILE_TYPE")
	public long getFileType() {
		return fileType;
	}

	public void setFileType(long fileType) {
		this.fileType = fileType;
	}
	@Column(name = "ADD_INF")
	public String getAddInf() {
		return addInf;
	}

	public void setAddInf(String addInf) {
		this.addInf = addInf;
	}
	
}
