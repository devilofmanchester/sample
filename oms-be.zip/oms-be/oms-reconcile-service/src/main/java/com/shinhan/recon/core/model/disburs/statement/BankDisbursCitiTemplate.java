/**
 * 
 */
package com.shinhan.recon.core.model.disburs.statement;

/**
 * @author shds04
 *
 */
public class BankDisbursCitiTemplate {
	
	private String trxDt;
	private String ref;
	private String loanNo;
	private String valueDt;
	private String description;
	private String debit;
	private String credit;
	public BankDisbursCitiTemplate() {
		super();
	}
	public BankDisbursCitiTemplate(String trxDt, String ref, String loanNo, String valueDt, String description,
			String debit, String credit) {
		super();
		this.trxDt = trxDt;
		this.ref = ref;
		this.loanNo = loanNo;
		this.valueDt = valueDt;
		this.description = description;
		this.debit = debit;
		this.credit = credit;
	}
	public String getTrxDt() {
		return trxDt;
	}
	public void setTrxDt(String trxDt) {
		this.trxDt = trxDt;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}
	public String getValueDt() {
		return valueDt;
	}
	public void setValueDt(String valueDt) {
		this.valueDt = valueDt;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDebit() {
		return debit;
	}
	public void setDebit(String debit) {
		this.debit = debit;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	
}
