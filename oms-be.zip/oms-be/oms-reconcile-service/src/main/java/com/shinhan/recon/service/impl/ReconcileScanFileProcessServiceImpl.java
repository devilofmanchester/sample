/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.io.File;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.model.BankTemplateInfo;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.service.ReconcileScanFileProcessService;

/**
 * @author shds04
 *
 */
@Service("reconcileScanFileProcessService")
@Transactional(readOnly = false, propagation =  Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
public class ReconcileScanFileProcessServiceImpl extends AbstractServiceClass implements ReconcileScanFileProcessService{

	@Override
	public void scanBankStatementFile() throws Exception {
		
		/** Step 1: Load common infor from DB */
		Map<String, Object> statementFileMasMap = new HashedMap<String, Object>();
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant._UPLOAD_FILE_DELETE_STATUS);
		statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_REPAYMENT);
		
		File destFile = new File(env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_PROCESS_FOLDER));
		Collection<File> files = CommonUtil.getBankStatementFileInFolder(env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_FTP_FOLDER));
		
		List<TBankCommon> listBankCommonVal = getRepositoryManagerService().getUtilityManagerRepositoryService()
				.getBankCommonByBizValue(APIConstant._BANK_COMMON_BIZ_TEMPLATE_VALUE_);
		List<TOmsStmtFileMas> tOmsStmtFileMasList= getRepositoryManagerService()
				.getTomsStmtFileMasManagerRepositoryService().getListUploadByDate(statementFileMasMap);

		/** Step 2: Scan list of file, insert file information to DB and move file to NEW */
		for (File file : files) {
			if(file.exists()) {
				FileUtils.copyFileToDirectory(file, new File(env.getProperty(APIConstant.PATH_SCAN_BANK_TEMP_FOLDER)));
			}
			TBankCommon bankFileVal = getBankCommonValByBankCode(file.getName(), listBankCommonVal);
			BankTemplateInfo tmBankTemplateInfo = DTOConverter.getBankTemplateInfo(bankFileVal);
			/** if bankfileVal not found in OmsCommonValEntity, skip **/
			if( tmBankTemplateInfo.getFileCnt() == 0 ||isFileUploadSuccess(file.getName(), tOmsStmtFileMasList)) {
		
				continue;
			}
			
			if(isFileScanSuccess(file.getName(), tOmsStmtFileMasList) ) {
				/** check all bank file were uploaded to TOmsStmtFileMas or not */
				List<TOmsStmtFileMas> fileMasList  = getListByBankCode(bankFileVal.getBankAccNuber(),tOmsStmtFileMasList );
				
				if( fileMasList.size() == tmBankTemplateInfo.getFileCnt() ) {
					
					/**  Update tOmsStmtFileMas status, since status is 10 ---> skip */
					for (TOmsStmtFileMas filemas : fileMasList) {
						filemas.setFileStatus(APIConstant._UPLOAD_FILE_NORMAL_STATUS);
						filemas.setProcessStatus(APIConstant._RECONCILE_PROCESSING_STATUS);
					}
					if(	updateTOmsStmtFileListToDB(fileMasList,  APIConstant._USERNAME_BATCHJOB)) {
						/**  Move file to NEW */
						for (TOmsStmtFileMas filemas : fileMasList) {
							for (File fil : files) {
								if(fil.getName().equals(filemas.getFileName())) {
									logger.info("**** Move file " + fil.getName() + " to " + env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_PROCESS_FOLDER) + "****");
									CommonUtil.moveFileToDirectory(fil, destFile);
									logger.info("**** End Move file " + fil.getName() + " to " + env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_PROCESS_FOLDER) + "****");
								}
							}
							
						}
					}
				}
				
			}else {
				/** Insert data to TOmsStmtFileMas */
				
				TOmsStmtFileMas tOmsStmtFileMas = new TOmsStmtFileMas();
				tOmsStmtFileMas.setBankCode(bankFileVal.getBankAccNuber());
				tOmsStmtFileMas.setFileName(file.getName());
				tOmsStmtFileMas.setValueDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT));
				tOmsStmtFileMas.setFileStatus(APIConstant._UPLOAD_FILE_PENDING_STATUS);
				tOmsStmtFileMas.setProcessStatus(APIConstant._UPLOAD_FILE_PENDING_STATUS);
				tOmsStmtFileMas.setUploadDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT));
				tOmsStmtFileMas.setFileValidCount(tmBankTemplateInfo.getFileCnt());
				tOmsStmtFileMas.setUploadUser(APIConstant._OMS_FILESCANBATCH_);
				tOmsStmtFileMas.setFileType(APIConstant.LMS_TRX_TYPE_REPAYMENT);
				createTOmsStmtFileMasToDB(tOmsStmtFileMas, APIConstant._OMS_FILESCANBATCH_);
				logger.info("**** Insert " + file.getName() + " To DB ");		
			}
		}
	}

	@Override
	public void scanBankDisbursalFile() throws Exception {
		/** Step 1: Load common infor from DB */
		Map<String, Object> statementFileMasMap = new HashedMap<String, Object>();
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant._UPLOAD_FILE_DELETE_STATUS);
		statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		File destFile = new File(env.getProperty(APIConstant.PATH_SCAN_DISBURSAL_STATEMENT_PROCESS_FOLDER));
		Collection<File> files = CommonUtil.getBankStatementFileInFolder(env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_FTP_FOLDER));
		
		List<TBankCommon> listBankCommonVal = getRepositoryManagerService().getUtilityManagerRepositoryService()
				.getBankCommonByBizValue(APIConstant._BANK_COMMON_BIZ_DISBURSAL_TEMPLATE_VALUE_);
		List<TOmsStmtFileMas> tOmsStmtFileMasList= getRepositoryManagerService()
				.getTomsStmtFileMasManagerRepositoryService().getListUploadByDate(statementFileMasMap);

		/** Step 2: Scan list of file, insert file information to DB and move file to NEW */
		for (File file : files) {
			
			TBankCommon bankFileVal = getBankCommonValByBankCode(file.getName(), listBankCommonVal);
			BankTemplateInfo tmBankTemplateInfo = DTOConverter.getBankTemplateInfo(bankFileVal);
			/** if bankfileVal not found in OmsCommonValEntity, skip **/
			if( tmBankTemplateInfo.getFileCnt() == 0 || isFileUploadSuccess(file.getName(), tOmsStmtFileMasList)) {
		
				continue;
			}
			
			if(isFileScanSuccess(file.getName(), tOmsStmtFileMasList) ) {
				/** check all bank file were uploaded to TOmsStmtFileMas or not */
				List<TOmsStmtFileMas> fileMasList  = getListByBankCode(bankFileVal.getBankAccNuber(),tOmsStmtFileMasList );
				
				if( fileMasList.size() == tmBankTemplateInfo.getFileCnt() ) {
					
					/**  Update tOmsStmtFileMas status, since status is 10 ---> skip */
					for (TOmsStmtFileMas filemas : fileMasList) {
						filemas.setFileStatus(APIConstant._UPLOAD_FILE_NORMAL_STATUS);
						filemas.setProcessStatus(APIConstant._RECONCILE_PROCESSING_STATUS);
					}
					if(	updateTOmsStmtFileListToDB(fileMasList,  APIConstant._USERNAME_BATCHJOB)) {
						/**  Move file to NEW */
						for (TOmsStmtFileMas filemas : fileMasList) {
							for (File fil : files) {
								if(fil.getName().equals(filemas.getFileName())) {
									logger.info("**** Move file " + fil.getName() + " to " + env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_PROCESS_FOLDER));
									CommonUtil.moveFileToDirectory(fil, destFile);
								}
							}
							
						}
					}
				}
				
			}else {
				/** Insert data to TOmsStmtFileMas */
				
				TOmsStmtFileMas tOmsStmtFileMas = new TOmsStmtFileMas();
				tOmsStmtFileMas.setBankCode(bankFileVal.getBankAccNuber());
				tOmsStmtFileMas.setFileName(file.getName());
				tOmsStmtFileMas.setValueDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT));
				tOmsStmtFileMas.setFileStatus(APIConstant._UPLOAD_FILE_PENDING_STATUS);
				tOmsStmtFileMas.setProcessStatus(APIConstant._UPLOAD_FILE_PENDING_STATUS);
				tOmsStmtFileMas.setUploadDt(DateUtils.formatStringToDate(DateUtils.getSystemDateStr(DateUtils.DATEFORMAT), DateUtils.DATEFORMAT));
				tOmsStmtFileMas.setFileValidCount(tmBankTemplateInfo.getFileCnt());
				tOmsStmtFileMas.setUploadUser(APIConstant._OMS_FILESCANBATCH_);
				tOmsStmtFileMas.setFileType(APIConstant.LMS_TRX_TYPE_DISBURSAL);
				createTOmsStmtFileMasToDB(tOmsStmtFileMas, APIConstant._OMS_FILESCANBATCH_);
				logger.info("**** Insert " + file.getName() + " To DB ");		
			}
		}
	}

}
