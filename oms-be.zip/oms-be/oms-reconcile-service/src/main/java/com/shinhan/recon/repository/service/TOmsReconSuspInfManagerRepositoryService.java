/**
 * 
 */
package com.shinhan.recon.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.model.SuspenseTrxInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;
import com.shinhan.recon.repository.entity.TOmsReconSuspenseInf;

/**
 * @author shds04
 *
 */
public interface TOmsReconSuspInfManagerRepositoryService {
	
	public List<TOmsReconSuspenseInf> getListTrxByBankcodeAndDate(Map<String, Object> inputParams) throws BaseException;

	public List<SuspenseTrxInf> getSuspenseList(Map<String, Object> inputParams) throws BaseException;
	
	public List<TOmsReconSuspenseInf> getSuspenseByRef(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsReconSuspenseInf> getSuspenseByRevertRef(Map<String, Object> inputParams) throws BaseException;
	
	public boolean create(Map<String, Object> inputParams) throws BaseException;
	
	public boolean createAll(Map<String, Object> inputParams) throws BaseException;
	
	public boolean update(Map<String, Object> inputParams) throws BaseException;

	public boolean updateAll(Map<String, Object> inputParams) throws BaseException;

	public BigDecimal countTotalSuspenseTrxByDate(Map<String, Object> inputParams)throws BaseException;

	public TOmsReconSuspenseInf getOne(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsReconSuspenseInf> getListTrxByBankcodeAndFileId(Map<String, Object> inputParams) throws BaseException;

	public List<Object[]> getSuspenseListForReport(Map<String, Object> inputParams) throws BaseException;
	
}
