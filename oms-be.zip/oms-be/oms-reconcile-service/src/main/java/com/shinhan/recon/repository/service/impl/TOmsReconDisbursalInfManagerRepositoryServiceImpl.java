/**
 * 
 */
package com.shinhan.recon.repository.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankDailyReportInf;
import com.shinhan.recon.core.model.BankStatemenTrxInfo;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.repository.dao.TOmsReconDisbursalInfDAO;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.service.TOmsReconDisbursalInfManagerRepositoryService;

/**
 * @author shds04
 *
 */

@Service("tOmsReconDisbursalInfManagerRepositoryService")
public class TOmsReconDisbursalInfManagerRepositoryServiceImpl  extends AbstractServiceClass
implements TOmsReconDisbursalInfManagerRepositoryService{
	
	private TOmsReconDisbursalInfDAO objectDao;

	@Autowired
	public TOmsReconDisbursalInfManagerRepositoryServiceImpl(TOmsReconDisbursalInfDAO objectDao) {
		this.objectDao = objectDao;
	}
	
	@Override
	public List<TOmsReconDisburInf> getSpecInfs(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconDisburInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getSpecDisbByLoanAndAmt");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		String drAmtString = inputParams.get(APIConstant._DR_AMT_KEY).toString();
		BigDecimal drAmt = new BigDecimal( StringUtils.isBlank(drAmtString) ? "0" :drAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconDisburInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant.LOAN_NO_KEY,loanNo);
		query.setParameter(APIConstant._DR_AMT_KEY,drAmt);
		query.setParameter(APIConstant._STATUS_KEY,inputParams.get(APIConstant._STATUS_KEY).toString());
		list = query.getResultList();
		return list;
	}
	@Override
	public List<TOmsReconDisburInf> getDisbursByBankCodeAndStatus(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconDisburInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getDisbursByBankCodeAndStatus");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		String status = inputParams.get(APIConstant._STATUS_KEY).toString();
		Query query = entityManager.createNativeQuery(sql,TOmsReconDisburInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant.LOAN_NO_KEY,loanNo);
		query.setParameter(APIConstant._STATUS_KEY,status);
		list = query.getResultList();
		return list;
	}

	@Override
	public List<TOmsReconDisburInf> getListRevertTrxMatchWithLoanNo(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconDisburInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getListRevertDisburTrxMatchWithLoan");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String loanNo = inputParams.get(APIConstant.LOAN_NO_KEY).toString();
		String crAmtString = inputParams.get(APIConstant._DR_AMT_KEY).toString();
		
		BigDecimal crAmt = new BigDecimal( StringUtils.isBlank(crAmtString) ? "0" :crAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconLmsInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant.LOAN_NO_KEY,loanNo);
		query.setParameter(APIConstant._CR_AMT_KEY,crAmt);
		query.setParameter(APIConstant._STATUS_KEY,inputParams.get(APIConstant._STATUS_KEY).toString());
		list = query.getResultList();
		return list;
	}
	
	@Override
	public boolean create(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconDisburInf item = (TOmsReconDisburInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean createAll(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconDisburInf> items = (List<TOmsReconDisburInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public TOmsReconDisburInf getOne(Map<String, Object> inputParams) throws BaseException {
		String omsId = inputParams.get(APIConstant.OMSID).toString();
		if (StringUtils.isBlank(omsId)) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_003"));
		}
		try {
			TOmsReconDisburInf item = objectDao.findById(Long.valueOf(omsId)).get();
			return item;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002") + "." + omsId + "");
		}
	}

	@Override
	public boolean update(Map<String, Object> inputParams) throws BaseException {
		try {
			TOmsReconDisburInf item = (TOmsReconDisburInf) inputParams.get(APIConstant.DOCUMENT);
			if (item != null) {
				objectDao.save(item);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public boolean updateALL(Map<String, Object> inputParams) throws BaseException {
		try {
			List<TOmsReconDisburInf> items = (List<TOmsReconDisburInf>) inputParams.get(APIConstant.DOCUMENT);
			if (CollectionUtils.isNotEmpty(items)) {
				objectDao.saveAll(items);
				return true;
			}
			return false;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(env.getProperty("MSG_002"));
		}
	}

	@Override
	public List<BankStatementLmsTrxInfo> getListMatchingTrxByDate(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT new com.shinhan.recon.core.model.BankStatementLmsTrxInfo("
					+ "bank.id as id, bank.refNo as refNo, bank.trxDt as trxDt, bank.bankCode as bankCode, "
					+ "bank.drAmt as drAmt, bank.crAmt as crAmt, bank.loanNo as loanNo, "
					+ "bank.statusCode as statusCode, bank.subStatusCode as subStatusCode, bank.remark as remark, bank.remarkNote as remarkNote, "
					+ "lms.id as idLMS, lms.refNo as refNoLMS, lms.bankCode as bankCodeLMS, lms.trxDt as trxDtLMS, "
					+ "lms.valueDt as valueDtLMS, lms.cif as cifLMS, lms.paymode as paymodeLMS, "
					+ "lms.drAmt as drAmtLMS, lms.crAmt as crAmtLMS, lms.loanNo as loanNoLMS, "
					+ "lms.statusCode as statusCodeLMS, lms.subStatusCode as subStatusCodeLMS, lms.remark as remarkLMS, lms.remarkNote as remarkNoteLMS"
					+ ") "
					+ "FROM TOmsReconLmsInf lms, TOmsReconDisburInf bank "
					+ "WHERE lms.trxDt = bank.trxDt and bank.bankCode = lms.bankCode and lms.statusCode = bank.statusCode "
					+ "and lms.refID = bank.refID "
					+ "and lms.trxDt BETWEEN :fromDt and :endDt "
					+ "and lms.bankCode =:bankCode and lms.statusCode =:statusCode "
					+ "and (:ref is NULL or lms.refNo =:ref) "
					+ "and (:loanNo is NULL or lms.loanNo =:loanNo) "
					+ "and (:cif is NULL or lms.cif =:cif)";
			
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			
			Query query = entityManager.createQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_MATCH_STATUS));
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			query.setParameter("cif", inputParams.get(APIConstant.CIF_KEY).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			List<BankStatementLmsTrxInfo> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	@Override
	public List<Object[]> getMatchListDisbursalByDateAndBankCode(Map<String, Object> inputParams)
			throws BaseException {
		try {
			List<Object[]> result = new ArrayList<>();
			String sql = "SELECT "
					+ "bank.TRX_DT as trxDt, bank.REF_NO as refNo, bank.REMARK as remark, "
					+ "bank.DR_AMT as drAmt, bank.CR_AMT as crAmt, bank.LOAN_NO as loanNo, "
					+ "lms.TRX_DT as trxDtLMS, lms.REF_NO as refNoLMS, lms.LOAN_NO as loanNoLMS, "
					+ "lms.CIF as cif,lms.paymode as paymode, "
					+ "lms.DR_AMT as drAmtLMS, lms.CR_AMT as crAmtLMS, lms.REMARK_NOTE as remarkLMS "
					+ "FROM OMS_RECON_LMS_INF lms, OMS_RECON_DISBURS_INF bank "
					+ "WHERE bank.BANK_CODE = lms.BANK_CODE and lms.STATUS = bank.STATUS "
					+ "and lms.REF_ID = bank.REF_ID "
					+ "and lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS =:statusCode "
					+ "ORDER BY bank.LOAN_NO";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_MATCH_STATUS));
			result = query.getResultList();
			
			for ( int i = 0; i < result.size(); i ++ ) {
				for(int j = i + 1; j < result.size(); j++) {
					if(result.get(i)[8].equals(result.get(j)[8]) && result.get(i)[12].equals(result.get(j)[12]) ) {
						for(int idx = 6; idx< 14; idx++) {
							result.get(j)[idx] = " ";
						}
					}else {
						break;
					}
				}
			}
			return result;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	@Override
	public BankStatementLmsTrxInfo sumDrAndCrMatchListDisbursalTrxByDateAndBankCode(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT MAX(drAmt) as drAmt, MAX(crAmt) as crAmt, MAX(drAmtLMS) as drAmtLMS, MAX(crAmtLMS) as crAmtLMS from ( "
					+ "SELECT "
					+ "SUM(bank.DR_AMT) as drAmt, SUM(bank.CR_AMT) as crAmt, "
					+ "0 as drAmtLMS, 0 as crAmtLMS "
					+ "FROM OMS_RECON_DISBURS_INF bank "
					+ "WHERE bank.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and bank.BANK_CODE =:bankCode and bank.STATUS =:statusCode "
					+ "union all "
					+ "SELECT "
					+ "0 as drAmt, 0 as crAmt, "
					+ "SUM(lms.DR_AMT) as drAmtLMS, SUM(lms.CR_AMT) as crAmtLMS "
					+ "FROM OMS_RECON_LMS_INF lms "
					+ "WHERE lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.TRANSACTION_TYPE = :transactionType "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS =:statusCode "
					+ ")";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_MATCH_STATUS));
			query.setParameter("transactionType", Long.valueOf(APIConstant.LMS_TRX_TYPE_DISBURSAL));
			
			List<Object[]> lst = query.getResultList();
			
			for(Object[] item : lst){
				if(item[0] == null) {
					return new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
				}
				return new BankStatementLmsTrxInfo(new BigDecimal(item[0] + ""), new BigDecimal(item[1] + "")
						, new BigDecimal(item[2] + ""), new BigDecimal(item[3] + ""));
			}
			return new BankStatementLmsTrxInfo();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	
	@Override
	public BankStatementLmsTrxInfo sumDrAndCrUnMatchListDisbursalTrxByDateAndBankCode(
			Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT "
					+ "SUM(bank.DR_AMT) as drAmt, SUM(bank.CR_AMT) as crAmt "
					+ "FROM OMS_RECON_DISBURS_INF bank "
					+ "WHERE "
					+ "bank.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and bank.STATUS <> 7 "
					+ "and bank.BANK_CODE =:bankCode and bank.STATUS <> :statusCode ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_STATEMENT_MATCH_STATUS));
			
			List<Object[]> lst = query.getResultList();
			
			for(Object[] item : lst){
				if(item[0] == null) {
					return new BankStatementLmsTrxInfo(APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
				}
				return new BankStatementLmsTrxInfo(new BigDecimal(item[0] + ""), new BigDecimal(item[1] + ""), APIConstant.DEC_ZERO, APIConstant.DEC_ZERO);
			}
			return new BankStatementLmsTrxInfo();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	@Override
	public BigDecimal countTotalUnmatchDisbByDate(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT count( distinct bank.ID) "
					+ "FROM OMS_RECON_DISBURS_INF bank "
					+ "WHERE "
					+ "bank.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and bank.BANK_CODE = :bankCode "
					+ "and bank.STATUS  not in (1) "
					+ "and DECODE(:statusCode,0,bank.STATUS,:statusCode) = bank.STATUS "
					+ "and (:ref is NULL or bank.REF_NO =:ref) "
					+ "and (:loanNo is NULL or bank.LOAN_NO =:loanNo) ";
			
			Query query = entityManager.createNativeQuery(sql);
			long statusCode = StringUtils.isBlank(inputParams.get(APIConstant._STATUS_KEY).toString())
					? 0
					: Long.parseLong(inputParams.get(APIConstant._STATUS_KEY).toString());
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", statusCode);
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	
	@Override
	public List<BankStatemenTrxInfo> getUnmatchListDisbByDate(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT new com.shinhan.recon.core.model.BankStatemenTrxInfo("
					+ "bank.id as id, bank.refNo as refNo, bank.trxDt as trxDt, bank.bankCode as bankCode, "
					+ "bank.drAmt as drAmt, bank.crAmt as crAmt, bank.loanNo as loanNo, "
					+ "bank.statusCode as statusCode, bank.subStatusCode as subStatusCode, bank.remark as remark, bank.remarkNote as remarkNote"
					+ ") "
					+ "FROM TOmsReconDisburInf bank "
					+ "where bank.trxDt BETWEEN :fromDt and :endDt "
					+ "and bank.bankCode =:bankCode "
					+ "and bank.statusCode  not in (1) "
					+ "and DECODE(:statusCode,0,bank.statusCode,:statusCode) = bank.statusCode "
					+ "and bank.refID is NULL "
					+ "and (:ref is NULL or bank.refNo =:ref) "
					+ "and (:loanNo is NULL or bank.loanNo =:loanNo) ";
			
			int pageNumber = inputParams.get(APIConstant._START_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._START_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._START_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._START_KEY).toString());
			
			int pageSize = inputParams.get(APIConstant._NUMBER_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant._NUMBER_KEY).toString())
							? Integer.valueOf(env.getProperty(APIConstant._NUMBER_KEY))
							: Integer.parseInt(inputParams.get(APIConstant._NUMBER_KEY).toString());
			long statusCode = StringUtils.isBlank(inputParams.get(APIConstant._STATUS_KEY).toString())
					? 0
					: Long.parseLong(inputParams.get(APIConstant._STATUS_KEY).toString());
			Query query = entityManager.createQuery(sql);
			query.setParameter("statusCode",statusCode);
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode",statusCode);
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			
			query.setFirstResult((pageNumber - 1) * pageSize);
			query.setMaxResults(pageSize);
			
			List<BankStatemenTrxInfo> list = query.getResultList();
			
			return list;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	
	@Override
	public List<Object[]> getUnMatchListTrxByDateAndBankCodeAndStatus(Map<String, Object> inputParams)
			throws BaseException {
		try {
			String sql = "SELECT "
					+ "bank.TRX_DT as trxDt, bank.REF_NO as refNo, bank.REMARK as remark, "
					+ "bank.DR_AMT as drAmt, bank.CR_AMT as crAmt, bank.LOAN_NO as loanNo, "
					+ "'' as trxDtLMS, '' as refNoLMS, '' as loanNoLMS, "
					+ "'' as cif, '' as paymode, "
					+ "'' as drAmtLMS, '' as crAmtLMS, bank.REMARK_NOTE as remarkLMS "
					+ "FROM OMS_RECON_DISBURS_INF bank "
					+ "WHERE bank.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and bank.BANK_CODE =:bankCode and bank.STATUS = :statusCode ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			
			query.setParameter("statusCode", Long.valueOf(inputParams.get(APIConstant._STATUS_KEY).toString()));
			
			return query.getResultList();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	@Override
	public BigDecimal countTotalDisbursalTrxByDate(Map<String, Object> inputParams) throws BaseException {
		try {
			String sql = "SELECT count( distinct lms.ID) "
					+ "FROM OMS_RECON_LMS_INF lms, OMS_RECON_DISBURS_INF bank "
					+ "WHERE lms.TRX_DT = bank.TRX_DT and bank.BANK_CODE = lms.BANK_CODE and lms.STATUS = bank.STATUS and lms.REF_ID = bank.REF_ID "
					+ "and lms.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and lms.BANK_CODE =:bankCode and lms.STATUS =:statusCode "
					+ "and lms.TRANSACTION_TYPE = :transactionType "
					+ "and (:ref is NULL or lms.REF_NO =:ref) "
					+ "and (:loanNo is NULL or lms.LOAN_NO =:loanNo) "
					+ "and (:cif is NULL or lms.CIF =:cif)";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("cif", inputParams.get(APIConstant.CIF_KEY).toString());
			
			query.setParameter("statusCode", APIConstant._BANK_STATEMENT_MATCH_STATUS);
			
			query.setParameter("ref", inputParams.get(APIConstant.REF_KEY).toString());
			query.setParameter("loanNo", inputParams.get(APIConstant.LOAN_NO_KEY).toString());
			long trxType = inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY) == null
					|| StringUtils.isBlank(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString())
					? 0
					: Integer.parseInt(inputParams.get(APIConstant.UPLOAD_TRXTYPE_KEY).toString());
			query.setParameter(APIConstant.UPLOAD_TRXTYPE_KEY, trxType);
			BigDecimal countResult = (BigDecimal) query.getSingleResult();
			return countResult;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	@Override
	public List<TOmsReconDisburInf> getDisburByRefNo(Map<String, Object> inputParams) throws BaseException {
		List<TOmsReconDisburInf> list = new ArrayList<>();
		String sql = oracleOMSNamedQueries.get("getSpecDisbByRefAndAmt");
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String refNo = inputParams.get(APIConstant._REF_NO_KEY).toString();
		String drAmtString = inputParams.get(APIConstant._DR_AMT_KEY).toString();
		BigDecimal drAmt = new BigDecimal( StringUtils.isBlank(drAmtString) ? "0" :drAmtString );
		Query query = entityManager.createNativeQuery(sql,TOmsReconDisburInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY,bankCode);
		query.setParameter(APIConstant._REF_NO_KEY,refNo);
		query.setParameter(APIConstant._DR_AMT_KEY,drAmt);
		list = query.getResultList();
		return list;
	}

	@Override
	public List<Object[]> getPendingListDisbursalForReport(Map<String, Object> inputParams) throws BaseException {
		try {
			List<Object[]> result = new ArrayList<>();
			String sql = "SELECT "
					+ "bank.BANK_CODE as bankCode, bank.TRX_DT as trxDt, bank.REF_NO as refNo, bank.REMARK as remark, "
					+ "bank.DR_AMT as drAmt, bank.CR_AMT as crAmt, bank.LOAN_NO as loanNo, bank.REMARK_NOTE as remarkNote "
					+ "FROM OMS_RECON_DISBURS_INF bank "
					+ "WHERE bank.TRX_DT BETWEEN :fromDt and :endDt "
					+ "and bank.BANK_CODE =:bankCode and bank.STATUS =:statusCode ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", DateUtils.convertDate(inputParams.get(APIConstant._START_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("endDt", DateUtils.convertDate(inputParams.get(APIConstant._END_DATE_KEY).toString(), DateUtils.DATEFORMAT));
			query.setParameter("bankCode", inputParams.get(APIConstant._BANK_CODE_KEY).toString());
			query.setParameter("statusCode", Long.valueOf(APIConstant._BANK_DISBURSAL_STATUS_PENDING));
			result = query.getResultList();
			
			return result;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002") + "." + inputParams.get(APIConstant.USERNAME_KEY).toString() + "");
		}
	}
	@Override
	public BankDailyReportInf getDailyCollDisbInf(Map<String, Object> inputParams) throws BaseException {
		try {
			String ref = inputParams.get(APIConstant.REF_KEY).toString();
//			String sql = "with tmp as ( "
//					+ "select to_date(:fromDt,'DD/MM/YYYY') + level -1 as trx_dt "
//					+ "from dual  "
//					+ "connect by level <=to_date(:endDt,'DD/MM/YYYY') - to_date(:fromDt,'DD/MM/YYYY') "
//					+ ") "
//					+ "select * from ( "
//					+ "select tmp_bank.VALUE as BANK_CODE,"
//					+ oracleOMSNamedQueries.get("getsumcolldisb") + ",TO_CHAR(tmp.trx_dt,'DD/MM/YYYY') as trx_dt "
//					+ "from oms_recon_disburs_inf a, tmp,OMS_METADATA tmp_bank "
//					+ "where a.trx_dt(+) = tmp.trx_dt "
//					+ "AND tmp_bank.LOOKUPCODE = 'BANK_CODE_DISB' "
//					+ "and a.bank_code(+) = tmp_bank.LOOKUPCODEID "
//					+ "group by tmp_bank.VALUE, tmp.trx_dt) "
//					+ "pivot ( sum(amt) for trx_dt in ( " +ref + ") ) ";
			String sql = "with tmp as ( "
					+ "select to_date(:fromDt,'DD/MM/YYYY') + level -1 as trx_dt "
					+ "from dual  "
					+ "connect by level <=to_date(:endDt,'DD/MM/YYYY') - to_date(:fromDt,'DD/MM/YYYY') "
					+ ") "
					+ "select * from ( "
					+ "select tmp_bank.VALUE as BANK_CODE,"
					+ oracleOMSNamedQueries.get("getsumcolldisb") + ",TO_CHAR(f.upload_dt,'DD/MM/YYYY') as trx_dt "
					+ "from oms_recon_disburs_inf a, tmp,OMS_METADATA tmp_bank, oms_stmt_file_mas f "
					+ "where f.upload_dt(+) = tmp.trx_dt "
					+ "AND tmp_bank.LOOKUPCODE = 'BANK_CODE_DISB' "
					+ "and f.bank_code(+) = tmp_bank.LOOKUPCODEID "
					+ "and f.id = a.ref_id_file_mas(+) "
					+ "and a.bank_code(+) = tmp_bank.LOOKUPCODEID "
					+ "group by tmp_bank.VALUE, f.upload_dt) "
					+ "pivot ( sum(amt) for trx_dt in ( " +ref + ") ) ";
			
			Query query = entityManager.createNativeQuery(sql);
			
			query.setParameter("fromDt", inputParams.get(APIConstant._START_DATE_KEY).toString());
			query.setParameter("endDt", inputParams.get(APIConstant._END_DATE_KEY).toString());
			BankDailyReportInf bankDailyReportInf = new BankDailyReportInf();
			bankDailyReportInf.setData(query.getResultList());
			return bankDailyReportInf;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServiceRuntimeException(
					env.getProperty("MSG_002"));
		}
	}
	@Override
	public List<TOmsReconDisburInf> getListTrxByBankcodeAndFileId(Map<String, Object> inputParams) throws BaseException {
		List< TOmsReconDisburInf> rs = new ArrayList<>();
		String bankCode = inputParams.get(APIConstant._BANK_CODE_KEY).toString();
		String fileId = inputParams.get(APIConstant.FILE_ID).toString();
		String sql = oracleOMSNamedQueries.get("getDisbDataByBankCodeAndFileId");
		Query query = entityManager.createNativeQuery(sql, TOmsReconDisburInf.class);
		query.setParameter(APIConstant._BANK_CODE_KEY, bankCode);
		query.setParameter(APIConstant.FILE_ID, fileId);
		rs = query.getResultList();
		return rs;
	}
}
