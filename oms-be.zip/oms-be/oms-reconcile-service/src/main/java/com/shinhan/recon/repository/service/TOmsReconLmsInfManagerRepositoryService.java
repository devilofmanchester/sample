/**
 * 
 */
package com.shinhan.recon.repository.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.model.BankStatementLmsTrxInfo;
import com.shinhan.recon.core.model.LmsTrxInfo;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;

/**
 * @author shds01
 *
 */
public interface TOmsReconLmsInfManagerRepositoryService {

	public List<TOmsReconLmsInf> getListLmsTrxByDate(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsReconLmsInf> getListLmsTrxMatchWithStmtRef(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsReconLmsInf> getListLmsTrxMatchWithRevertRef(Map<String, Object> inputParams) throws BaseException;

	public List<TOmsReconLmsInf> getListLmsTrxMatchByLoanAndCrAmt(Map<String, Object> inputParams) throws BaseException;
	
	public List<TOmsReconLmsInf> getListLmsTrxByBankCode(Map<String, Object> inputParams) throws BaseException;
   
	public List<TOmsReconLmsInf> getListLmsTrxByBankCodeAndDate(Map<String, Object> inputParams) throws BaseException;

	public boolean create(Map<String, Object> inputParams) throws BaseException;
	
	public boolean createAll(Map<String, Object> inputParams) throws BaseException;
	
	public TOmsReconLmsInf getOne(Map<String, Object> inputParams) throws BaseException;
	
	public boolean update(Map<String, Object> inputParams) throws BaseException;
	
	public boolean updateALL(Map<String, Object> inputParams) throws BaseException;
	
	public BigDecimal countTotalUnMatchLMSTrxByDate(Map<String, Object> inputParams) throws BaseException;
	
	public List<LmsTrxInfo> getUnmatchListLMSTrxByDate(Map<String, Object> inputParams) throws BaseException;
	
	public List<Object[]> getUnMatchListTrxByDateAndBankCodeAndStatus(Map<String, Object> inputParams) throws BaseException;

	public List<Object[]> getPendingListTrxForReport(Map<String, Object> inputParams) throws BaseException;

	public List<Object[]> getListTrxByDateAndBankCodeAndStatuses(Map<String, Object> inputParams) throws BaseException;

	public List<Object[]> getUnMatchListTrxByDateAndBankCodeAndNonStatus(Map<String, Object> inputParams) throws BaseException;
	
	public BankStatementLmsTrxInfo sumDrAndCrUnMatchListLMSTrxByDateAndBankCode(Map<String, Object> inputParams) throws BaseException;
}
