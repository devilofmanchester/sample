/**
 * 
 */
package com.shinhan.recon.service;

import java.io.File;
import java.util.Collection;
import java.util.List;

import com.shinhan.recon.repository.entity.TBankCommon;

/**
 * @author shds04
 *
 */
public interface ReconcileBankStatementOCBService {
	public void processReconcileBankStatementOCB(Collection<File> files, List<TBankCommon> tBankCommons) throws Exception;
	
	public void processReconcileBankStatementOCBAd(File file, List<TBankCommon> tBankCommons)throws Exception;
	
	public void processReconcileBankStatementOCBIb(File file, List<TBankCommon> tBankCommons)throws Exception;
	
	public void processReconcileBankStatementOCBOtc(File file, List<TBankCommon> tBankCommons)throws Exception;
	
	public void processReconcileBankStatementOCB061(File file, List<TBankCommon> tBankCommons)throws Exception;
}
