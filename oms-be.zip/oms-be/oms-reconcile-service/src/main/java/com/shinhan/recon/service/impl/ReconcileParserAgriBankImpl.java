/**
 * 
 */
package com.shinhan.recon.service.impl;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.UnaryOperator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.ServiceInvalidAgurmentException;
import com.shinhan.recon.core.model.BankTemplateInfo;
import com.shinhan.recon.core.model.statement.BankStatementCommonTemplate;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.core.util.ReadFromExcel;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.service.ReconcileParser;

/**
 * @author shds04
 *
 */
@Service
public class ReconcileParserAgriBankImpl  extends AbstractServiceClass implements ReconcileParser {

	@Override
	public List<BankStatementCommonTemplate> getBankStatement(File file, TBankCommon bankVal, Object bankTemplate,
			Map<String, String> glBaMap) throws Exception {
		ReadFromExcel rw = new ReadFromExcel(file.getAbsolutePath());
		BankTemplateInfo templateInfo = DTOConverter.getBankTemplateInfo(bankVal);
		ArrayList<Map> lsArrMapObject = (ArrayList<Map>) rw.readDataFromExcel(templateInfo.getSheetIndex(), templateInfo.getFromRow(), templateInfo.getHeaderRow());
			Pattern pLoan = Pattern.compile(oracleOMSNamedQueries.get(APIConstant._REGEX_GET_LOAN_NO).replaceAll("\\s+",""));
			Pattern p = Pattern.compile(oracleOMSNamedQueries.get(APIConstant._REGEX_GET_REF_AGRIBANK).replaceAll("\\s+", ""));
			for (Map map : lsArrMapObject) {
				map.put("crAmt", "0");
				map.put("drAmt", "0");
				if(String.valueOf(map.get("+/-")).equals("+")) {
					map.put("crAmt", map.get("So Tien Giao dich"));
				}else {
					map.put("drAmt", map.get("So Tien Giao dich"));
				}
				String loanRefNoFromDesc =String.valueOf(map.get("Dien Giai")).toLowerCase().replaceAll(" ", "");
				Matcher matcher = p.matcher(loanRefNoFromDesc);
				String regexString = "";
				
				if(matcher.find()) {
					regexString = matcher.group(0);
				}
				
				String[] loanRefNoFromDescArr = regexString.split("\\|");
				if(loanRefNoFromDescArr.length == 2) {
					map.put("refNo", loanRefNoFromDescArr[0]);
					map.put("loanNo", loanRefNoFromDescArr[1]);
				}else {
					String loanNo = "";
					Matcher mLoan = pLoan.matcher(" " + map.get("Dien Giai") + " ");
					if(mLoan.find()) {
						loanNo = mLoan.group(1);
					}
					String trxDt = map.get("Ngay Giao dich").toString().replaceAll("\\s.*", "");
					String format = DateUtils.getValidFormat(trxDt);
					map.put("loanNo", loanNo);
					map.put("refNo", "ARD" +   StringUtils.leftPad(loanNo, 9,"0")  + 
						DateUtils.formatToString(DateUtils.convertDate(trxDt, format, DateUtils.DATEFORMAT), DateUtils.ddMMyyyy) );
					
				}
			}
		/** Step 2: import raw excel data to java class and validation */
		JsonArray jsonArrayDocument = (JsonArray) CommonUtil.toPojo(lsArrMapObject, JsonArray.class);
		
		List<String> excelColumn = Arrays.asList(templateInfo.getTemplateColName().split(","));
		Field[] bankStatementProperty = bankTemplate.getClass().getDeclaredFields();
		
		Map<String, Entry<String, UnaryOperator<String>>> bankStatementMapping = buildBankStatementMapping(excelColumn, bankStatementProperty);
		List<BankStatementCommonTemplate> bankStatements = super.mapListExcelDataToListBankStatement(jsonArrayDocument, bankStatementMapping, BankStatementCommonTemplate::new);
		if(bankStatements.isEmpty()) {
			throw new ServiceInvalidAgurmentException(env.getProperty("MSG_006"));
		}
		glBaMap.put(APIConstant.GL_OPEN_BALANCE, rw.readFromSpecCell(templateInfo.getSheetIndex(), templateInfo.getGlOpenBlcRow(), templateInfo.getGlOpenBlcCol()));
		glBaMap.put(APIConstant.GL_CLOSE_BALANCE,rw.readFromSpecCell(templateInfo.getSheetIndex(), templateInfo.getGlCloseBlcRow(), templateInfo.getGlCloseBlcCol()));
		return bankStatements;
	}

}
