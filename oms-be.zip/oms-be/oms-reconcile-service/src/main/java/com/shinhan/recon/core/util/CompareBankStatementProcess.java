package com.shinhan.recon.core.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.print.CancelablePrintJob;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsReconStmtInf;

import oracle.net.aso.j;

public class CompareBankStatementProcess {
	/**
	 * This function will return matching both matching list between LMS and BankStatement
	 * @param List<TOmsReconStmtInf>
	 * @param List<TOmsReconLmsInf>
	 */
	public static void getMatchingList(List<TOmsReconStmtInf> comparatorList, List<TOmsReconLmsInf> comparedList,List<TOmsReconStmtInf> stmtResult, List<TOmsReconLmsInf> lmsResult){
		if(comparatorList == null || comparedList == null) {
			return ;
		}
		List<TOmsReconLmsInf> tmp =  new ArrayList<>();
		BigDecimal lmsCrAmt = BigDecimal.ZERO;
		for (TOmsReconStmtInf tOmsReconStmtInf : comparatorList) {
			lmsCrAmt = BigDecimal.ZERO;
			String loanNo = StringUtils.isBlank(tOmsReconStmtInf.getLoanNo()) ? "0":tOmsReconStmtInf.getLoanNo();
			tmp.clear();
			for (TOmsReconLmsInf tOmsReconLmsInf : comparedList) {
				if( tOmsReconStmtInf.getRefNo().trim().equals(tOmsReconLmsInf.getRefNo().trim())){
					if(tOmsReconStmtInf.getCrAmt().compareTo(tOmsReconLmsInf.getDrAmt()) == 0 ) {
						lmsCrAmt = lmsCrAmt.add(tOmsReconLmsInf.getDrAmt());
						tOmsReconLmsInf.setRefID(tOmsReconStmtInf.getRefNo()+loanNo + DateUtils.getSystemDateStr(DateUtils.DATE_FORMAT) );
						tOmsReconLmsInf.setRemarkNote(DateUtils.getDateFormat(tOmsReconStmtInf.getValueDt(), DateUtils.DATEFORMAT));
						tmp.add(tOmsReconLmsInf);
					}
					
				}else {
					if ( tOmsReconStmtInf.getRefNo().trim().startsWith(tOmsReconLmsInf.getRefNo().trim()) ) {
						lmsCrAmt = lmsCrAmt.add(tOmsReconLmsInf.getDrAmt());
						tOmsReconLmsInf.setRefID(tOmsReconStmtInf.getRefNo()+loanNo + DateUtils.getSystemDateStr(DateUtils.DATE_FORMAT) );
						tOmsReconLmsInf.setRemarkNote(DateUtils.getDateFormat(tOmsReconStmtInf.getValueDt(), DateUtils.DATEFORMAT));
						tmp.add(tOmsReconLmsInf);
					}
				}
				   
			}
			if(lmsCrAmt.compareTo(tOmsReconStmtInf.getCrAmt()) == 0 && lmsCrAmt.compareTo(BigDecimal.ZERO) > 0 && 
				( StringUtils.isBlank(tOmsReconStmtInf.getRemarkNote())? true : !tOmsReconStmtInf.getRemarkNote().equals(APIConstant.THE_DATA_INCORRECT_FORMAT_ERROR) ) ) {
				tOmsReconStmtInf.setRefID(tOmsReconStmtInf.getRefNo()+loanNo + DateUtils.getSystemDateStr(DateUtils.DATE_FORMAT));
				stmtResult.add(tOmsReconStmtInf);
				if( StringUtils.isBlank(tOmsReconStmtInf.getLoanNo()) ) {
					tOmsReconStmtInf.setSubStatusCode(APIConstant._LOAN_INPARSE_SUBSTATUS);
					tOmsReconStmtInf.setRemarkNote(APIConstant.THE_LOAN_BLANK_RMK);
				}else if(!StringUtils.isBlank(tOmsReconStmtInf.getLoanNo()) && !StringUtils.isBlank(tmp.get(0).getLoanNo())) {
					if(tOmsReconStmtInf.getLoanNo().equals(tmp.get(0).getLoanNo())) {
						tOmsReconStmtInf.setSubStatusCode(APIConstant._LOAN_CORRECT_SUBSTATUS);
						
					}else {
						tOmsReconStmtInf.setSubStatusCode(APIConstant._LOAN_INCORRECT_SUBSTATUS);
						tOmsReconStmtInf.setRemarkNote(APIConstant.THE_LOAN_INCORRECT_RMK);
					}
				}else {
					tOmsReconStmtInf.setSubStatusCode(APIConstant._LOAN_INCORRECT_SUBSTATUS);
					tOmsReconStmtInf.setRemarkNote(APIConstant.THE_LOAN_INCORRECT_RMK);
				}
				lmsResult.addAll(tmp);
			}
		}
	}
	public static void getMatchingList(List<TOmsReconDisburInf> comparatorList, List<TOmsReconLmsInf> comparedList,List<TOmsReconDisburInf> stmtResult, List<TOmsReconLmsInf> lmsResult, BigDecimal innerFeeAmt, BigDecimal outerFeeAmt){
		if(comparatorList == null || comparedList == null) {
			return ;
		}
		List<TOmsReconLmsInf> tmpLms =  new ArrayList<>();
		List<TOmsReconDisburInf> tmpDisbur =  new ArrayList<>();
		Map<String, BigDecimal> reconDisbMap = new HashMap<>();
		BigDecimal lmsCrAmt = BigDecimal.ZERO;
		for (TOmsReconDisburInf tDisburInf : comparatorList) {
			lmsCrAmt = BigDecimal.ZERO;
			for (TOmsReconDisburInf tDisburInf1 : comparatorList) {
				if(tDisburInf.getLoanNo().equals(tDisburInf1.getLoanNo())) {
					lmsCrAmt = lmsCrAmt.add(tDisburInf1.getDrAmt());
				}
			}
			
			if( !reconDisbMap.containsKey(tDisburInf.getLoanNo()) && !StringUtils.isBlank(tDisburInf.getLoanNo()) ) {
				reconDisbMap.put(tDisburInf.getLoanNo(), lmsCrAmt);
			}
		}
		
		Iterator<Entry<String, BigDecimal>> itr = reconDisbMap.entrySet().iterator();
		
		while (itr.hasNext()) {
			lmsCrAmt = BigDecimal.ZERO;
			tmpLms.clear();
			Map.Entry mapElement = (Map.Entry)itr.next();
			String mapLoanNo = mapElement.getKey().toString();
			BigDecimal mapAmt = new BigDecimal(mapElement.getValue().toString());
			for (TOmsReconLmsInf tOmsReconLmsInf : comparedList) {
				if(mapLoanNo.trim().equals(tOmsReconLmsInf.getLoanNo().trim())) {
					if(mapAmt.compareTo(tOmsReconLmsInf.getCrAmt().add(outerFeeAmt)) == 0 || mapAmt.compareTo(tOmsReconLmsInf.getCrAmt().add(innerFeeAmt)) == 0 || mapAmt.compareTo(tOmsReconLmsInf.getCrAmt()) == 0) {
						lmsCrAmt = lmsCrAmt.add(tOmsReconLmsInf.getCrAmt());
						tOmsReconLmsInf.setRefID(mapLoanNo + DateUtils.getSystemDateStr(DateUtils.DATE_FORMAT));
						tmpLms.add(tOmsReconLmsInf);
					}
				}else {
					if ( tOmsReconLmsInf.getLoanNo().trim().startsWith(mapLoanNo.trim())) {
						lmsCrAmt = lmsCrAmt.add(tOmsReconLmsInf.getCrAmt());
						tOmsReconLmsInf.setRefID(mapLoanNo + DateUtils.getSystemDateStr(DateUtils.DATE_FORMAT));
						tmpLms.add(tOmsReconLmsInf);
					}
				}
				   
			}
			BigDecimal lmsInnerFee = lmsCrAmt.add(innerFeeAmt);
			BigDecimal lmsOuterFee = lmsCrAmt.add(outerFeeAmt);
			if( ( lmsOuterFee.compareTo(mapAmt) == 0 || lmsInnerFee.compareTo(mapAmt) == 0 || lmsCrAmt.compareTo(mapAmt) == 0 ) && 
				lmsCrAmt.compareTo(BigDecimal.ZERO) > 0) {
				for (TOmsReconDisburInf tOmsReconDisburInf2 : comparatorList) {
					if(tOmsReconDisburInf2.getLoanNo().equals(mapLoanNo)) {
						tOmsReconDisburInf2.setRefID(tOmsReconDisburInf2.getLoanNo()+ DateUtils.getSystemDateStr(DateUtils.DATE_FORMAT));
						stmtResult.add(tOmsReconDisburInf2);
					}
				}
				lmsResult.addAll(tmpLms);
			}
		}
		
//		for (TOmsReconDisburInf tOmsReconDisburInf : tmpDisbur) {
//			lmsCrAmt = BigDecimal.ZERO;
//			tmpLms.clear();
//			for (TOmsReconLmsInf tOmsReconLmsInf : comparedList) {
//				if(tOmsReconDisburInf.getLoanNo().trim().equals(tOmsReconLmsInf.getLoanNo().trim())) {
//					if(tOmsReconDisburInf.getDrAmt().compareTo(tOmsReconLmsInf.getCrAmt()) == 0) {
//						lmsCrAmt = lmsCrAmt.add(tOmsReconLmsInf.getCrAmt());
//						tOmsReconLmsInf.setRefID(tOmsReconDisburInf.getLoanNo() + DateUtils.getSystemDateStr(DateUtils.DATE_FORMAT));
//						tmpLms.add(tOmsReconLmsInf);
//					}
//				}else {
//					if ( tOmsReconLmsInf.getLoanNo().trim().startsWith(tOmsReconDisburInf.getLoanNo().trim())) {
//						lmsCrAmt = lmsCrAmt.add(tOmsReconLmsInf.getCrAmt());
//						tOmsReconLmsInf.setRefID(tOmsReconDisburInf.getLoanNo() + DateUtils.getSystemDateStr(DateUtils.DATE_FORMAT));
//						tmpLms.add(tOmsReconLmsInf);
//					}
//				}
//				   
//			}
//			BigDecimal lmsInnerFee = lmsCrAmt.add(innerFeeAmt);
//			BigDecimal lmsOuterFee = lmsCrAmt.add(outerFeeAmt);
//			if( ( lmsOuterFee.compareTo(tOmsReconDisburInf.getDrAmt()) == 0 || lmsInnerFee.compareTo(tOmsReconDisburInf.getDrAmt()) == 0) && 
//				lmsCrAmt.compareTo(BigDecimal.ZERO) > 0) {
//				for (TOmsReconDisburInf tOmsReconDisburInf2 : comparatorList) {
//					if(tOmsReconDisburInf2.getLoanNo().equals(tOmsReconDisburInf.getLoanNo())) {
//						tOmsReconDisburInf2.setRefID(tOmsReconDisburInf2.getLoanNo()+ DateUtils.getSystemDateStr(DateUtils.DATE_FORMAT));
//						stmtResult.add(tOmsReconDisburInf2);
//					}
//				}
//				lmsResult.addAll(tmpLms);
//			}
//		}
	}
	
	public static List<TOmsReconStmtInf> getMatchingListByPattern(List<TOmsReconStmtInf> comparatorList, String regex){
		if(comparatorList == null ) {
			return new ArrayList<TOmsReconStmtInf>();
		}
		List<TOmsReconStmtInf> rsInfs = new ArrayList<>();
		Pattern pattern = Pattern.compile(regex);
		for (TOmsReconStmtInf tOmsReconStmtInf : comparatorList) {
			String str = tOmsReconStmtInf.getRemark().toLowerCase().replaceAll("\\s+", "");
			if(pattern.matcher(str).find()) {
				rsInfs.add(tOmsReconStmtInf);
			}
		}
		//Predicate<TOmsReconStmtInf> predicate = e->(pattern.matcher( e.getRemark().toLowerCase().replaceAll(" ", "")).find());
		return rsInfs; //comparatorList.stream().filter(predicate).collect(Collectors.toList());
	}
	
	public static <T> List<T> getMatchingListByPredict(List<T> comparatorList, Predicate<T> predicate){
		if(comparatorList == null ) {
			return new ArrayList<T>();
		}
		return comparatorList.stream().filter(predicate).collect(Collectors.toList());
	}
	
	public static List<TOmsReconStmtInf> getFinanceList(List<TOmsReconStmtInf> comparatorList){
		if(comparatorList == null ) {
			return new ArrayList<TOmsReconStmtInf>();
		}
		Predicate<TOmsReconStmtInf> predicate = e->( e.getDrAmt().compareTo(BigDecimal.ZERO) > 0 );
		return comparatorList.stream().filter(predicate).collect(Collectors.toList());
	}
	
}
