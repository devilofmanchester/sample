/**
 * 
 */
package com.shinhan.recon.job;

import java.time.LocalDateTime;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.shinhan.recon.common.AbstractBasicCommonClass;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.util.CommonUtil;

/**
 * @author shds01
 *
 */
@Component
public class ReconcileBatchJobBankStatement extends AbstractBasicCommonClass {

	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.reconBankStatement}") // 1 minutes
	public void scanBankStatementFile() throws BaseException {
		logger.info("***** Start Reconcile Re-payment File Bank Statement Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		boolean isFile = getProcessManagerService().getReconcileProcessService().getFileFromFTPServer();
		if (!isFile) {
			logger.info("***** No File Bank Statement To Scan :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		} else {
			try {
				getProcessManagerService().getReconcileProcessService().processReconcileBankStatement();
			} catch (Exception e) {
				logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
				logger.info("***** End Reconcile Re-payment File Bank Statement Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
			}
		}
		logger.info("***** End Reconcile Re-payment File Bank Statement Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		
		logger.info("***** Start Reconcile Disbursal File Bank Statement Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		isFile = getProcessManagerService().getReconcileDisbursProcessService().getFileFromFTPServer();
		if (!isFile) {
			logger.info("***** No File Disbursal Statement To Scan :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		} else {
			try {
				getProcessManagerService().getReconcileDisbursProcessService().processReconcileBankStatement();
			} catch (Exception e) {
				logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
				logger.info("***** End Reconcile Disbursal File Bank Statement Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
			}
		}
		logger.info("***** End Reconcile Disbursal File Bank Statement Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
}
