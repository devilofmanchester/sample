/**
 * 
 */
package com.shinhan.recon.disburs.service.impl;

import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.common.AbstractServiceClass;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.core.exception.ServiceRuntimeException;
import com.shinhan.recon.core.model.BankTemplateInfo;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.DTOConverter;
import com.shinhan.recon.core.util.DateUtils;
import com.shinhan.recon.disburs.service.ReconcileDisbursProcessService;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;

/**
 * @author shds04
 *
 */
@Service("reconcileDisbursProcessService")
@Transactional(readOnly = false, propagation =  Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
public class ReconcileDisbursProcessServiceImpl extends AbstractServiceClass implements ReconcileDisbursProcessService{

	@Override
	public boolean getFileFromFTPServer() throws ServiceRuntimeException, BaseException {
		Collection<File> files = getStatementFileFromFolderToRecon(env.getProperty(APIConstant.PATH_SCAN_DISBURSAL_STATEMENT_PROCESS_FOLDER ));
		if(files.size() > 0) {
			return true;
		}
		return false;
	}

	@Override
	public Collection<File> getStatementFileFromFolderToRecon(String path)
			throws ServiceRuntimeException, BaseException {
		return CommonUtil.getBankStatementFileInFolder(path);
	}

	@Override
	public void processReconcileBankStatement() throws Exception {
		logger.info("***** Start Reconcile Bank Disbursal *****");
		Map<String, Object> statementFileMasMap = new HashMap<String, Object>();
		statementFileMasMap.put(APIConstant.UPLOAD_DATE_KEY, DateUtils.getSystemDateStr(DateUtils.DATEFORMAT));
		statementFileMasMap.put(APIConstant.UPLOAD_BANKSTATUS_KEY, APIConstant._UPLOAD_FILE_DELETE_STATUS);
		statementFileMasMap.put(APIConstant.UPLOAD_TRXTYPE_KEY, APIConstant.LMS_TRX_TYPE_DISBURSAL);
		Collection<File> files = getStatementFileFromFolderToRecon(env.getProperty(APIConstant.PATH_SCAN_DISBURSAL_STATEMENT_PROCESS_FOLDER));
		List<TOmsStmtFileMas> tOmsStmtFileMasList= getRepositoryManagerService()
				.getTomsStmtFileMasManagerRepositoryService().getListUploadByDate(statementFileMasMap);
		List<TBankCommon> listBankCommonVal = getRepositoryManagerService().getUtilityManagerRepositoryService()
				.getBankCommonByBizValue(APIConstant._BANK_COMMON_BIZ_DISBURSAL_TEMPLATE_VALUE_);

		for (File file : files) {
			TBankCommon bankFileVal = getBankCommonValByBankCode(file.getName(), listBankCommonVal);
			BankTemplateInfo templateInfo = DTOConverter.getBankTemplateInfo(bankFileVal);
			List<TOmsStmtFileMas> fileMasList  = getListByBankCode(bankFileVal.getBankAccNuber(),tOmsStmtFileMasList );
			if( ( fileMasList.size() != templateInfo.getFileCnt() && 
				  getBankUploadedFileCount(files, listBankCommonVal) != templateInfo.getFileCnt()
				) || templateInfo.getFileCnt() == 0	) {
				logger.info("***** " + bankFileVal.getBankName() + " is not enough quantity to process " + "*****");
				continue;
			}
			switch (bankFileVal.getBankCode()) {
				case APIConstant.BANK_DISBURSAL_VIETCOMBANK:
					logger.info("***** Start Reconcile Bank Disbursal For VietComBank *****");
					
					try {
						getProcessManagerService().getReconcileDisbursalProcessVietcombankService().processReconcileBankDisbursalVietcombank(file, listBankCommonVal);
						logger.info("***** End Reconcile Bank Disbursal For VietComBank *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Reconcile Bank Statement For VietComBank *****");
					}
					
					break;
				case APIConstant.BANK_DISBURSAL_TECHCOMBANK:
					logger.info("***** Start Reconcile Bank Disbursal For Techcombank *****");
					
					try {
						getProcessManagerService().getReconcileDisbursalProcessTechcombankService().processReconcileBankDisbursalTechcombank(file, listBankCommonVal);
						logger.info("***** End Reconcile Bank Disbursal For Techcombank *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Reconcile Bank Statement For Techcombank *****");
					}
					
					break;
				case APIConstant.BANK_DISBURSAL_CITI:
					logger.info("***** Start Reconcile Bank Disbursal For Citibank *****");
					
					try {
						getProcessManagerService().getReconcileDisbursalProcessCitibankService().processReconcileBankDisbursalCitibank(file, listBankCommonVal);
						logger.info("***** End Reconcile Bank Disbursal For Citibank *****");
					} catch (Exception e) {
						logger.info("***** " + CommonUtil.getLogMessenge(e) + " *****");
						logger.info("***** End Reconcile Bank Statement For Citibank *****");
					}
					
					break;
			}

		}
		logger.info("***** End Reconcile Bank Statement *****");
	}
}
