package com.shinhan.recon.service;

import com.shinhan.recon.core.exception.BaseException;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;

public interface ReconcileLogProcessService {
	
	public void logToFileMas(TOmsStmtFileMas tOmsStmtFileMas, String logInf) throws BaseException;
	
}
