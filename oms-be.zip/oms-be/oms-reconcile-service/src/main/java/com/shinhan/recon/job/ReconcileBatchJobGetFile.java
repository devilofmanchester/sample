package com.shinhan.recon.job;

import java.io.File;
import java.time.LocalDateTime;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.shinhan.recon.common.AbstractBasicCommonClass;
import com.shinhan.recon.configure.NFsSourceProperties;
import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.core.util.NFsUtils;

@Component
public class ReconcileBatchJobGetFile extends AbstractBasicCommonClass{

	@Autowired
	private NFsSourceProperties sourceProperties;
	
	@Scheduled(fixedDelayString = "${spring.job.application.fixedDelay.getFileFromSfpt}") // 1 minutes
	public void scanBankStatementFile() throws Exception {
		logger.info("***** Start Getting File From NFS  :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		NFsUtils.downloadViaNFS(sourceProperties.getHost(), sourceProperties.getUsername(), sourceProperties.getPassword(), sourceProperties.getRemotedirectory(),env.getProperty(APIConstant.PATH_SCAN_BANK_STATEMENT_FTP_FOLDER) );
		
		logger.info("***** End Getting File From NFS :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		
		logger.info("***** Start Uploading File To NFS  :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
		Collection<File> files = CommonUtil.getBankStatementFileInFolder(env.getProperty(APIConstant.PATH_SCAN_BANK_TEMP_FOLDER));
	    for (File file : files) {
	    	NFsUtils.uploadViaNFS(sourceProperties.getHost(), sourceProperties.getUsername(), sourceProperties.getPassword(), sourceProperties.getRemotebackupdirectory(), env.getProperty(APIConstant.PATH_SCAN_BANK_TEMP_FOLDER), file.getName());
	    	//CommonUtil.deleteFile(file);
		}
	    logger.info("***** End Uploading File To NFS  :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()) + " *****");
	}
}
