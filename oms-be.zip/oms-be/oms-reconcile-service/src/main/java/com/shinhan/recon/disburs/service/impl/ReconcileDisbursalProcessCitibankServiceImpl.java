/**
 * 
 */
package com.shinhan.recon.disburs.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.model.BankDisbursInfo;
import com.shinhan.recon.core.model.disburs.statement.BankDisbursCitiTemplate;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.disburs.service.ReconcileDisbursalProcessCitibankService;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;
import com.shinhan.recon.service.impl.ReconcileConvertDisbCitiImpl;

/**
 * @author shds04
 *
 */
@Service("reconcileDisbursalProcessCitibankService")
@Transactional(readOnly = false, propagation =  Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
public class ReconcileDisbursalProcessCitibankServiceImpl extends AbstractReconcileDisbursalStatement implements ReconcileDisbursalProcessCitibankService {

	@Override
	public void processReconcileBankDisbursalCitibank(File file, List<TBankCommon> tBankCommons) throws Exception {
		/** Step 1: read raw data from excel */
		Map<String, String> glBalance = new HashMap<>();
		
		TBankCommon bankFileVal = getBankCommonValByBankCode(file.getName(), tBankCommons);
		BankDisbursInfo bankDisbursInfo =(BankDisbursInfo) CommonUtil.toPojo(bankFileVal.getAddInf(), BankDisbursInfo.class);
		List<TOmsReconDisburInf> MatchingList = new ArrayList<>(); 
		List<TOmsReconDisburInf> unMatchingList = new ArrayList<>(); 
		List<TOmsReconDisburInf> creditShieldList = new ArrayList<>(); 
		List<TOmsReconDisburInf> financeList = new ArrayList<>(); 
		List<TOmsReconDisburInf> feeFinanceList = new ArrayList<>(); 
		List<TOmsReconDisburInf> revertList = new ArrayList<>(); 
		List<TOmsReconLmsInf> lmsMatchingList = new ArrayList<>();
		List<TOmsReconLmsInf> lmsUnMatchingList = new ArrayList<>();
		List<TOmsStmtFileMas> tOmsStmtFileMasList = new ArrayList<>();
		
		List<TOmsReconDisburInf> omsReconDisburInfs = getBankStatement(file, bankFileVal, new BankDisbursCitiTemplate(),glBalance, new ReconcileConvertDisbCitiImpl()); 
//		Pattern p = Pattern.compile(oracleOMSNamedQueries.get(APIConstant._REGEX_GET_REF_OCB061).toLowerCase().replaceAll("\\s+", ""));
//		for (TOmsReconDisburInf tOmsReconDisburInf : omsReconDisburInfs) {
//			String loanRefNoFromDesc =tOmsReconDisburInf.getRefNo().toLowerCase().replaceAll("\\s+", "");
//			Matcher matcher = p.matcher(loanRefNoFromDesc);
//			String regexString = "";
//			
//			if(matcher.find()) {
//				regexString = matcher.group(0);
//			}
//			if(!StringUtils.isBlank(regexString)) {
//				tOmsReconDisburInf.setRefNo(regexString);
//			}
//		}
		getLoanNoFromDescription(omsReconDisburInfs, oracleOMSNamedQueries.get(APIConstant._REGEX_GET_LOAN_NO).replaceAll("\\s+",""));
		financeList = getListMatchPattern(omsReconDisburInfs, bankDisbursInfo.getRegFin());
		creditShieldList = getCrShieldList(omsReconDisburInfs, bankDisbursInfo.getRegShield());
		//revertList = getListMatchPattern(omsReconDisburInfs, bankDisbursInfo.getRegRevert());
		omsReconDisburInfs.removeAll(financeList);
		omsReconDisburInfs.removeAll(creditShieldList);
		feeFinanceList = getListFeeFinance(omsReconDisburInfs);
		omsReconDisburInfs.removeAll(feeFinanceList);
		financeList.addAll(feeFinanceList);
		omsReconDisburInfs.removeAll(revertList);
		processLoadReconcileInfo(file, bankFileVal, omsReconDisburInfs, tOmsStmtFileMasList, creditShieldList, financeList,
				 revertList, MatchingList, unMatchingList, lmsMatchingList, lmsUnMatchingList);
		TOmsStmtFileMas tOmsStmtFileMas = getFileMasByFileName(file.getName(), tOmsStmtFileMasList);
		
		processReconcileDataBase(tOmsStmtFileMas, creditShieldList, financeList, revertList,
				 MatchingList, unMatchingList, lmsMatchingList, lmsUnMatchingList);

		processLoadFileMasInf(tOmsStmtFileMas, omsReconDisburInfs.size(),MatchingList.size() , glBalance, loadAddInfForFileMas(creditShieldList, financeList, revertList, MatchingList, unMatchingList));
		/** Step 5: move file to Done folder */
		File destFile = new File(env.getProperty(APIConstant.PATH_SCAN_DISBURSAL_STATEMENT_DONE_FOLDER));
		moveFileToDirectory(file, destFile);		
	}

	@Override
	public List<TOmsReconDisburInf> getCrShieldList(List<TOmsReconDisburInf> tOmsReconDisburInfs, String regex) throws Exception {
		List<TOmsReconDisburInf> rs = new ArrayList<>();
		Pattern pattern = Pattern.compile(regex.toLowerCase().replaceAll("\\s+", ""));
		for (TOmsReconDisburInf tOmsReconDisburInf : tOmsReconDisburInfs) {
			Matcher matcher = pattern.matcher(tOmsReconDisburInf.getRemark().toLowerCase().replaceAll("\\s+", ""));
			if( matcher.find() ) {
				rs.add(tOmsReconDisburInf);
			}
		}
		return rs;
	}

	
}
