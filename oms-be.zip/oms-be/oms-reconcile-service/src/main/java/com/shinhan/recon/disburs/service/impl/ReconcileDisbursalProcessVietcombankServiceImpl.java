/**
 * 
 */
package com.shinhan.recon.disburs.service.impl;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shinhan.recon.core.constant.APIConstant;
import com.shinhan.recon.core.model.BankDisbursInfo;
import com.shinhan.recon.core.model.disburs.statement.BankDisbursVietcomBankTemplate;
import com.shinhan.recon.core.util.CommonUtil;
import com.shinhan.recon.disburs.service.ReconcileDisbursalProcessVietcombankService;
import com.shinhan.recon.repository.entity.TBankCommon;
import com.shinhan.recon.repository.entity.TOmsReconDisburInf;
import com.shinhan.recon.repository.entity.TOmsReconLmsInf;
import com.shinhan.recon.repository.entity.TOmsStmtFileMas;

/**
 * @author shds04
 *
 */
@Service("reconcileDisbursalProcessVietcombankService")
@Transactional(readOnly = false, propagation =  Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
public class ReconcileDisbursalProcessVietcombankServiceImpl extends AbstractReconcileDisbursalStatement implements ReconcileDisbursalProcessVietcombankService {

	@Override
	public void processReconcileBankDisbursalVietcombank(File file, List<TBankCommon> tBankCommons) throws Exception {
		/** Step 1: read raw data from excel */
		Map<String, String> glBalance = new HashMap<>();
		
		TBankCommon bankFileVal = getBankCommonValByBankCode(file.getName(), tBankCommons);
		BankDisbursInfo bankDisbursInfo =(BankDisbursInfo) CommonUtil.toPojo(bankFileVal.getAddInf(), BankDisbursInfo.class);
		List<TOmsReconDisburInf> MatchingList = new ArrayList<>(); 
		List<TOmsReconDisburInf> unMatchingList = new ArrayList<>(); 
		List<TOmsReconDisburInf> creditShieldList = new ArrayList<>(); 
		List<TOmsReconDisburInf> financeList = new ArrayList<>(); 
		List<TOmsReconDisburInf> revertList = new ArrayList<>(); 
		List<TOmsReconLmsInf> lmsMatchingList = new ArrayList<>();
		List<TOmsReconLmsInf> lmsUnMatchingList = new ArrayList<>();
		List<TOmsStmtFileMas> tOmsStmtFileMasList = new ArrayList<>();
		
		List<TOmsReconDisburInf> omsReconDisburInfs = getBankStatement(file, bankFileVal, new BankDisbursVietcomBankTemplate(),glBalance); 
		getLoanNoFromDescription(omsReconDisburInfs, oracleOMSNamedQueries.get(APIConstant._REGEX_GET_LOAN_NO).replaceAll("\\s+",""));
		financeList = getListMatchPattern(omsReconDisburInfs, bankDisbursInfo.getRegFin());
		//creditShieldList = getListMatchPattern(omsReconDisburInfs, bankDisbursInfo.getRegShield());
		//revertList = getListMatchPattern(omsReconDisburInfs, bankDisbursInfo.getRegRevert());
		omsReconDisburInfs.removeAll(financeList);
		//omsReconDisburInfs.removeAll(creditShieldList);
		//omsReconDisburInfs.removeAll(revertList);
		processLoadReconcileInfo(file, bankFileVal, omsReconDisburInfs, tOmsStmtFileMasList, creditShieldList, financeList,
				 revertList, MatchingList, unMatchingList, lmsMatchingList, lmsUnMatchingList);
		TOmsStmtFileMas tOmsStmtFileMas = getFileMasByFileName(file.getName(), tOmsStmtFileMasList);
		
		processReconcileDataBase(tOmsStmtFileMas, creditShieldList, financeList, revertList,
				 MatchingList, unMatchingList, lmsMatchingList, lmsUnMatchingList);
//		if(CommonUtil.isNumber(glBalance.get(APIConstant.GL_OPEN_BALANCE)) && CommonUtil.isNumber(glBalance.get(APIConstant.GL_CLOSE_BALANCE))) {
//			tOmsStmtFileMas.setOpenBalance(new BigDecimal( StringUtils.isBlank(glBalance.get(APIConstant.GL_OPEN_BALANCE)) ? "0":glBalance.get(APIConstant.GL_OPEN_BALANCE)));
//			tOmsStmtFileMas.setCloseBalance(new BigDecimal( StringUtils.isBlank(glBalance.get(APIConstant.GL_CLOSE_BALANCE)) ? "0":glBalance.get(APIConstant.GL_CLOSE_BALANCE)));
//		}
//		tOmsStmtFileMas.setProcessStatus(APIConstant._RECONCILE_DONE_STATUS);
		processLoadFileMasInf(tOmsStmtFileMas, omsReconDisburInfs.size(),MatchingList.size() , glBalance, loadAddInfForFileMas(creditShieldList, financeList, revertList, MatchingList, unMatchingList)
);
		/** Step 5: move file to Done folder */
		File destFile = new File(env.getProperty(APIConstant.PATH_SCAN_DISBURSAL_STATEMENT_DONE_FOLDER));
		moveFileToDirectory(file, destFile);		
	}

}
